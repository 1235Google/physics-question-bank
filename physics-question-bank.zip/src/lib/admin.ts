import { Question } from '../types';

export function getCustomQuestions(): Question[] {
  try {
    const data = localStorage.getItem('custom_questions');
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function saveCustomQuestions(questions: Question[]) {
  localStorage.setItem('custom_questions', JSON.stringify(questions));
}

export function addCustomQuestion(question: Question) {
  const qs = getCustomQuestions();
  qs.push(question);
  saveCustomQuestions(qs);
}

export function deleteCustomQuestion(id: string) {
  const qs = getCustomQuestions();
  saveCustomQuestions(qs.filter(q => q.id !== id));
}
