import { UserProgress } from '../types';

const STORAGE_KEY = 'physics_qb_progress_v1';

const INITIAL_PROGRESS: UserProgress = {
  solvedQuestions: {},
  completedWorksheets: [],
  quizAttempts: [],
  streak: 0,
  lastActiveDate: null,
  favoriteChapters: [],
  bookmarkedQuestions: [],
  xp: 0,
  coins: 0,
  lastRewardDate: null
};

export function getProgress(): UserProgress {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      return INITIAL_PROGRESS;
    }
    const parsed = JSON.parse(data) as UserProgress;
    
    // Ensure nested fields are present if loaded from older versions
    return {
      solvedQuestions: parsed.solvedQuestions || {},
      completedWorksheets: parsed.completedWorksheets || [],
      quizAttempts: parsed.quizAttempts || [],
      streak: parsed.streak || 0,
      lastActiveDate: parsed.lastActiveDate || null,
      favoriteChapters: parsed.favoriteChapters || [],
      bookmarkedQuestions: parsed.bookmarkedQuestions || [],
      xp: parsed.xp || 0,
      coins: parsed.coins || 0,
      lastRewardDate: parsed.lastRewardDate || null
    };
  } catch (e) {
    console.error('Error loading progress:', e);
    return INITIAL_PROGRESS;
  }
}

export function saveProgress(progress: UserProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Error saving progress:', e);
  }
}

export function recordQuestionSolved(
  questionId: string,
  answered: string,
  isCorrect: boolean
): UserProgress {
  const progress = getProgress();
  const today = new Date().toISOString().split('T')[0];

  progress.solvedQuestions[questionId] = {
    answered,
    isCorrect,
    timestamp: new Date().toISOString()
  };

  // Manage Active Streak
  if (progress.lastActiveDate !== today) {
    if (progress.lastActiveDate) {
      const lastDate = new Date(progress.lastActiveDate);
      const currentDate = new Date(today);
      const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === 1) {
        progress.streak += 1;
      } else if (diffDays > 1) {
        progress.streak = 1;
      }
    } else {
      progress.streak = 1;
    }
    progress.lastActiveDate = today;
  }

  // Add rewards
  if (isCorrect) {
    progress.xp += 15;
    progress.coins += 2;
  } else {
    progress.xp += 5; // Reward for trying
  }

  saveProgress(progress);
  return progress;
}

export function recordWorksheetCompleted(worksheetId: string): UserProgress {
  const progress = getProgress();
  if (!progress.completedWorksheets.includes(worksheetId)) {
    progress.completedWorksheets.push(worksheetId);
  }
  saveProgress(progress);
  return progress;
}

export function recordQuizAttempt(attempt: {
  classId: number;
  chapterId: string;
  score: number;
  total: number;
  percentage: number;
  timeTaken: number;
}): UserProgress {
  const progress = getProgress();
  const today = new Date().toISOString().split('T')[0];
  
  progress.quizAttempts.push({
    ...attempt,
    id: `quiz_${Date.now()}`,
    timestamp: new Date().toISOString()
  });

  // Streak logic
  if (progress.lastActiveDate !== today) {
    if (progress.lastActiveDate) {
      const lastDate = new Date(progress.lastActiveDate);
      const currentDate = new Date(today);
      const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === 1) {
        progress.streak += 1;
      } else if (diffDays > 1) {
        progress.streak = 1;
      }
    } else {
      progress.streak = 1;
    }
    progress.lastActiveDate = today;
  }

  // Quiz Rewards: Base XP + Bonus based on percentage
  const earnedXp = attempt.total * 5 + Math.round(attempt.percentage * 1.5);
  const earnedCoins = Math.floor(attempt.percentage / 10) + (attempt.percentage === 100 ? 5 : 0);
  
  progress.xp += earnedXp;
  progress.coins += earnedCoins;

  saveProgress(progress);
  return progress;
}

export function toggleFavoriteChapter(chapterId: string): UserProgress {
  const progress = getProgress();
  const index = progress.favoriteChapters.indexOf(chapterId);
  if (index === -1) {
    progress.favoriteChapters.push(chapterId);
  } else {
    progress.favoriteChapters.splice(index, 1);
  }
  saveProgress(progress);
  return progress;
}

export function toggleBookmarkedQuestion(questionId: string): UserProgress {
  const progress = getProgress();
  const index = progress.bookmarkedQuestions.indexOf(questionId);
  if (index === -1) {
    progress.bookmarkedQuestions.push(questionId);
  } else {
    progress.bookmarkedQuestions.splice(index, 1);
  }
  saveProgress(progress);
  return progress;
}

export function addReward(xp: number, coins: number): UserProgress {
  const progress = getProgress();
  progress.xp += xp;
  progress.coins += coins;
  saveProgress(progress);
  return progress;
}

export function claimDailyReward(): UserProgress | null {
  const progress = getProgress();
  const today = new Date().toISOString().split('T')[0];
  if (progress.lastRewardDate === today) {
    return null; // Already claimed today
  }
  
  progress.lastRewardDate = today;
  // Reward logic: e.g. 50 XP and 10 coins
  progress.xp += 50;
  progress.coins += 10;
  
  saveProgress(progress);
  return progress;
}
