import { db } from './firebase';
import { collection, doc, writeBatch } from 'firebase/firestore';
import { CLASSES_DATA, CHAPTERS_DATA, PHYSICS_QUESTIONS, WORKSHEETS_DATA } from '../data/questions';

export async function seedDatabase() {
  if (!db.app.options.projectId || db.app.options.projectId === "dummy") {
    throw new Error("Firebase is not configured. Please set up environment variables.");
  }
  
  try {
    const batch = writeBatch(db);
    
    // Seed Classes
    CLASSES_DATA.forEach(c => {
      const docRef = doc(db, 'classes', c.id.toString());
      batch.set(docRef, { ...c });
    });
    
    // Seed Chapters
    CHAPTERS_DATA.forEach(ch => {
      const docRef = doc(db, 'chapters', ch.id);
      // Ensure we don't save circular references or unneeded data
      const chapterData = { ...ch };
      delete (chapterData as any).questions;
      batch.set(docRef, chapterData);
    });

    // We might exceed the 500 limit for a batch, so we chunk it
    const chunkArray = (arr: any[], size: number) => 
      Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
        arr.slice(i * size, i * size + size)
      );

    await batch.commit();

    // Questions (chunked)
    const questionChunks = chunkArray(PHYSICS_QUESTIONS, 400);
    for (const chunk of questionChunks) {
      const qBatch = writeBatch(db);
      chunk.forEach(q => {
        const docRef = doc(db, 'questions', q.id);
        qBatch.set(docRef, { ...q });
      });
      await qBatch.commit();
    }
    
    // Worksheets
    const wsBatch = writeBatch(db);
    WORKSHEETS_DATA.forEach(ws => {
      const docRef = doc(db, 'worksheets', ws.id);
      const wsData = { ...ws };
      delete (wsData as any).questions;
      wsBatch.set(docRef, wsData);
    });
    await wsBatch.commit();
    
    return true;
  } catch (err) {
    console.error("Error seeding database:", err);
    throw err;
  }
}
