import { db } from './firebase';
import { collection, getDocs, doc, setDoc, query, where, getDoc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { Question, Chapter, ClassInfo, Worksheet, UserProgress } from '../types';

// Fetch classes
export async function getClasses(): Promise<ClassInfo[]> {
  const snapshot = await getDocs(collection(db, 'classes'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as unknown as ClassInfo));
}

// Fetch chapters
export async function getChapters(classId?: number): Promise<Chapter[]> {
  const chaptersRef = collection(db, 'chapters');
  const q = classId ? query(chaptersRef, where('classId', '==', classId)) : chaptersRef;
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter));
}

// Fetch questions
export async function getQuestions(filters?: { classId?: number; chapterId?: string; difficulty?: string; type?: string }): Promise<Question[]> {
  let qRef = collection(db, 'questions');
  let q = query(qRef);

  if (filters?.classId && filters.classId !== -1) {
    q = query(q, where('classId', '==', filters.classId));
  }
  if (filters?.chapterId && filters.chapterId !== 'all') {
    q = query(q, where('chapterId', '==', filters.chapterId));
  }
  if (filters?.difficulty && filters.difficulty !== 'all') {
    q = query(q, where('difficulty', '==', filters.difficulty));
  }
  if (filters?.type && filters.type !== 'all') {
    q = query(q, where('type', '==', filters.type));
  }

  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Question));
}

export async function addQuestion(question: Question): Promise<void> {
  await setDoc(doc(db, 'questions', question.id), question);
}

export async function updateQuestion(question: Question): Promise<void> {
  await setDoc(doc(db, 'questions', question.id), question, { merge: true });
}

export async function deleteQuestion(id: string): Promise<void> {
  await deleteDoc(doc(db, 'questions', id));
}

export async function getWorksheets(): Promise<Worksheet[]> {
  const snapshot = await getDocs(collection(db, 'worksheets'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Worksheet));
}

export async function addChapter(chapter: Chapter): Promise<void> {
  await setDoc(doc(db, 'chapters', chapter.id), chapter);
}

export async function deleteChapter(id: string): Promise<void> {
  await deleteDoc(doc(db, 'chapters', id));
}

export async function addWorksheet(worksheet: Worksheet): Promise<void> {
  await setDoc(doc(db, 'worksheets', worksheet.id), worksheet);
}

export async function deleteWorksheet(id: string): Promise<void> {
  await deleteDoc(doc(db, 'worksheets', id));
}

export async function addQuiz(quiz: any): Promise<void> {
  await setDoc(doc(db, 'quizzes', quiz.id), quiz);
}

export async function deleteQuiz(id: string): Promise<void> {
  await deleteDoc(doc(db, 'quizzes', id));
}

export async function getQuizzes(): Promise<any[]> {
  const snapshot = await getDocs(collection(db, 'quizzes'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export const addQuestionsBatch = async (questions: Question[]) => {
  const batch = writeBatch(db);
  questions.forEach(q => {
    const qRef = doc(db, 'questions', q.id);
    batch.set(qRef, q);
  });
  await batch.commit();
};
