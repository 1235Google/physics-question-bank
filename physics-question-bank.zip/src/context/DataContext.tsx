import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Question, Chapter, ClassInfo, Worksheet } from '../types';
import { getClasses, getChapters, getQuestions, getWorksheets, getQuizzes } from '../lib/db';
import { CLASSES_DATA as DEFAULT_CLASSES, CHAPTERS_DATA as DEFAULT_CHAPTERS, PHYSICS_QUESTIONS as DEFAULT_QUESTIONS, WORKSHEETS_DATA as DEFAULT_WORKSHEETS } from '../data/questions';
import { db } from '../lib/firebase';

interface DataContextType {
  classes: ClassInfo[];
  chapters: Chapter[];
  questions: Question[];
  worksheets: Worksheet[];
  quizzes: any[];
  loading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [classes, setClasses] = useState<ClassInfo[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [worksheets, setWorksheets] = useState<Worksheet[]>([]);
  const [quizzes, setQuizzes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      // Check if Firebase is actually configured
      if (db.app.options.projectId && db.app.options.projectId !== "dummy") {
        const [dbClasses, dbChapters, dbQuestions, dbWorksheets, dbQuizzes] = await Promise.all([
          getClasses(),
          getChapters(),
          getQuestions(),
          getWorksheets(),
          getQuizzes()
        ]);
        
        if (dbClasses.length > 0) setClasses(dbClasses);
        if (dbChapters.length > 0) setChapters(dbChapters);
        if (dbQuestions.length > 0) setQuestions(dbQuestions);
        if (dbWorksheets.length > 0) setWorksheets(dbWorksheets);
        if (dbQuizzes.length > 0) setQuizzes(dbQuizzes);
      }
    } catch (err: any) {
      console.error("Error fetching data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <DataContext.Provider value={{ classes, chapters, questions, worksheets, quizzes, loading, error, refreshData: fetchData }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
