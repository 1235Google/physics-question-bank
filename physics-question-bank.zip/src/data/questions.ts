import { Question, Chapter, Worksheet, ClassInfo } from '../types';
import { getCustomQuestions } from '../lib/admin';

const DEFAULT_PHYSICS_QUESTIONS: Question[] = [
  // ==========================================
  // CLASS 6
  // ==========================================
  {
    id: 'c6_ch1_q1',
    class: 6,
    chapter: 'c6_motion_measurement',
    question: 'What is the SI unit of length?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['Centimeter', 'Meter', 'Kilometer', 'Millimeter'],
    answer: 'Meter',
    explanation: 'The International System of Units (SI) unit of length is the meter (m).',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c6_ch1_q2',
    class: 6,
    chapter: 'c6_motion_measurement',
    question: 'A motion that repeats itself after regular intervals of time is called periodic motion.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'True',
    explanation: 'Periodic motion repeats itself at equal intervals of time, like a clock pendulum or a swing.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c6_ch1_q3',
    class: 6,
    chapter: 'c6_motion_measurement',
    question: 'The motion of a drawer pulling out is an example of __________ motion.',
    type: 'fill_blank',
    difficulty: 'medium',
    marks: 1,
    answer: 'rectilinear',
    explanation: 'The motion of a drawer is along a straight line, which is rectilinear motion (or linear motion).',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c6_ch1_q4',
    class: 6,
    chapter: 'c6_motion_measurement',
    question: 'A thread is used to measure the length of a curved line. If the thread starts at 2 cm on a ruler and ends at 15.5 cm, what is the length of the curved line?',
    type: 'numerical',
    difficulty: 'medium',
    marks: 2,
    answer: '13.5 cm',
    explanation: 'Length of the curved line = Ending reading - Starting reading = 15.5 cm - 2.0 cm = 13.5 cm.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c6_ch2_q1',
    class: 6,
    chapter: 'c6_light_shadows',
    question: 'Which of the following is a non-luminous object?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['Sun', 'Burning Candle', 'Moon', 'Glow-worm'],
    answer: 'Moon',
    explanation: 'The Moon does not emit its own light; it reflects light from the Sun, making it non-luminous.',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 60,
    relatedConcept: 'Optics'
  },
  {
    id: 'c6_ch2_q2',
    class: 6,
    chapter: 'c6_light_shadows',
    question: 'Explain the difference between transparent, translucent, and opaque materials with examples.',
    type: 'long_answer',
    difficulty: 'medium',
    marks: 5,
    answer: 'Transparent materials allow light to pass through them completely (e.g., clear water, air). Translucent materials allow light to pass through them partially, so objects cannot be seen clearly (e.g., butter paper, frosted glass). Opaque materials do not allow light to pass through them at all (e.g., cardboard, wood, brick).',
    explanation: 'This division is based on the behavior of light when it strikes a material: transparent lets light pass fully, translucent lets some pass, and opaque blocks all light.',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 120,
    relatedConcept: 'Optics'
  },
  {
    id: 'c6_ch3_q1',
    class: 6,
    chapter: 'c6_electricity',
    question: 'Which part of an electric bulb glows when current passes through it?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['Glass case', 'Filament', 'Terminals', 'Thick wires support'],
    answer: 'Filament',
    explanation: 'The filament, which is a thin coil of tungsten wire, heats up and glows when electricity passes through it.',
    hint: 'Think about the basic principles of electricity.',
    estimatedTime: 90,
    relatedConcept: 'Electricity'
  },
  {
    id: 'c6_ch3_q2',
    class: 6,
    chapter: 'c6_electricity',
    question: 'Distinguish between conductors and insulators of electricity.',
    type: 'short_answer',
    difficulty: 'medium',
    marks: 3,
    answer: 'Conductors are materials that allow electric current to flow through them easily (e.g., copper, iron, aluminum). Insulators are materials that do not allow electric current to pass through them (e.g., plastic, rubber, wood).',
    explanation: 'Conductors have free electrons that carry electric current, whereas insulators do not.',
    hint: 'Think about the basic principles of electricity.',
    estimatedTime: 60,
    relatedConcept: 'Electricity'
  },

  // ==========================================
  // CLASS 7
  // ==========================================
  {
    id: 'c7_ch1_q1',
    class: 7,
    chapter: 'c7_heat',
    question: 'What is the normal temperature of a healthy human body in Celsius?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['35 °C', '37 °C', '42 °C', '98.6 °C'],
    answer: '37 °C',
    explanation: 'The normal temperature of the human body is approximately 37 °C (which is 98.6 °F).',
    hint: 'Think about the basic principles of thermodynamics.',
    estimatedTime: 60,
    relatedConcept: 'Thermodynamics'
  },
  {
    id: 'c7_ch1_q2',
    class: 7,
    chapter: 'c7_heat',
    question: 'In liquids and gases, heat transfer takes place primarily by which process?',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: ['Conduction', 'Convection', 'Radiation', 'Insulation'],
    answer: 'Convection',
    explanation: 'Convection is the mode of heat transfer in fluids (liquids and gases) where hot, less dense parts rise and cool, denser parts sink.',
    hint: 'Think about the basic principles of thermodynamics.',
    estimatedTime: 90,
    relatedConcept: 'Thermodynamics'
  },
  {
    id: 'c7_ch1_q3',
    class: 7,
    chapter: 'c7_heat',
    question: 'A clinical thermometer can measure temperatures from 0 °C to 100 °C.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'False',
    explanation: 'A clinical thermometer is designed specifically to measure human body temperature and ranges from 35 °C to 42 °C (or 95 °F to 108 °F).',
    hint: 'Think about the basic principles of thermodynamics.',
    estimatedTime: 90,
    relatedConcept: 'Thermodynamics'
  },
  {
    id: 'c7_ch2_q1',
    class: 7,
    chapter: 'c7_motion_time',
    question: 'An object moving along a straight line with a constant speed is said to be in __________ motion.',
    type: 'fill_blank',
    difficulty: 'easy',
    marks: 1,
    answer: 'uniform',
    explanation: 'When an object covers equal distances in equal intervals of time along a straight line, it is in uniform motion.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c7_ch2_q2',
    class: 7,
    chapter: 'c7_motion_time',
    question: 'A simple pendulum takes 32 seconds to complete 20 oscillations. What is the time period of the pendulum?',
    type: 'numerical',
    difficulty: 'medium',
    marks: 2,
    answer: '1.6 s',
    explanation: 'Time Period = Total Time / Number of Oscillations = 32 s / 20 = 1.6 seconds.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c7_ch3_q1',
    class: 7,
    chapter: 'c7_electricity_current',
    question: 'Which safety device in household circuits breaks the circuit when excessive current flows through?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['Electromagnet', 'Electric Fuse', 'Key Switch', 'Resistor'],
    answer: 'Electric Fuse',
    explanation: 'An electric fuse contains a wire with a low melting point that melts and breaks the circuit if the current exceeds a safe limit.',
    hint: 'Think about the basic principles of electricity.',
    estimatedTime: 90,
    relatedConcept: 'Electricity'
  },

  // ==========================================
  // CLASS 8
  // ==========================================
  {
    id: 'c8_ch1_q1',
    class: 8,
    chapter: 'c8_force_pressure',
    question: 'Which of the following is a non-contact force?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['Muscular force', 'Frictional force', 'Magnetic force', 'Tension force'],
    answer: 'Magnetic force',
    explanation: 'Magnetic force acts over a distance without physical contact, whereas muscular and frictional forces require physical contact.',
    hint: 'Think about the basic principles of force & motion.',
    estimatedTime: 90,
    relatedConcept: 'Force & Motion'
  },
  {
    id: 'c8_ch1_q2',
    class: 8,
    chapter: 'c8_force_pressure',
    question: 'A force of 100 N is applied over an area of 2 m². What is the pressure produced in Pascal (Pa)?',
    type: 'numerical',
    difficulty: 'easy',
    marks: 2,
    answer: '50 Pa',
    explanation: 'Pressure (P) = Force (F) / Area (A) = 100 N / 2 m² = 50 Pa (N/m²).',
    hint: 'Think about the basic principles of force & motion.',
    estimatedTime: 60,
    relatedConcept: 'Force & Motion'
  },
  {
    id: 'c8_ch1_q3',
    class: 8,
    chapter: 'c8_force_pressure',
    question: 'Explain why school bags have wide straps instead of thin strings.',
    type: 'short_answer',
    difficulty: 'medium',
    marks: 3,
    answer: 'Wide straps increase the surface area in contact with the shoulder. Since Pressure = Force / Area, increasing the area reduces the pressure exerted on the student\'s shoulders, making it comfortable to carry.',
    explanation: 'A larger area reduces the pressure for the same weight, reducing strain on the shoulders.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c8_ch2_q1',
    class: 8,
    chapter: 'c8_friction',
    question: 'Which of the following friction values is typically the smallest for the same pair of surfaces?',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: ['Static friction', 'Sliding friction', 'Rolling friction', 'Fluid friction'],
    answer: 'Rolling friction',
    explanation: 'Rolling friction is much smaller than sliding and static friction, which is why wheels and ball bearings are used to reduce friction.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c8_ch2_q2',
    class: 8,
    chapter: 'c8_friction',
    question: 'Friction can be increased by making surfaces smoother.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'False',
    explanation: 'Making surfaces smoother reduces friction (to a limit). To increase friction, surfaces are made rougher (like treaded tires or grooved shoes).',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c8_ch3_q1',
    class: 8,
    chapter: 'c8_light',
    question: 'What is the angle of reflection if the angle of incidence of a light ray on a plane mirror is 35 degrees?',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: ['35 degrees', '55 degrees', '90 degrees', '70 degrees'],
    answer: '35 degrees',
    explanation: 'According to the first law of reflection, the angle of incidence is always equal to the angle of reflection.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c8_ch3_q2',
    class: 8,
    chapter: 'c8_light',
    question: 'The part of the eye that controls the amount of light entering is the __________.',
    type: 'fill_blank',
    difficulty: 'medium',
    marks: 1,
    answer: 'iris',
    explanation: 'The iris is the colored part of the eye that adjusts the size of the pupil, controlling the amount of light entering.',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 90,
    relatedConcept: 'Optics'
  },

  // ==========================================
  // CLASS 9
  // ==========================================
  {
    id: 'c9_ch1_q1',
    class: 9,
    chapter: 'c9_motion',
    question: 'A particle is moving in a circular path of radius R. The displacement after half a circle would be:',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: ['Zero', 'πR', '2R', '2πR'],
    answer: '2R',
    explanation: 'Displacement is the shortest distance between the initial and final position. After half a circle, the particle is at the diametrically opposite point, so the distance is 2R.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 120,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch1_q2',
    class: 9,
    chapter: 'c9_motion',
    question: 'A car accelerates uniformly from 18 km/h to 36 km/h in 5 seconds. What is its acceleration in m/s²?',
    type: 'numerical',
    difficulty: 'hard',
    marks: 3,
    answer: '1 m/s²',
    explanation: 'Convert speeds to m/s: Initial (u) = 18 * (5/18) = 5 m/s. Final (v) = 36 * (5/18) = 10 m/s. Acceleration (a) = (v - u) / t = (10 - 5) / 5 = 1 m/s².',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch1_q3',
    class: 9,
    chapter: 'c9_motion',
    question: 'Distance is a scalar quantity, whereas displacement is a vector quantity.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'True',
    explanation: 'Distance has only magnitude (scalar), while displacement has both magnitude and a specific direction (vector).',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch1_q4',
    class: 9,
    chapter: 'c9_motion',
    question: 'Derive the equation of motion: s = ut + ½at² using graphical methods.',
    type: 'long_answer',
    difficulty: 'hard',
    marks: 5,
    answer: 'Consider a velocity-time graph where an object starts with initial velocity u and accelerates uniformly to final velocity v in time t. The distance s travelled is equal to the area under the v-t graph (which is a trapezoid). Area of trapezoid = Area of rectangle (u * t) + Area of triangle (½ * t * (v - u)). Since acceleration a = (v - u)/t, we have (v - u) = at. Substituting this, we get Area = ut + ½ * t * at = ut + ½at².',
    explanation: 'The distance travelled by an object is the geometric area under its velocity-time graph, split into a uniform rectangular block and a triangular acceleration block.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 120,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch2_q1',
    class: 9,
    chapter: 'c9_force_laws',
    question: 'The inertia of an object tends to cause the object to:',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    options: [
      'increase its speed',
      'decrease its speed',
      'resist any change in its state of motion',
      'decelerate due to friction'
    ],
    answer: 'resist any change in its state of motion',
    explanation: 'Inertia is the natural tendency of an object to resist changes in its state of rest or uniform motion.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch2_q2',
    class: 9,
    chapter: 'c9_force_laws',
    question: 'An object of mass 2 kg is slid with a constant velocity of 4 m/s on a frictionless horizontal table. The force required to keep the object moving with the same velocity is:',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: ['8 N', '2 N', '32 N', '0 N'],
    answer: '0 N',
    explanation: 'According to Newton\'s First Law, an object will maintain constant velocity unless acted upon by an external net force. Since the table is frictionless, 0 N is required to maintain motion.',
    hint: 'Think about the basic principles of force & motion.',
    estimatedTime: 120,
    relatedConcept: 'Force & Motion'
  },
  {
    id: 'c9_ch2_q3',
    class: 9,
    chapter: 'c9_force_laws',
    question: 'A bullet of mass 20g is horizontally fired with a velocity of 150 m/s from a pistol of mass 2 kg. Calculate the recoil velocity of the pistol.',
    type: 'numerical',
    difficulty: 'hard',
    marks: 3,
    answer: '-1.5 m/s',
    explanation: 'By Conservation of Momentum: m1*u1 + m2*u2 = m1*v1 + m2*v2. Since initially at rest, Initial Momentum = 0. Final Momentum = 0 = (0.02 kg * 150 m/s) + (2 kg * v_recoil) => 3 + 2 * v_recoil = 0 => v_recoil = -1.5 m/s. The negative sign denotes direction opposite to the bullet.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 120,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch3_q1',
    class: 9,
    chapter: 'c9_gravitation',
    question: 'The value of acceleration due to gravity (g) is constant everywhere on the Earth\'s surface.',
    type: 'true_false',
    difficulty: 'medium',
    marks: 1,
    options: ['True', 'False'],
    answer: 'False',
    explanation: 'The value of g is slightly larger at the poles and smaller at the equator because the Earth is not a perfect sphere (flatter at poles, wider at equator).',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 120,
    relatedConcept: 'Optics'
  },
  {
    id: 'c9_ch3_q2',
    class: 9,
    chapter: 'c9_gravitation',
    question: 'What is the mass of an object whose weight is 49 N? (Take g = 9.8 m/s²)',
    type: 'numerical',
    difficulty: 'medium',
    marks: 2,
    answer: '5 kg',
    explanation: 'Weight (W) = mass (m) * g => 49 N = m * 9.8 m/s² => m = 49 / 9.8 = 5 kg.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c9_ch3_q3',
    class: 9,
    chapter: 'c9_gravitation',
    question: 'State Archimedes\' Principle and write two of its practical applications.',
    type: 'long_answer',
    difficulty: 'hard',
    marks: 4,
    answer: 'Archimedes\' Principle states that when a body is immersed fully or partially in a fluid, it experiences an upward buoyant force that is equal to the weight of the fluid displaced by it. Applications include: (1) Designing ships and submarines, (2) Lactometers (used to determine purity of milk), and (3) Hydrometers (used to determine density of liquids).',
    explanation: 'The buoyant force is mathematically F_buoyant = rho * g * V, which is equal to the weight of the displaced liquid.',
    hint: 'Think about the basic principles of force & motion.',
    estimatedTime: 90,
    relatedConcept: 'Force & Motion'
  },

  // ==========================================
  // CLASS 10
  // ==========================================
  {
    id: 'c10_ch1_q1',
    class: 10,
    chapter: 'c10_light_refl_refr',
    question: 'An object is placed at a distance of 10 cm in front of a convex mirror of focal length 15 cm. Find the position of the image.',
    type: 'numerical',
    difficulty: 'hard',
    marks: 3,
    answer: '6 cm',
    explanation: 'For a convex mirror, f = +15 cm, u = -10 cm. Using Mirror Formula: 1/f = 1/v + 1/u => 1/15 = 1/v - 1/10 => 1/v = 1/15 + 1/10 = 5/30 = 1/6 => v = +6 cm. The image is formed behind the mirror.',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 120,
    relatedConcept: 'Optics'
  },
  {
    id: 'c10_ch1_q2',
    class: 10,
    chapter: 'c10_light_refl_refr',
    question: 'A concave mirror can produce a real, inverted, and magnified image.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'True',
    explanation: 'When the object is placed between C and F, or at F, a concave mirror forms a real, inverted, and magnified image.',
    hint: 'Think about the basic principles of optics.',
    estimatedTime: 90,
    relatedConcept: 'Optics'
  },
  {
    id: 'c10_ch1_q3',
    class: 10,
    chapter: 'c10_light_refl_refr',
    question: 'The power of a lens is -2.0 D. Its focal length is:',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: ['-50 cm', '-2.0 m', '+50 cm', '+2.0 m'],
    answer: '-50 cm',
    explanation: 'Power (P) = 1 / f (in meters) => f = 1 / P = 1 / (-2) = -0.5 m = -50 cm. The negative focal length indicates a concave lens.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c10_ch2_q1',
    class: 10,
    chapter: 'c10_electricity',
    question: 'According to Ohm\'s Law, the electrical current (I) flowing through a metallic conductor is directly proportional to the voltage (V) across its ends, provided temperature remains constant.',
    type: 'true_false',
    difficulty: 'easy',
    marks: 1,
    options: ['True', 'False'],
    answer: 'True',
    explanation: 'Ohm\'s Law states V = IR, representing a linear proportional relationship between potential difference and current.',
    hint: 'Think about the basic principles of electricity.',
    estimatedTime: 90,
    relatedConcept: 'Electricity'
  },
  {
    id: 'c10_ch2_q2',
    class: 10,
    chapter: 'c10_electricity',
    question: 'How much work is done in moving a charge of 2 C across two points having a potential difference of 12 V?',
    type: 'numerical',
    difficulty: 'medium',
    marks: 2,
    answer: '24 J',
    explanation: 'Work Done (W) = Charge (Q) * Potential Difference (V) = 2 C * 12 V = 24 Joules.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 60,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c10_ch2_q3',
    class: 10,
    chapter: 'c10_electricity',
    question: 'Three resistors of 2 Ω, 3 Ω, and 6 Ω are connected in parallel. What is their equivalent resistance?',
    type: 'numerical',
    difficulty: 'hard',
    marks: 3,
    answer: '1 Ω',
    explanation: 'For parallel circuit: 1/Rp = 1/R1 + 1/R2 + 1/R3 = 1/2 + 1/3 + 1/6 = (3 + 2 + 1)/6 = 6/6 = 1. So, Rp = 1 Ω.',
    hint: 'Think about the basic principles of core concepts.',
    estimatedTime: 90,
    relatedConcept: 'Core Concepts'
  },
  {
    id: 'c10_ch2_q4',
    class: 10,
    chapter: 'c10_electricity',
    question: 'State Joule\'s Law of Heating. Express it mathematically and list two industrial or domestic appliances that work on this principle.',
    type: 'long_answer',
    difficulty: 'medium',
    marks: 4,
    answer: 'Joule\'s Law of Heating states that the heat produced in a resistor is (1) directly proportional to the square of the current for a given resistance, (2) directly proportional to the resistance for a given current, and (3) directly proportional to the time for which the current flows. Mathematically: H = I²Rt. Examples: Electric iron, electric toaster, electric oven, electric heater, and electric fuse.',
    explanation: 'Heat is generated due to collisions of flowing electrons with the atomic lattice of the resistive material.',
    hint: 'Think about the basic principles of thermodynamics.',
    estimatedTime: 90,
    relatedConcept: 'Thermodynamics'
  },
  {
    id: 'c10_ch3_q1',
    class: 10,
    chapter: 'c10_magnetic_effects',
    question: 'A soft iron core placed inside a current-carrying solenoid turns it into a strong temporary magnet called an __________.',
    type: 'fill_blank',
    difficulty: 'easy',
    marks: 1,
    answer: 'electromagnet',
    explanation: 'An electromagnet is a temporary magnet made by wrapping a coil of wire around a soft iron core and passing an electric current through the coil.',
    hint: 'Think about the basic principles of electricity.',
    estimatedTime: 90,
    relatedConcept: 'Electricity'
  },
  {
    id: 'c10_ch3_q2',
    class: 10,
    chapter: 'c10_magnetic_effects',
    question: 'Which rule is used to find the direction of force on a current-carrying conductor in a magnetic field?',
    type: 'mcq',
    difficulty: 'medium',
    marks: 1,
    options: [
      'Right-Hand Thumb Rule',
      'Fleming\'s Left-Hand Rule',
      'Fleming\'s Right-Hand Rule',
      'Lenz\'s Law'
    ],
    answer: 'Fleming\'s Left-Hand Rule',
    explanation: 'Fleming\'s Left-Hand Rule is used for motors to find the force: Thumb = Force, Forefinger = Magnetic Field, Middle finger = Current.',
    hint: 'Think about the basic principles of force & motion.',
    estimatedTime: 90,
    relatedConcept: 'Force & Motion'
  }
];

export const PHYSICS_QUESTIONS: Question[] = [...DEFAULT_PHYSICS_QUESTIONS, ...getCustomQuestions()];

export const CHAPTERS_DATA: Chapter[] = [
  // Class 6 Chapters
  {
    id: 'c6_motion_measurement',
    classId: 6,
    name: 'Motion and Measurement of Distances',
    description: 'Explore the history of transport, standard units of measurement, types of motion (rectilinear, circular, periodic).',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_motion_measurement')
  },
  {
    id: 'c6_light_shadows',
    classId: 6,
    name: 'Light, Shadows and Reflections',
    description: 'Learn about opaque, transparent, and translucent materials, how shadows are formed, and mirror reflections.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_light_shadows')
  },
  {
    id: 'c6_electricity',
    classId: 6,
    name: 'Electricity and Circuits',
    description: 'Understand electric cells, complete circuits, switches, conductors, and insulators.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_electricity')
  },

  // Class 7 Chapters
  {
    id: 'c7_heat',
    classId: 7,
    name: 'Heat and Temperature',
    description: 'Understand hot and cold, temperature scales, clinical and laboratory thermometers, conduction, convection, radiation.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c7_heat')
  },
  {
    id: 'c7_motion_time',
    classId: 7,
    name: 'Motion and Time',
    description: 'Learn about speed, uniform/non-uniform motion, time period of simple pendulums, and distance-time graphs.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c7_motion_time')
  },
  {
    id: 'c7_electricity_current',
    classId: 7,
    name: 'Electric Current and its Effects',
    description: 'Explore circuit diagram symbols, the heating effect of electric currents (fuses), and electromagnets.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c7_electricity_current')
  },

  // Class 8 Chapters
  {
    id: 'c8_force_pressure',
    classId: 8,
    name: 'Force and Pressure',
    description: 'Study contact/non-contact forces, pressure under fluids, and atmospheric pressure.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_force_pressure')
  },
  {
    id: 'c8_friction',
    classId: 8,
    name: 'Friction: A Necessary Evil',
    description: 'Explore static, sliding, and rolling friction, factors affecting friction, and methods to change friction.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_friction')
  },
  {
    id: 'c8_light',
    classId: 8,
    name: 'Light and Reflection',
    description: 'Understand the laws of reflection, diffuse vs regular reflection, the human eye, and care of eyes.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_light')
  },

  // Class 9 Chapters
  {
    id: 'c9_motion',
    classId: 9,
    name: 'Motion',
    description: 'Master distance, displacement, speed, velocity, acceleration, distance-time/velocity-time graphs, and uniform circular motion.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_motion')
  },
  {
    id: 'c9_force_laws',
    classId: 9,
    name: 'Force and Laws of Motion',
    description: 'Dive deep into balanced and unbalanced forces, Newton\'s three laws of motion, inertia, and conservation of momentum.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_force_laws')
  },
  {
    id: 'c9_gravitation',
    classId: 9,
    name: 'Gravitation & Fluids',
    description: 'Understand the Universal Law of Gravitation, acceleration due to gravity (g), buoyancy, and Archimedes\' Principle.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_gravitation')
  },

  // Class 10 Chapters
  {
    id: 'c10_light_refl_refr',
    classId: 10,
    name: 'Light: Reflection & Refraction',
    description: 'Study spherical mirrors, mirror formula, magnification, refraction, Snell\'s law, lenses, lens formula, and power of a lens.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_light_refl_refr')
  },
  {
    id: 'c10_electricity',
    classId: 10,
    name: 'Electricity',
    description: 'Explore electric current, potential difference, Ohm\'s law, factors affecting resistance, series/parallel networks, and Joule\'s heating law.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_electricity')
  },
  {
    id: 'c10_magnetic_effects',
    classId: 10,
    name: 'Magnetic Effects of Electric Current',
    description: 'Study magnetic fields, solenoid fields, force on current conductors (Fleming\'s left hand rule), electromagnets, and household circuits.',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_magnetic_effects')
  }
];

export const CLASSES_DATA: ClassInfo[] = [
  {
    id: 6,
    name: 'Class 6 Physics',
    chaptersCount: 3,
    worksheetsCount: 3,
    questionsCount: PHYSICS_QUESTIONS.filter(q => q.class === 6).length,
    chapters: CHAPTERS_DATA.filter(ch => ch.classId === 6)
  },
  {
    id: 7,
    name: 'Class 7 Physics',
    chaptersCount: 3,
    worksheetsCount: 2,
    questionsCount: PHYSICS_QUESTIONS.filter(q => q.class === 7).length,
    chapters: CHAPTERS_DATA.filter(ch => ch.classId === 7)
  },
  {
    id: 8,
    name: 'Class 8 Physics',
    chaptersCount: 3,
    worksheetsCount: 3,
    questionsCount: PHYSICS_QUESTIONS.filter(q => q.class === 8).length,
    chapters: CHAPTERS_DATA.filter(ch => ch.classId === 8)
  },
  {
    id: 9,
    name: 'Class 9 Physics',
    chaptersCount: 3,
    worksheetsCount: 4,
    questionsCount: PHYSICS_QUESTIONS.filter(q => q.class === 9).length,
    chapters: CHAPTERS_DATA.filter(ch => ch.classId === 9)
  },
  {
    id: 10,
    name: 'Class 10 Physics',
    chaptersCount: 3,
    worksheetsCount: 4,
    questionsCount: PHYSICS_QUESTIONS.filter(q => q.class === 10).length,
    chapters: CHAPTERS_DATA.filter(ch => ch.classId === 10)
  }
];

export const WORKSHEETS_DATA: Worksheet[] = [
  // Class 6 Worksheets
  {
    id: 'ws_c6_1',
    classId: 6,
    number: 1,
    title: 'Measurement and Units Practice Sheet',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_motion_measurement'),
    difficulty: 'easy',
    estimatedTime: 10
  },
  {
    id: 'ws_c6_2',
    classId: 6,
    number: 2,
    title: 'Shadows and Reflections Exploration',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_light_shadows'),
    difficulty: 'easy',
    estimatedTime: 15
  },
  {
    id: 'ws_c6_3',
    classId: 6,
    number: 3,
    title: 'Basic Electricity & Circuit Builder',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c6_electricity'),
    difficulty: 'easy',
    estimatedTime: 10
  },

  // Class 7 Worksheets
  {
    id: 'ws_c7_1',
    classId: 7,
    number: 1,
    title: 'Heat Transfers & Temperature Scales',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c7_heat'),
    difficulty: 'medium',
    estimatedTime: 15
  },
  {
    id: 'ws_c7_2',
    classId: 7,
    number: 2,
    title: 'Motion, Time and Simple Pendulum Calculations',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c7_motion_time'),
    difficulty: 'medium',
    estimatedTime: 15
  },

  // Class 8 Worksheets
  {
    id: 'ws_c8_1',
    classId: 8,
    number: 1,
    title: 'Forces, Pressure and Stratified Applications',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_force_pressure'),
    difficulty: 'medium',
    estimatedTime: 20
  },
  {
    id: 'ws_c8_2',
    classId: 8,
    number: 2,
    title: 'Frictional Forces and Lubricant Efficiency',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_friction'),
    difficulty: 'medium',
    estimatedTime: 15
  },
  {
    id: 'ws_c8_3',
    classId: 8,
    number: 3,
    title: 'Optics and Human Eye Structures',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c8_light'),
    difficulty: 'medium',
    estimatedTime: 15
  },

  // Class 9 Worksheets
  {
    id: 'ws_c9_1',
    classId: 9,
    number: 1,
    title: 'Kinematics & Graph Analysis Master Sheet',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_motion'),
    difficulty: 'hard',
    estimatedTime: 25
  },
  {
    id: 'ws_c9_2',
    classId: 9,
    number: 2,
    title: 'Newtonian Dynamics & Momentum Conservation',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_force_laws'),
    difficulty: 'hard',
    estimatedTime: 20
  },
  {
    id: 'ws_c9_3',
    classId: 9,
    number: 3,
    title: 'Gravitation & Archimedes Principle Drill',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c9_gravitation'),
    difficulty: 'hard',
    estimatedTime: 20
  },

  // Class 10 Worksheets
  {
    id: 'ws_c10_1',
    classId: 10,
    number: 1,
    title: 'Mirrors, Lenses & Refraction Optics Sheet',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_light_refl_refr'),
    difficulty: 'hard',
    estimatedTime: 25
  },
  {
    id: 'ws_c10_2',
    classId: 10,
    number: 2,
    title: 'Ohmic Resistances and Electrical Circuits',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_electricity'),
    difficulty: 'hard',
    estimatedTime: 20
  },
  {
    id: 'ws_c10_3',
    classId: 10,
    number: 3,
    title: 'Electromagnetic Inductions and Fields',
    questions: PHYSICS_QUESTIONS.filter(q => q.chapter === 'c10_magnetic_effects'),
    difficulty: 'medium',
    estimatedTime: 15
  }
];
