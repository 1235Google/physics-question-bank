import React, { useState } from 'react';
import { Atom, Menu, X, Sun, Moon, Search, BookOpen, FileText, LayoutDashboard, Info, HelpCircle, Settings } from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Navbar({ currentView, onViewChange, darkMode, onToggleDarkMode }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: BookOpen },
    { id: 'classes', label: 'Classes', icon: Atom },
    { id: 'worksheets', label: 'Worksheets', icon: FileText },
    { id: 'quiz', label: 'Quiz', icon: HelpCircle },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'about', label: 'About', icon: Info },
    { id: 'admin', label: 'Admin', icon: Settings },
  ];

  return (
    <nav id="app-navbar" className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur-md transition-all duration-300 dark:border-slate-800 dark:bg-slate-900/95 shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div 
            id="nav-logo"
            className="flex cursor-pointer items-center space-x-2.5 group"
            onClick={() => { onViewChange('home'); setIsOpen(false); }}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-500/20 transition-all duration-300 group-hover:scale-105 group-hover:rotate-12 dark:bg-blue-500">
              <Atom className="h-6 w-6 animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className="font-sans text-lg font-bold tracking-tight text-slate-900 dark:text-white transition-colors duration-200">
                Physics Question Bank
              </span>
              <span className="font-sans text-[10px] font-medium text-blue-600 dark:text-blue-400 -mt-1 tracking-wider uppercase">
                Interactive Learning
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id || (item.id === 'classes' && currentView.startsWith('class-'));
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => onViewChange(item.id)}
                  className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg font-sans text-sm font-medium transition-all duration-250 ${
                    isActive
                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800/60 dark:hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* Dark Mode Toggle */}
            <div className="pl-4 ml-4 border-l border-slate-200 dark:border-slate-800">
              <button
                id="navbar-darkmode-toggle-desktop"
                onClick={onToggleDarkMode}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 shadow-sm transition-all duration-200 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700/80"
                title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              >
                {darkMode ? <Sun className="h-4 w-4 text-amber-500" /> : <Moon className="h-4 w-4 text-blue-600" />}
              </button>
            </div>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              id="navbar-darkmode-toggle-mobile"
              onClick={onToggleDarkMode}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 shadow-sm transition-all duration-200 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
            >
              {darkMode ? <Sun className="h-4.5 w-4.5 text-amber-500" /> : <Moon className="h-4.5 w-4.5 text-blue-600" />}
            </button>

            <button
              id="mobile-menu-toggle"
              onClick={() => setIsOpen(!isOpen)}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div id="mobile-drawer" className="md:hidden border-t bg-white dark:border-slate-800 dark:bg-slate-900 px-4 py-3 space-y-1 shadow-inner">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id || (item.id === 'classes' && currentView.startsWith('class-'));
            return (
              <button
                key={item.id}
                id={`nav-link-mobile-${item.id}`}
                onClick={() => {
                  onViewChange(item.id);
                  setIsOpen(false);
                }}
                className={`flex w-full items-center space-x-2.5 px-3 py-2.5 rounded-lg font-sans text-base font-medium transition-all ${
                  isActive
                    ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400'
                    : 'text-slate-600 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800/40'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </nav>
  );
}
