import { useData } from '../context/DataContext';
import React, { useState, useMemo } from 'react';
import { Worksheet, Question } from '../types';
import QuestionCard from './QuestionCard';
import { Download, FileText, CheckCircle, RotateCcw, AlertCircle, Clock, BookOpen, Printer, ArrowLeft, Award } from 'lucide-react';

interface WorksheetViewProps {
  onWorksheetCompleted: (worksheetId: string) => void;
  completedWorksheets: string[];
}

export default function WorksheetView({
  onWorksheetCompleted,
  completedWorksheets
}: WorksheetViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  const [selectedClass, setSelectedClass] = useState<number | 'all'>('all');
  const [activeWorksheet, setActiveWorksheet] = useState<Worksheet | null>(null);
  const [worksheetAnswers, setWorksheetAnswers] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isPrintMode, setIsPrintMode] = useState<Worksheet | null>(null);

  // Filters worksheets based on class selection
  const filteredWorksheets = useMemo(() => {
    if (selectedClass === 'all') {
      return WORKSHEETS_DATA;
    }
    return WORKSHEETS_DATA.filter(ws => ws.classId === selectedClass);
  }, [selectedClass]);

  const handleStartWorksheet = (ws: Worksheet) => {
    setActiveWorksheet(ws);
    setWorksheetAnswers({});
    setIsSubmitted(false);
  };

  const handleWorksheetSubmit = () => {
    if (!activeWorksheet) return;
    setIsSubmitted(true);
    onWorksheetCompleted(activeWorksheet.id);
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setWorksheetAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  // Triggers browser native Print view optimized by Tailwind print-utilities
  const triggerPrintPDF = (ws: Worksheet) => {
    setIsPrintMode(ws);
    setTimeout(() => {
      window.print();
      setIsPrintMode(null);
    }, 300);
  };

  const difficultyColors = {
    easy: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/30',
    medium: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/30',
    hard: 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-900/30'
  };

  // If in Print/PDF Mode, render a highly detailed print template only
  if (isPrintMode) {
    return (
      <div id="print-worksheet-template" className="bg-white text-black p-12 max-w-4xl mx-auto space-y-8 font-serif leading-normal print:p-0">
        <style>{`
          @media print {
            body { background: white; color: black; }
            #app-navbar, #app-footer, button, #root > :not(#print-worksheet-template) { display: none !important; }
            #print-worksheet-template { display: block !important; width: 100%; max-width: 100%; margin: 0; padding: 1cm; }
          }
        `}</style>

        {/* School Exam Header */}
        <div className="text-center border-b-4 border-double border-black pb-5">
          <h1 className="text-2xl font-bold uppercase tracking-wide">Physics Department Evaluation</h1>
          <h2 className="text-xl font-semibold mt-1">{isPrintMode.title}</h2>
          <div className="grid grid-cols-2 gap-4 mt-4 text-sm font-sans">
            <div className="text-left space-y-1">
              <p><strong>Class:</strong> Class {isPrintMode.classId} Physics Syllabus</p>
              <p><strong>Worksheet Number:</strong> WS-0{isPrintMode.number}</p>
            </div>
            <div className="text-right space-y-1">
              <p><strong>Estimated Time:</strong> {isPrintMode.estimatedTime} Minutes</p>
              <p><strong>Total Marks:</strong> {isPrintMode.questions.reduce((acc, q) => acc + q.marks, 0)} Marks</p>
            </div>
          </div>
        </div>

        {/* Student metadata fields */}
        <div className="grid grid-cols-2 gap-6 border border-slate-300 p-3 text-xs font-sans">
          <p><strong>Student Name:</strong> ____________________________________</p>
          <p><strong>Date:</strong> ___________________________</p>
        </div>

        {/* Questions list */}
        <div className="space-y-8 font-sans">
          {isPrintMode.questions.map((q, idx) => (
            <div key={q.id} className="space-y-3 page-break-inside-avoid">
              <div className="flex justify-between items-start font-medium text-slate-900 border-b border-slate-200 pb-1">
                <span>Q{idx + 1}. {q.question}</span>
                <span className="text-xs font-bold text-slate-500 shrink-0 ml-4">({q.marks} Marks)</span>
              </div>

              {/* MCQ Format layout */}
              {q.type === 'mcq' && q.options && (
                <div className="grid grid-cols-2 gap-4 pl-4 text-sm">
                  {q.options.map((opt, oIdx) => (
                    <div key={oIdx} className="flex items-center gap-2">
                      <span className="border border-black rounded h-4 w-4 inline-block text-center text-xs"></span>
                      <span>({String.fromCharCode(65 + oIdx)}) {opt}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* True/False Layout */}
              {q.type === 'true_false' && (
                <div className="flex gap-6 pl-4 text-sm">
                  <span>( A ) True</span>
                  <span>( B ) False</span>
                </div>
              )}

              {/* Writing Lines for qualitative answers */}
              {(q.type === 'short_answer' || q.type === 'long_answer' || q.type === 'numerical' || q.type === 'fill_blank') && (
                <div className="space-y-2 pl-4">
                  <div className="border-b border-dashed border-slate-400 h-6"></div>
                  {q.type === 'long_answer' && (
                    <>
                      <div className="border-b border-dashed border-slate-400 h-6"></div>
                      <div className="border-b border-dashed border-slate-400 h-6"></div>
                      <div className="border-b border-dashed border-slate-400 h-6"></div>
                    </>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer info */}
        <div className="text-center pt-8 border-t border-slate-200 text-xs text-slate-400">
          Generated automatically by Physics Question Bank. All Rights Reserved.
        </div>
      </div>
    );
  }

  return (
    <div id="worksheets-hub" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* ACTIVE SOLVING WORKSPACE */}
      {activeWorksheet ? (
        <div id="worksheet-workspace" className="space-y-6">
          {/* Workspace Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white/70 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-lg shadow-slate-100/30 dark:shadow-none">
            <div className="space-y-1">
              <button
                id="btn-worksheet-back"
                onClick={() => setActiveWorksheet(null)}
                className="group flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors cursor-pointer"
              >
                <ArrowLeft className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" /> 
                <span>Back to Worksheets List</span>
              </button>
              <h2 className="font-display text-xl sm:text-2xl font-black text-slate-950 dark:text-white mt-1.5 leading-tight">
                {activeWorksheet.title}
              </h2>
              <p className="font-sans text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-semibold">
                Class {activeWorksheet.classId} Physics • WS {activeWorksheet.number}
              </p>
            </div>

            <div className="flex flex-wrap gap-2.5">
              <button
                id="btn-worksheet-print"
                onClick={() => triggerPrintPDF(activeWorksheet)}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2.5 font-sans text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-750 cursor-pointer"
              >
                <Printer className="h-4 w-4 text-blue-500" /> Print / PDF Export
              </button>
              {!isSubmitted && (
                <button
                  id="btn-worksheet-submit"
                  onClick={handleWorksheetSubmit}
                  className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2.5 font-sans text-xs font-bold text-white shadow-md shadow-blue-500/15 hover:bg-blue-700 cursor-pointer transition-all hover:scale-101"
                >
                  <CheckCircle className="h-4 w-4" /> Submit Worksheet
                </button>
              )}
              {isSubmitted && (
                <button
                  id="btn-worksheet-reset"
                  onClick={() => handleStartWorksheet(activeWorksheet)}
                  className="flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 text-blue-700 px-4 py-2.5 font-sans text-xs font-bold dark:border-blue-900 dark:bg-blue-950/20 dark:text-blue-400 cursor-pointer"
                >
                  <RotateCcw className="h-4 w-4 animate-spin-slow" /> Redo Worksheet
                </button>
              )}
            </div>
          </div>

          {/* Questions Render List */}
          <div className="space-y-6">
            {activeWorksheet.questions.map((q, idx) => (
              <div key={q.id} className="relative">
                <span className="absolute -left-3 top-6 flex h-8 w-8 items-center justify-center rounded-xl bg-slate-100 border border-slate-200/60 text-slate-700 font-display text-sm font-black dark:bg-slate-800 dark:border-slate-800 dark:text-slate-300 shadow-sm z-10">
                  {idx + 1}
                </span>
                <div className="pl-7">
                  <QuestionCard
                    question={q}
                    submittedAnswer={worksheetAnswers[q.id] || ''}
                    isSubmitted={isSubmitted}
                    onSubmit={(ans) => handleAnswerChange(q.id, ans)}
                    showResultsInline={isSubmitted}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Submission callout */}
          {!isSubmitted && (
            <div className="rounded-2xl border border-blue-100 bg-blue-50/20 p-6 text-center dark:border-blue-950/30 dark:bg-blue-950/10 backdrop-blur-sm">
              <AlertCircle className="h-7 w-7 text-blue-500 mx-auto mb-3" />
              <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">Ready to evaluate?</h3>
              <p className="font-sans text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto font-medium">
                Once finished typing and selecting your answers, click submit to instantly evaluate all worksheets.
              </p>
              <button
                id="btn-worksheet-bottom-submit"
                onClick={handleWorksheetSubmit}
                className="mt-4 rounded-xl bg-blue-600 px-6 py-2.5 font-sans text-xs font-bold text-white shadow-md shadow-blue-500/10 hover:bg-blue-700 cursor-pointer"
              >
                Evaluate Worksheet Answers
              </button>
            </div>
          )}
        </div>
      ) : (
        /* WORKSHEETS LIST HUB */
        <div className="space-y-8">
          <div>
            <h1 className="font-display text-3xl font-black tracking-tight text-slate-950 dark:text-white">
              Syllabus Worksheets
            </h1>
            <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">
              Test complete chapters offline with physical PDF printable worksheets or complete them interactively below.
            </p>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-4">
            <span className="font-sans text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 mr-2">
              Filter by Class:
            </span>
            <button
              onClick={() => setSelectedClass('all')}
              className={`rounded-xl px-4 py-2 font-sans text-xs font-bold border transition-all cursor-pointer ${
                selectedClass === 'all'
                  ? 'border-blue-600 bg-blue-600 text-white shadow-md shadow-blue-500/10'
                  : 'border-slate-200 bg-white text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-850'
              }`}
            >
              All Classes
            </button>
            {[6, 7, 8, 9, 10].map(cNum => (
              <button
                key={cNum}
                onClick={() => setSelectedClass(cNum)}
                className={`rounded-xl px-4 py-2 font-sans text-xs font-bold border transition-all cursor-pointer ${
                  selectedClass === cNum
                    ? 'border-blue-600 bg-blue-600 text-white shadow-md shadow-blue-500/10'
                    : 'border-slate-200 bg-white text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-850'
                }`}
              >
                Class {cNum}
              </button>
            ))}
          </div>

          {/* Cards Grid */}
          <div id="worksheets-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredWorksheets.map((ws) => {
              const totalMarks = ws.questions.reduce((acc, q) => acc + q.marks, 0);
              const isCompleted = completedWorksheets.includes(ws.id);

              return (
                <div
                  key={ws.id}
                  id={`worksheet-card-${ws.id}`}
                  className="group relative rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 hover:shadow-xl hover:border-blue-500/50 hover:-translate-y-1 transition-all duration-300 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col justify-between h-[280px]"
                >
                  {isCompleted && (
                    <div className="absolute top-4.5 right-4.5 flex items-center gap-1 text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/40 text-[9px] font-bold uppercase tracking-wider">
                      <Award className="h-3 w-3" /> Completed
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="font-sans text-[10px] font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                        Worksheet 0{ws.number}
                      </span>
                      <span className="text-slate-300 dark:text-slate-700">•</span>
                      <span className={`rounded border px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider ${difficultyColors[ws.difficulty]}`}>
                        {ws.difficulty}
                      </span>
                    </div>

                    <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200 leading-snug line-clamp-2">
                      {ws.title}
                    </h3>
                  </div>

                  <div>
                    <div className="grid grid-cols-3 gap-2 border-y border-slate-100 dark:border-slate-850/50 py-3 my-4 text-center">
                      <div>
                        <span className="block font-mono text-sm font-bold text-slate-800 dark:text-white">{ws.questions.length}</span>
                        <span className="font-sans text-[10px] font-medium text-slate-400">Questions</span>
                      </div>
                      <div>
                        <span className="block font-mono text-sm font-bold text-slate-800 dark:text-white">{totalMarks}</span>
                        <span className="font-sans text-[10px] font-medium text-slate-400">Total Marks</span>
                      </div>
                      <div>
                        <span className="block font-mono text-sm font-bold text-slate-800 dark:text-white flex items-center justify-center gap-0.5">
                          <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0" /> {ws.estimatedTime}m
                        </span>
                        <span className="font-sans text-[10px] font-medium text-slate-400">Time Limit</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        id={`btn-ws-start-${ws.id}`}
                        onClick={() => handleStartWorksheet(ws)}
                        className="rounded-xl bg-blue-600 text-white font-sans text-xs font-bold py-2.5 shadow-md shadow-blue-500/10 hover:bg-blue-700 transition-all cursor-pointer text-center"
                      >
                        Start Worksheet
                      </button>
                      <button
                        id={`btn-ws-pdf-${ws.id}`}
                        onClick={() => triggerPrintPDF(ws)}
                        className="rounded-xl border border-slate-200 bg-white text-slate-700 font-sans text-xs font-bold py-2.5 hover:bg-slate-50 transition-all cursor-pointer flex items-center justify-center gap-1.5 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-750"
                      >
                        <Download className="h-3.5 w-3.5 text-blue-500" /> PDF / Print
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
