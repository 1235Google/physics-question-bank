import React, { useState, useRef, useEffect } from 'react';
import { Upload, X, FileText, Loader2, CheckCircle, AlertCircle, Save, Edit, Trash2, Copy, AlertTriangle, Layers, Percent, Download } from 'lucide-react';
import { Question } from '../types';
import { useData } from '../context/DataContext';
import { addQuestionsBatch } from '../lib/db';

type ProcessStep = 'idle' | 'uploading' | 'analyzing' | 'completed' | 'error';
type DuplicateAction = 'skip' | 'replace' | 'keep';

interface ExtractedQuestion extends Question {
  confidence?: number;
  duplicateMatchId?: string;
  duplicateAction?: DuplicateAction;
}

export default function PdfUploader() {
  const { questions: EXISTING_QUESTIONS, refreshData } = useData();
  const [file, setFile] = useState<File | null>(null);
  
  const [step, setStep] = useState<ProcessStep>('idle');
  const [progressMsg, setProgressMsg] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const [extractedQuestions, setExtractedQuestions] = useState<ExtractedQuestion[]>([]);
  const [reviewMode, setReviewMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [saving, setSaving] = useState(false);
  const [importReport, setImportReport] = useState<any>(null);

  // Fake progress animation
  useEffect(() => {
    let interval: any;
    if (step === 'analyzing') {
      const messages = [
        "Reading Pages...",
        "Extracting Questions...",
        "Finding MCQs...",
        "Finding Numericals...",
        "Detecting Answers...",
        "Checking Duplicates...",
        "Finalizing..."
      ];
      let i = 0;
      setProgressMsg(messages[0]);
      interval = setInterval(() => {
        i++;
        if (i < messages.length) {
          setProgressMsg(messages[i]);
        }
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [step]);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type === 'application/pdf') {
        setFile(droppedFile);
        setError(null);
        setStep('idle');
      } else {
        setError('Only PDF files are supported.');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
      setError(null);
      setStep('idle');
    }
  };

  const uploadAndProcess = async () => {
    if (!file) return;
    setStep('uploading');
    setProgressMsg('Uploading PDF...');
    setError(null);

    const formData = new FormData();
    formData.append('pdf', file);

    try {
      const res = await fetch('/api/upload-pdf', {
        method: 'POST',
        body: formData,
      });

      setStep('analyzing');
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process PDF');
      }

      const formattedQuestions = data.questions.map((q: any, index: number) => {
        // duplicate detection
        const match = EXISTING_QUESTIONS.find(ex => ex.question.trim().toLowerCase() === q.question.trim().toLowerCase());
        
        return {
          ...q,
          id: `pdf_\${Date.now()}_\${index}`,
          options: q.options || [],
          tags: q.tags || [],
          duplicateMatchId: match ? match.id : undefined,
          duplicateAction: match ? 'skip' : undefined
        };
      });

      setExtractedQuestions(formattedQuestions);
      setStep('completed');
      setReviewMode(true);
    } catch (err: any) {
      setError(err.message);
      setStep('error');
    }
  };

  const handleSaveAll = async () => {
    setSaving(true);
    const startTime = Date.now();
    let imported = 0;
    let skipped = 0;
    let errors = 0;

    const toSave: Question[] = [];

    for (const q of extractedQuestions) {
      if (q.duplicateMatchId) {
        if (q.duplicateAction === 'skip') {
          skipped++;
          continue;
        } else if (q.duplicateAction === 'replace') {
          // Keep the existing ID but overwrite content
          const cleanQ = { ...q, id: q.duplicateMatchId };
          delete cleanQ.duplicateMatchId;
          delete cleanQ.duplicateAction;
          delete cleanQ.confidence;
          toSave.push(cleanQ as Question);
          imported++;
        } else if (q.duplicateAction === 'keep') {
          // Keep as new ID
          const cleanQ = { ...q };
          delete cleanQ.duplicateMatchId;
          delete cleanQ.duplicateAction;
          delete cleanQ.confidence;
          toSave.push(cleanQ as Question);
          imported++;
        }
      } else {
        const cleanQ = { ...q };
        delete cleanQ.duplicateMatchId;
        delete cleanQ.duplicateAction;
        delete cleanQ.confidence;
        toSave.push(cleanQ as Question);
        imported++;
      }
    }

    try {
      // Use batch import
      if (toSave.length > 0) {
        await addQuestionsBatch(toSave);
      }
      await refreshData();
      
      setImportReport({
        fileName: file?.name,
        found: extractedQuestions.length,
        imported,
        skipped,
        errors,
        time: ((Date.now() - startTime) / 1000).toFixed(1)
      });
      
      setSaving(false);
      setReviewMode(false);
      setStep('idle');
    } catch (e: any) {
      console.error(e);
      alert('Error saving questions: ' + e.message);
      setSaving(false);
    }
  };

  const reset = () => {
    setFile(null);
    setExtractedQuestions([]);
    setReviewMode(false);
    setError(null);
    setStep('idle');
    setImportReport(null);
  };

  const updateQuestion = (index: number, field: string, value: any) => {
    const updated = [...extractedQuestions];
    updated[index] = { ...updated[index], [field]: value };
    setExtractedQuestions(updated);
  };

  const deleteExtracted = (index: number) => {
    const updated = [...extractedQuestions];
    updated.splice(index, 1);
    setExtractedQuestions(updated);
  };

  const duplicateExtracted = (index: number) => {
    const updated = [...extractedQuestions];
    const newQ = { ...updated[index], id: `pdf_dup_\${Date.now()}` };
    updated.splice(index + 1, 0, newQ);
    setExtractedQuestions(updated);
  };

  if (importReport) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-lg max-w-2xl mx-auto text-center">
        <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
        </div>
        <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-6">Import Complete</h2>
        
        <div className="grid grid-cols-2 gap-4 mb-8 text-left">
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl">
            <p className="text-sm text-slate-500 font-medium mb-1">PDF File</p>
            <p className="font-bold text-slate-800 dark:text-white truncate">{importReport.fileName}</p>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl">
            <p className="text-sm text-slate-500 font-medium mb-1">Processing Time</p>
            <p className="font-bold text-slate-800 dark:text-white">{importReport.time}s</p>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl">
            <p className="text-sm text-slate-500 font-medium mb-1">Questions Found</p>
            <p className="font-bold text-slate-800 dark:text-white">{importReport.found}</p>
          </div>
          <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-800/50">
            <p className="text-sm text-indigo-600 dark:text-indigo-400 font-bold mb-1">Imported</p>
            <p className="font-black text-2xl text-indigo-700 dark:text-indigo-300">{importReport.imported}</p>
          </div>
          <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-2xl">
            <p className="text-sm text-amber-600 dark:text-amber-400 font-medium mb-1">Duplicates Skipped</p>
            <p className="font-bold text-amber-700 dark:text-amber-300">{importReport.skipped}</p>
          </div>
          <div className="bg-rose-50 dark:bg-rose-900/20 p-4 rounded-2xl">
            <p className="text-sm text-rose-600 dark:text-rose-400 font-medium mb-1">Errors</p>
            <p className="font-bold text-rose-700 dark:text-rose-300">{importReport.errors}</p>
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <button onClick={reset} className="px-6 py-3 bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-xl font-bold hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors">
            Upload Another
          </button>
        </div>
      </div>
    );
  }

  if (reviewMode) {
    return (
      <div className="bg-slate-50 dark:bg-slate-900 rounded-3xl p-6 shadow-inner min-h-[600px]">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 sticky top-[56px] bg-slate-50 dark:bg-slate-900 z-20 py-4 -my-4">
          <div>
            <h3 className="text-xl font-black text-slate-800 dark:text-white">Review Extracted Questions</h3>
            <p className="text-sm text-slate-500 font-medium">Found {extractedQuestions.length} questions in {file?.name}</p>
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <button onClick={reset} disabled={saving} className="w-full md:w-auto h-12 px-4 flex items-center justify-center text-slate-600 bg-slate-200 dark:bg-slate-800 dark:text-slate-300 rounded-xl hover:bg-slate-300 dark:hover:bg-slate-700 font-medium transition-colors">
              Cancel
            </button>
            <button onClick={handleSaveAll} disabled={saving || extractedQuestions.length === 0} className="w-full md:w-auto h-12 px-6 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 justify-center font-bold flex items-center gap-2 shadow-lg shadow-indigo-200 dark:shadow-none transition-colors">
              {saving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
              {saving ? 'Importing to Firestore...' : 'Import Questions'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {extractedQuestions.map((q, idx) => {
            return (
              <div key={q.id} className={`bg-white dark:bg-slate-800 p-6 rounded-2xl border shadow-sm \${q.duplicateMatchId ? 'border-amber-300 dark:border-amber-700/50 ring-2 ring-amber-100 dark:ring-amber-900/30' : 'border-slate-200 dark:border-slate-700'}`}>
                
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    {q.confidence !== undefined && (
                      <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-md \${q.confidence < 70 ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'}`}>
                        <Percent className="h-3 w-3" />
                        Conf: {Math.round(q.confidence)}%
                        {q.confidence < 70 && ' (Needs Review)'}
                      </div>
                    )}
                    {q.duplicateMatchId && (
                      <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-lg border border-amber-200 dark:border-amber-800/50">
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                        <span className="text-sm font-bold text-amber-700 dark:text-amber-400">Already Exists</span>
                        <select 
                          value={q.duplicateAction} 
                          onChange={(e) => updateQuestion(idx, 'duplicateAction', e.target.value)}
                          className="ml-2 text-sm bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded p-1 text-slate-700 dark:text-slate-200 font-medium outline-none"
                        >
                          <option value="skip">Skip</option>
                          <option value="replace">Replace</option>
                          <option value="keep">Keep Both</option>
                        </select>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => duplicateExtracted(idx)} className="p-2 text-slate-500 bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors" title="Duplicate">
                      <Copy className="h-4 w-4" />
                    </button>
                    <button onClick={() => deleteExtracted(idx)} className="p-2 text-rose-500 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 rounded-lg transition-colors" title="Delete">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1 space-y-4">
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Question</label>
                      <textarea 
                        className="w-full text-base font-medium p-3 bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl dark:bg-slate-900 resize-y min-h-[80px] focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                        value={q.question}
                        onChange={(e) => updateQuestion(idx, 'question', e.target.value)}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Type</label>
                        <select 
                          className="w-full h-12 p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                          value={q.type}
                          onChange={(e) => updateQuestion(idx, 'type', e.target.value)}
                        >
                          <option value="mcq">MCQ</option>
                          <option value="tf">True/False</option>
                          <option value="fib">Fill in the Blanks</option>
                          <option value="vsa">Very Short Answer</option>
                          <option value="sa">Short Answer</option>
                          <option value="la">Long Answer</option>
                          <option value="numerical">Numerical</option>
                          <option value="assertion">Assertion & Reason</option>
                          <option value="match">Match the Following</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Difficulty</label>
                        <select 
                          className="w-full h-12 p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                          value={q.difficulty}
                          onChange={(e) => updateQuestion(idx, 'difficulty', e.target.value)}
                        >
                          <option value="easy">Easy</option>
                          <option value="medium">Medium</option>
                          <option value="hard">Hard</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Chapter</label>
                        <input 
                          type="text"
                          className="w-full h-12 p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                          value={q.chapter}
                          onChange={(e) => updateQuestion(idx, 'chapter', e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Marks</label>
                        <input 
                          type="number"
                          className="w-full h-12 p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                          value={q.marks || 1}
                          onChange={(e) => updateQuestion(idx, 'marks', parseInt(e.target.value) || 1)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {q.type === 'mcq' && (
                        <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 block">Options</label>
                          <div className="space-y-2">
                            {(q.options?.length ? q.options : ['','','','']).map((opt, oIdx) => (
                              <div key={oIdx} className="flex items-center gap-2">
                                <span className="text-xs font-bold text-slate-400 w-4">{String.fromCharCode(65 + oIdx)}.</span>
                                <input 
                                  type="text"
                                  className="flex-1 p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  value={opt}
                                  onChange={(e) => {
                                    const newOpts = [...(q.options || ['','','',''])];
                                    newOpts[oIdx] = e.target.value;
                                    updateQuestion(idx, 'options', newOpts);
                                  }}
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="space-y-4">
                        <div>
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Correct Answer</label>
                          <input 
                            type="text"
                            className="w-full h-12 p-2.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                            value={q.answer}
                            onChange={(e) => updateQuestion(idx, 'answer', e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Explanation</label>
                          <textarea 
                            className="w-full h-12 p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none min-h-[80px]"
                            value={q.explanation || ''}
                            onChange={(e) => updateQuestion(idx, 'explanation', e.target.value)}
                            placeholder="Optional explanation..."
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-xl shadow-slate-100/50 dark:shadow-none w-full max-w-4xl mx-auto backdrop-blur-xl bg-opacity-80">
      <div className="text-center mb-10">
        <div className="bg-indigo-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-lg shadow-indigo-200 dark:shadow-indigo-900/50 transform rotate-3">
          <Layers className="h-8 w-8 text-white -rotate-3" />
        </div>
        <h2 className="text-3xl font-black text-slate-800 dark:text-white tracking-tight">Smart PDF Import</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">Extract structured questions automatically from your worksheets.</p>
      </div>

      <div 
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleFileDrop}
        className={`border-2 border-dashed rounded-3xl p-12 text-center transition-all duration-300 ease-in-out \${
          file 
            ? 'border-indigo-400 bg-indigo-50/50 dark:bg-indigo-900/10' 
            : step === 'uploading' || step === 'analyzing'
              ? 'border-slate-200 bg-slate-50 opacity-70 pointer-events-none'
              : 'border-slate-300 dark:border-slate-700 hover:border-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
        }`}
      >
        <input 
          type="file" 
          accept=".pdf" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          className="hidden" 
        />
        
        {step === 'uploading' || step === 'analyzing' ? (
          <div className="flex flex-col items-center py-6 animate-pulse">
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-200 dark:bg-indigo-900 rounded-full blur-xl animate-ping opacity-50"></div>
              <Loader2 className="h-14 w-14 text-indigo-600 dark:text-indigo-400 animate-spin relative z-10" />
            </div>
            <h4 className="text-xl font-black text-slate-800 dark:text-white mt-6 mb-2">{progressMsg}</h4>
            <p className="text-sm font-medium text-slate-500">This might take a few moments...</p>
          </div>
        ) : file ? (
          <div className="flex flex-col items-center">
            <div className="bg-emerald-100 dark:bg-emerald-900/30 p-3 rounded-full mb-4">
              <CheckCircle className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
            </div>
            <h4 className="text-lg font-bold text-slate-800 dark:text-slate-200 mb-1">{file.name}</h4>
            <p className="text-sm font-medium text-slate-500 mb-8 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
              {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>
            
            <div className="flex gap-4">
              <button onClick={() => setFile(null)} className="px-6 py-3 rounded-xl text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors">
                Cancel
              </button>
              <button 
                onClick={uploadAndProcess} 
                className="px-8 py-3 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 flex items-center gap-2 transition-transform active:scale-95 shadow-lg shadow-indigo-200 dark:shadow-none"
              >
                <FileText className="h-5 w-5" />
                Process AI Extraction
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center cursor-pointer group" onClick={() => fileInputRef.current?.click()}>
            <div className="bg-slate-100 dark:bg-slate-800 w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/20 group-hover:scale-105 transition-all">
              <Upload className="h-10 w-10 text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors" />
            </div>
            <span className="bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold py-3 px-8 rounded-xl inline-block mb-4 shadow-md hover:shadow-lg transition-all">
              Browse Files
            </span>
            <p className="text-sm font-medium text-slate-400 mb-1">or drag and drop your PDF here</p>
            <p className="text-xs font-medium text-slate-400/70">Secure upload. Max file size: 50MB</p>
          </div>
        )}
      </div>

      {error && (
        <div className="mt-8 p-5 bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800/50 rounded-2xl flex items-start gap-4 animate-in fade-in slide-in-from-bottom-4">
          <div className="bg-rose-100 dark:bg-rose-900/50 p-2 rounded-xl shrink-0">
            <AlertCircle className="h-6 w-6 text-rose-600 dark:text-rose-400" />
          </div>
          <div>
            <span className="font-bold text-rose-800 dark:text-rose-300 block mb-1">Extraction Failed</span>
            <p className="text-sm text-rose-700 dark:text-rose-400/80 font-medium">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="ml-auto text-rose-400 hover:text-rose-600 dark:hover:text-rose-300">
            <X className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
}
