import { useData } from '../context/DataContext';
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Question, Difficulty } from '../types';
import { Timer, ArrowRight, ArrowLeft, Bookmark, CheckCircle, XCircle, Play, RotateCcw, AlertTriangle, ShieldCheck, Clock, Flag, HelpCircle, Sparkles, Link2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface QuizViewProps {
  onQuizCompleted: (attempt: {
    classId: number;
    chapterId: string;
    score: number;
    total: number;
    percentage: number;
    timeTaken: number;
    bookmarkedQuestions?: string[];
  }) => void;
  initialClassId?: number | null;
  initialChapterId?: string | null;
  initialDifficulty?: Difficulty | 'all';
  autoStartQuiz?: boolean;
}

export default function QuizView({
  onQuizCompleted,
  initialClassId,
  initialChapterId,
  initialDifficulty,
  autoStartQuiz
}: QuizViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  // Quiz Stages: 'lobby' | 'active' | 'results'
  const [stage, setStage] = useState<'lobby' | 'active' | 'results'>('lobby');

  // Lobby selections
  const [selectedClass, setSelectedClass] = useState<number>(() => initialClassId ?? 6);
  const [selectedChapter, setSelectedChapter] = useState<string | 'all'>(() => initialChapterId ?? 'all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'all'>(() => initialDifficulty ?? 'all');
  const [selectedLimit, setSelectedLimit] = useState<number>(5);

  // Active quiz state
  const [quizQuestions, setQuizQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [bookmarked, setBookmarked] = useState<Record<string, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(0); // in seconds
  const [totalQuizTime, setTotalQuizTime] = useState(0); // in seconds

  // Timer Ref
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Chapters available based on chosen class in lobby
  const lobbyChapters = useMemo(() => {
    return CHAPTERS_DATA.filter(ch => ch.classId === selectedClass);
  }, [selectedClass]);

  // Adjust chapter selection when class is changed in lobby
  const isFirstMount = useRef(true);
  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    setSelectedChapter('all');
  }, [selectedClass]);

  // Auto-start quiz if flag is provided
  useEffect(() => {
    if (autoStartQuiz && initialClassId) {
      const targetClass = initialClassId;
      const targetChapter = initialChapterId ?? 'all';
      const targetDifficulty = initialDifficulty ?? 'all';

      let pool = PHYSICS_QUESTIONS.filter(q => q.class === targetClass);
      if (targetChapter !== 'all') {
        pool = pool.filter(q => q.chapter === targetChapter);
      }
      if (targetDifficulty !== 'all') {
        pool = pool.filter(q => q.difficulty === targetDifficulty);
      }

      const shuffled = [...pool].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, selectedLimit);

      if (selected.length > 0) {
        const totalSecs = selected.length * 60;
        setQuizQuestions(selected);
        setCurrentIndex(0);
        setAnswers({});
        setBookmarked({});
        setTimeLeft(totalSecs);
        setTotalQuizTime(totalSecs);
        setStage('active');
      }
    }
  }, [autoStartQuiz, initialClassId, initialChapterId, initialDifficulty, selectedLimit]);

  // Start the Quiz
  const handleStartQuiz = () => {
    let pool = PHYSICS_QUESTIONS.filter(q => q.class === selectedClass);
    if (selectedChapter !== 'all') {
      pool = pool.filter(q => q.chapter === selectedChapter);
    }
    if (selectedDifficulty !== 'all') {
      pool = pool.filter(q => q.difficulty === selectedDifficulty);
    }

    // Shuffle pool to ensure random ordering
    const shuffled = [...pool].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, selectedLimit);

    if (selected.length === 0) {
      alert("No questions match the current combination! Please choose different parameters.");
      return;
    }

    // Set quiz conditions: 60 seconds per question
    const totalSecs = selected.length * 60;
    
    setQuizQuestions(selected);
    setCurrentIndex(0);
    setAnswers({});
    setBookmarked({});
    setTimeLeft(totalSecs);
    setTotalQuizTime(totalSecs);
    setStage('active');
  };

  // Timer Tick
  useEffect(() => {
    if (stage === 'active' && timeLeft > 0) {
      timerRef.current = setTimeout(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (stage === 'active' && timeLeft === 0) {
      // Auto-submit on time expiry
      handleForceSubmit();
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [stage, timeLeft]);

  // Submit functions
  const handleForceSubmit = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setStage('results');
    
    // Evaluate results
    let correct = 0;
    quizQuestions.forEach(q => {
      const studentAns = (answers[q.id] || '').trim().toLowerCase();
      const correctAns = q.answer.trim().toLowerCase();
      if (studentAns === correctAns) {
        correct++;
      }
    });

    const finalPercent = Math.round((correct / quizQuestions.length) * 100);
    const secsTaken = totalQuizTime - timeLeft;

    // Gather bookmarked questions
    const sessionBookmarks = Object.keys(bookmarked).filter(k => bookmarked[k]);

    onQuizCompleted({
      classId: selectedClass,
      chapterId: selectedChapter,
      score: correct,
      total: quizQuestions.length,
      percentage: finalPercent,
      timeTaken: secsTaken,
      bookmarkedQuestions: sessionBookmarks
    });
  };

  // Helper formatting for time
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  // Derived Results values
  const resultsData = useMemo(() => {
    if (stage !== 'results') return null;

    let correctCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;

    quizQuestions.forEach(q => {
      const ans = answers[q.id];
      if (!ans) {
        unansweredCount++;
      } else if (ans.trim().toLowerCase() === q.answer.trim().toLowerCase()) {
        correctCount++;
      } else {
        wrongCount++;
      }
    });

    const percentage = Math.round((correctCount / quizQuestions.length) * 100);
    const timeSpent = totalQuizTime - timeLeft;

    return {
      correctCount,
      wrongCount,
      unansweredCount,
      percentage,
      timeSpent
    };
  }, [stage, quizQuestions, answers, timeLeft, totalQuizTime]);

  const activeQuestion = quizQuestions[currentIndex];

  return (
    <div id="quiz-hub" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* LOBBY STAGE */}
      {stage === 'lobby' && (
        <div id="quiz-lobby" className="mx-auto max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl">
          <div className="text-center mb-8">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 dark:bg-blue-500 mb-4">
              <Clock className="h-7 w-7 animate-pulse" />
            </div>
            <h1 className="font-sans text-2xl md:text-3xl font-extrabold tracking-tight text-slate-950 dark:text-white">
              Physics Test Generator
            </h1>
            <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto">
              Set your target class, chapter, and test size to launch a randomized timed physics quiz session.
            </p>
          </div>

          <div className="space-y-5">
            {/* Class */}
            <div className="space-y-2">
              <label className="font-sans text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Select Class
              </label>
              <div className="grid grid-cols-5 gap-2">
                {[6, 7, 8, 9, 10].map(cNum => (
                  <button
                    key={cNum}
                    type="button"
                    onClick={() => setSelectedClass(cNum)}
                    className={`rounded-xl py-3 text-center font-sans text-sm font-bold border transition-all ${
                      selectedClass === cNum
                        ? 'border-blue-600 bg-blue-600 text-white shadow-md shadow-blue-500/20'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-300 dark:hover:bg-slate-800'
                    }`}
                  >
                    C{cNum}
                  </button>
                ))}
              </div>
            </div>

            {/* Chapter Selection */}
            <div className="space-y-2">
              <label className="font-sans text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Physics Chapter
              </label>
              <select
                id="quiz-setup-chapter"
                value={selectedChapter}
                onChange={(e) => setSelectedChapter(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 font-sans text-sm font-medium text-slate-800 focus:outline-none dark:border-slate-800 dark:bg-slate-800/40 dark:text-white"
              >
                <option value="all">All Chapters (Randomized Pool)</option>
                {lobbyChapters.map(ch => (
                  <option key={ch.id} value={ch.id}>{ch.name}</option>
                ))}
              </select>
            </div>

            {/* Difficulty & Size in double grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="font-sans text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Difficulty Level
                </label>
                <select
                  id="quiz-setup-difficulty"
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value as Difficulty | 'all')}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 font-sans text-sm font-medium text-slate-800 focus:outline-none dark:border-slate-800 dark:bg-slate-800/40 dark:text-white"
                >
                  <option value="all">Any Difficulty</option>
                  <option value="easy">Easy Only</option>
                  <option value="medium">Medium Only</option>
                  <option value="hard">Hard Only</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="font-sans text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Test Size (Questions)
                </label>
                <select
                  id="quiz-setup-limit"
                  value={selectedLimit}
                  onChange={(e) => setSelectedLimit(parseInt(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 font-sans text-sm font-medium text-slate-800 focus:outline-none dark:border-slate-800 dark:bg-slate-800/40 dark:text-white"
                >
                  <option value={5}>5 Questions</option>
                  <option value={10}>10 Questions</option>
                  <option value={15}>15 Questions</option>
                  <option value={20}>20 Questions</option>
                </select>
              </div>
            </div>

            {/* Launch CTA */}
            <div className="pt-4">
              <button
                id="btn-launch-quiz"
                onClick={handleStartQuiz}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 py-4 font-sans text-base font-bold text-white shadow-lg shadow-blue-500/20 hover:bg-blue-700 hover:shadow-xl transition-all cursor-pointer"
              >
                <Play className="h-5 w-5" />
                <span>Begin Timed Quiz</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ACTIVE TEST STAGE */}
      {stage === 'active' && activeQuestion && (
        <div id="quiz-active-session" className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Question Column */}
          <div className="lg:col-span-3 space-y-6">
            {/* Header: Progress, Timer */}
            <div className="flex flex-col gap-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2.5">
                  <span className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100">
                    Question {currentIndex + 1} of {quizQuestions.length}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">|</span>
                  <button
                    id="btn-quiz-bookmark"
                    onClick={() => setBookmarked(prev => ({ ...prev, [activeQuestion.id]: !prev[activeQuestion.id] }))}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-sans text-xs font-bold border transition-all ${
                      bookmarked[activeQuestion.id]
                        ? 'border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-900/40 dark:bg-amber-950/20 dark:text-amber-400'
                        : 'border-slate-200 bg-white text-slate-500 hover:text-slate-700 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400'
                    }`}
                  >
                    <Bookmark className={`h-3.5 w-3.5 ${bookmarked[activeQuestion.id] ? 'fill-amber-600' : ''}`} />
                    <span>{bookmarked[activeQuestion.id] ? 'Bookmarked' : 'Review Later'}</span>
                  </button>
                </div>

                {/* Countdown Timer */}
                <div className={`flex items-center gap-2 font-sans font-bold px-4 py-2 rounded-xl border ${
                  timeLeft < 30
                    ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-950/20 dark:border-rose-900/40 dark:text-rose-400 animate-pulse'
                    : 'bg-blue-50 border-blue-100 text-blue-600 dark:bg-blue-950/20 dark:border-blue-900/40 dark:text-blue-400'
                }`}>
                  <Timer className="h-4.5 w-4.5" />
                  <span className="text-sm font-mono tracking-wider">{formatTime(timeLeft)}</span>
                </div>
              </div>
              
              {/* Linear Progress Bar */}
              <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <motion.div 
                  className="h-full bg-blue-600 dark:bg-blue-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentIndex + 1) / quizQuestions.length) * 100}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Custom styled card to match QuestionCard style but without immediate evaluation */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeQuestion.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="rounded-2xl border border-slate-200 bg-white p-5 md:p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4 dark:border-slate-800">
                  <span className="rounded-full bg-blue-50 border border-blue-100 px-2.5 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/30 dark:text-blue-400 dark:border-blue-900/50">
                    {activeQuestion.type.toUpperCase()} • {activeQuestion.marks} Marks
                  </span>
                  {bookmarked[activeQuestion.id] && (
                    <span className="flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-400">
                      <Flag className="h-3.5 w-3.5 fill-amber-500" /> Review Later
                    </span>
                  )}
                </div>

                <p className="font-sans text-base md:text-lg font-medium text-slate-800 dark:text-slate-100 leading-relaxed mb-6">
                  {activeQuestion.text}
                </p>

                {/* Input options based on type */}
                <div className="space-y-3">
                  {activeQuestion.type === 'mcq' && activeQuestion.options && (
                    <div className="grid grid-cols-1 gap-3">
                      {activeQuestion.options.map((opt, idx) => {
                        const letter = String.fromCharCode(65 + idx);
                        const isSelected = answers[activeQuestion.id] === opt;
                        return (
                          <motion.button
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.99 }}
                            key={idx}
                            onClick={() => setAnswers(prev => ({ ...prev, [activeQuestion.id]: opt }))}
                            className={`flex items-center w-full rounded-xl border p-3.5 text-left font-sans text-sm font-medium transition-all duration-150 cursor-pointer ${
                              isSelected
                                ? 'border-blue-500 bg-blue-50/50 text-blue-700 ring-2 ring-blue-500/25 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300'
                                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-300'
                            }`}
                          >
                            <span className={`mr-3.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border text-xs font-bold ${
                              isSelected
                                ? 'border-blue-600 bg-blue-600 text-white'
                                : 'border-slate-300 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-800'
                            }`}>
                              {letter}
                            </span>
                            <span className="leading-snug">{opt}</span>
                          </motion.button>
                        );
                      })}
                    </div>
                  )}

                  {activeQuestion.type === 'true_false' && (
                    <div className="flex gap-4">
                      {['True', 'False'].map((val, idx) => {
                        const isSelected = answers[activeQuestion.id] === val;
                        return (
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            key={idx}
                            onClick={() => setAnswers(prev => ({ ...prev, [activeQuestion.id]: val }))}
                            className={`flex-1 rounded-xl border p-4 text-center font-sans text-base font-bold transition-all cursor-pointer ${
                              isSelected
                                ? 'border-blue-500 bg-blue-50/50 text-blue-700 ring-2 ring-blue-500/25 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300'
                                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-300'
                            }`}
                          >
                            {val}
                          </motion.button>
                        );
                      })}
                    </div>
                  )}

                  {(activeQuestion.type === 'fill_blank' || activeQuestion.type === 'numerical') && (
                    <input
                      type="text"
                      value={answers[activeQuestion.id] || ''}
                      onChange={(e) => setAnswers(prev => ({ ...prev, [activeQuestion.id]: e.target.value }))}
                      placeholder="Type your final answer here..."
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 font-sans text-sm font-medium text-slate-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-slate-800 dark:bg-slate-800/40 dark:text-white"
                    />
                  )}

                  {(activeQuestion.type === 'short_answer' || activeQuestion.type === 'long_answer') && (
                    <textarea
                      value={answers[activeQuestion.id] || ''}
                      onChange={(e) => setAnswers(prev => ({ ...prev, [activeQuestion.id]: e.target.value }))}
                      rows={activeQuestion.type === 'long_answer' ? 6 : 4}
                      placeholder="Type complete qualitative proof or justification..."
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 font-sans text-sm font-medium text-slate-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-slate-800 dark:bg-slate-800/40 dark:text-white"
                    />
                  )}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between">
              <button
                id="btn-quiz-prev"
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex(prev => prev - 1)}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2.5 font-sans text-sm font-bold text-slate-700 transition-all hover:bg-slate-50 disabled:opacity-40 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
              >
                <ArrowLeft className="h-4 w-4" /> Previous
              </button>

              <div className="flex items-center gap-2">
                <button
                  id="btn-quiz-skip"
                  onClick={() => setCurrentIndex(prev => Math.min(quizQuestions.length - 1, prev + 1))}
                  className="rounded-xl px-4 py-2.5 font-sans text-sm font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                >
                  Skip
                </button>

                {currentIndex === quizQuestions.length - 1 ? (
                  <button
                    id="btn-quiz-finish"
                    onClick={handleForceSubmit}
                    className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-6 py-2.5 font-sans text-sm font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700 transition-all cursor-pointer"
                  >
                    Finish Test
                  </button>
                ) : (
                  <button
                    id="btn-quiz-next"
                    onClick={() => setCurrentIndex(prev => prev + 1)}
                    className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2.5 font-sans text-sm font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700 transition-all cursor-pointer"
                  >
                    Next <ArrowRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Test Status/Navigator Sidebar */}
          <div className="lg:col-span-1 space-y-5 bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="font-sans text-sm font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-3">
              Test Navigation
            </h3>

            <div className="grid grid-cols-5 gap-2.5">
              {quizQuestions.map((q, idx) => {
                const isCurrent = currentIndex === idx;
                const isAnswered = !!answers[q.id];
                const isBookmarked = !!bookmarked[q.id];

                let indicatorStyle = 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400';
                if (isCurrent) {
                  indicatorStyle = 'border-blue-600 bg-blue-600 text-white font-extrabold ring-2 ring-blue-500/20';
                } else if (isBookmarked) {
                  indicatorStyle = 'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400';
                } else if (isAnswered) {
                  indicatorStyle = 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950/20 dark:text-emerald-400';
                }

                return (
                  <button
                    key={q.id}
                    id={`quiz-grid-${idx}`}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-9 w-9 rounded-lg border text-xs font-bold transition-all flex items-center justify-center ${indicatorStyle}`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Indicator Legend */}
            <div className="space-y-2 pt-4 border-t border-slate-200 dark:border-slate-800 font-sans text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-blue-600 inline-block" />
                <span>Current Question</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 inline-block" />
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-amber-500 inline-block" />
                <span>Review Later (Bookmarked)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-slate-300 inline-block" />
                <span>Skipped / Empty</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QUIZ RESULTS STAGE */}
      {stage === 'results' && resultsData && (
        <div id="quiz-results" className="space-y-8">
          {/* Summary Hero Card */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-col md:flex-row items-center gap-8 justify-between">
              <div className="space-y-4 text-center md:text-left">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
                  <ShieldCheck className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="font-sans text-2xl md:text-3xl font-extrabold tracking-tight text-slate-950 dark:text-white">
                    {resultsData.percentage >= 80 ? 'Outstanding Performance! 🎉' : 'Quiz Evaluation Finished!'}
                  </h2>
                  <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-md font-medium">
                    {resultsData.percentage === 100 && "Perfect Score! You are a physics genius! 🌟"}
                    {resultsData.percentage >= 80 && resultsData.percentage < 100 && "Excellent work! You have a solid grasp of these concepts! 🚀"}
                    {resultsData.percentage >= 60 && resultsData.percentage < 80 && "Good job! A little more review and you'll be an expert! 📚"}
                    {resultsData.percentage < 60 && "Keep practicing! Every mistake is a learning opportunity! 💪"}
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                  <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 text-sm font-semibold bg-slate-50 dark:bg-slate-800/50 px-3.5 py-2 rounded-xl border border-slate-100 dark:border-slate-800">
                    <CheckCircle className="h-4.5 w-4.5 text-emerald-500" />
                    <span>{resultsData.correctCount} Correct</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 text-sm font-semibold bg-slate-50 dark:bg-slate-800/50 px-3.5 py-2 rounded-xl border border-slate-100 dark:border-slate-800">
                    <XCircle className="h-4.5 w-4.5 text-rose-500" />
                    <span>{resultsData.wrongCount} Incorrect</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 text-sm font-semibold bg-slate-50 dark:bg-slate-800/50 px-3.5 py-2 rounded-xl border border-slate-100 dark:border-slate-800">
                    <Clock className="h-4.5 w-4.5 text-blue-500" />
                    <span>{formatTime(resultsData.timeSpent)} Taken</span>
                  </div>
                </div>
              </div>

              {/* Graphical Circular Percent Gauge */}
              <div className="flex flex-col items-center shrink-0">
                <div className="relative flex items-center justify-center h-40 w-40">
                  <svg className="absolute transform -rotate-90 w-full h-full">
                    <circle
                      cx="80"
                      cy="80"
                      r="65"
                      className="text-slate-100 dark:text-slate-800"
                      strokeWidth="12"
                      fill="transparent"
                      stroke="currentColor"
                    />
                    <circle
                      cx="80"
                      cy="80"
                      r="65"
                      className="text-blue-600 dark:text-blue-500 transition-all duration-1000"
                      strokeWidth="12"
                      fill="transparent"
                      strokeDasharray={408}
                      strokeDashoffset={408 - (408 * resultsData.percentage) / 100}
                      stroke="currentColor"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="flex flex-col items-center">
                    <span className="font-sans text-3xl font-extrabold text-slate-900 dark:text-white">
                      {resultsData.percentage}%
                    </span>
                    <span className="font-sans text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                      {resultsData.correctCount} / {quizQuestions.length} Score
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex justify-center sm:justify-start">
              <button
                id="btn-quiz-retry"
                onClick={() => setStage('lobby')}
                className="flex items-center gap-2 rounded-2xl bg-blue-600 px-6 py-3.5 font-sans text-sm font-bold text-white shadow-md shadow-blue-500/15 hover:bg-blue-700 transition-all"
              >
                <RotateCcw className="h-4.5 w-4.5" /> Try Another Quiz
              </button>
            </div>
          </div>

          {/* Deep Question-by-Question Review List */}
          <div className="space-y-5">
            <h3 className="font-sans text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-blue-600" />
              <span>Syllabus Concept Review</span>
            </h3>

            {quizQuestions.map((q, idx) => {
              const studentAns = answers[q.id] || '(Skipped)';
              const isCorrectAnswer = studentAns.trim().toLowerCase() === q.answer.trim().toLowerCase();

              return (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  key={q.id}
                  id={`review-card-${idx}`}
                  className={`rounded-2xl border bg-white p-5 md:p-6 shadow-sm transition-all dark:bg-slate-900 ${
                    isCorrectAnswer
                      ? 'border-emerald-100 dark:border-emerald-950/40'
                      : 'border-rose-100 dark:border-rose-950/40'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4 dark:border-slate-800">
                    <span className="font-sans text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Question {idx + 1} • {q.difficulty.toUpperCase()}
                    </span>
                    {isCorrectAnswer ? (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/20 px-2.5 py-1 rounded-full">
                        <CheckCircle className="h-3.5 w-3.5" /> Correct
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-2.5 py-1 rounded-full">
                        <XCircle className="h-3.5 w-3.5" /> Incorrect
                      </span>
                    )}
                  </div>

                  <p className="font-sans text-base font-medium text-slate-800 dark:text-slate-100 leading-relaxed mb-4">
                    {q.question}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 text-sm font-medium">
                    <div className="rounded-xl bg-slate-50 dark:bg-slate-800/40 p-3">
                      <span className="text-xs text-slate-400 block font-bold uppercase tracking-wider">Your Answer:</span>
                      <span className={`text-sm font-semibold mt-1 block ${isCorrectAnswer ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                        {studentAns}
                      </span>
                    </div>
                    <div className="rounded-xl bg-slate-50 dark:bg-slate-800/40 p-3">
                      <span className="text-xs text-slate-400 block font-bold uppercase tracking-wider">Correct Answer:</span>
                      <span className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 mt-1 block">
                        {q.answer}
                      </span>
                    </div>
                  </div>

                  <div className="rounded-xl bg-blue-50/30 dark:bg-blue-950/15 border border-blue-50 dark:border-blue-950/30 p-4.5">
                    <p className="font-sans text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      <strong className="text-slate-800 dark:text-slate-100 font-bold">Scientific Rationale: </strong>
                      {q.explanation}
                    </p>
                    {q.relatedConcept && (
                      <div className="mt-2 inline-flex items-center gap-1.5 rounded-md bg-indigo-50/50 px-2.5 py-1 text-xs font-semibold text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-400">
                        <Link2 className="h-3.5 w-3.5" />
                        <span>Concept: {q.relatedConcept}</span>
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
