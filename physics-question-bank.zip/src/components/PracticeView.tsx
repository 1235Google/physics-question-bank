import { useData } from '../context/DataContext';
import React, { useState, useMemo } from 'react';
import { Question, Difficulty, QuestionType } from '../types';
import QuestionCard from './QuestionCard';
import { Filter, ArrowLeft, ArrowRight, RotateCcw, AlertTriangle, CheckSquare, Search, Award } from 'lucide-react';

interface PracticeViewProps {
  onQuestionSolved: (questionId: string, answer: string, isCorrect: boolean) => void;
  solvedQuestionsMap: Record<string, { answered: string; isCorrect: boolean; timestamp: string }>;
  initialClassId?: number | null;
  initialChapterId?: string | null;
  initialQuestionId?: string | null;
}

export default function PracticeView({
  onQuestionSolved,
  solvedQuestionsMap,
  initialClassId = null,
  initialChapterId = null,
  initialQuestionId = null
}: PracticeViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  // Filter States
  const [selectedClass, setSelectedClass] = useState<number | 'all'>(initialClassId || 'all');
  const [selectedChapter, setSelectedChapter] = useState<string | 'all'>(initialChapterId || 'all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'all'>('all');
  const [selectedType, setSelectedType] = useState<QuestionType | 'all'>('all');

  // Interactive index
  const [currentIndex, setCurrentIndex] = useState(() => {
    if (initialQuestionId) {
      const idx = PHYSICS_QUESTIONS.filter(q => {
        if (initialClassId && q.class !== initialClassId) return false;
        if (initialChapterId && q.chapter !== initialChapterId) return false;
        return true;
      }).findIndex(q => q.id === initialQuestionId);
      return idx >= 0 ? idx : 0;
    }
    return 0;
  });

  // Chapters available based on class
  const availableChapters = useMemo(() => {
    if (selectedClass === 'all') {
      return CHAPTERS_DATA;
    }
    return CHAPTERS_DATA.filter(ch => ch.classId === selectedClass);
  }, [selectedClass]);

  // Adjust chapter selection when class changes
  React.useEffect(() => {
    if (selectedClass !== 'all' && selectedChapter !== 'all') {
      const exists = availableChapters.some(ch => ch.id === selectedChapter);
      if (!exists) {
        setSelectedChapter('all');
      }
    }
  }, [selectedClass, availableChapters, selectedChapter]);

  // Filtered list of questions
  const filteredQuestions = useMemo(() => {
    return PHYSICS_QUESTIONS.filter(q => {
      if (selectedClass !== 'all' && q.class !== selectedClass) return false;
      if (selectedChapter !== 'all' && q.chapter !== selectedChapter) return false;
      if (selectedDifficulty !== 'all' && q.difficulty !== selectedDifficulty) return false;
      if (selectedType !== 'all' && q.type !== selectedType) return false;
      return true;
    });
  }, [selectedClass, selectedChapter, selectedDifficulty, selectedType]);

  // Ensure current index is safe
  const activeQuestion = useMemo(() => {
    if (filteredQuestions.length === 0) return null;
    if (currentIndex >= filteredQuestions.length) {
      setCurrentIndex(0);
      return filteredQuestions[0];
    }
    return filteredQuestions[currentIndex];
  }, [filteredQuestions, currentIndex]);

  const handleAnswerSubmit = (answer: string) => {
    if (!activeQuestion) return;
    const isCorrect = activeQuestion.type === 'short_answer' || activeQuestion.type === 'long_answer'
      ? true
      : answer.trim().toLowerCase() === activeQuestion.correctAnswer.trim().toLowerCase();
    
    onQuestionSolved(activeQuestion.id, answer, isCorrect);
  };

  const handleResetFilters = () => {
    setSelectedClass('all');
    setSelectedChapter('all');
    setSelectedDifficulty('all');
    setSelectedType('all');
    setCurrentIndex(0);
  };

  const isCurrentSolved = activeQuestion ? !!solvedQuestionsMap[activeQuestion.id] : false;
  const currentSolvedDetails = activeQuestion ? solvedQuestionsMap[activeQuestion.id] : null;

  const handlePracticeSimilar = (question: Question) => {
    setSelectedClass(question.class);
    setSelectedChapter(question.chapter);
    setSelectedDifficulty(question.difficulty);
    // Find next unanswered question matching this filter if possible, otherwise just reset index
    setCurrentIndex(0);
  };

  return (
    <div id="practice-hub" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Page Title & Stats */}
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-black tracking-tight text-slate-950 dark:text-white">
            Practice Hub
          </h1>
          <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">
            Solve Physics problems chapter-by-chapter and test your formulas instantly.
          </p>
        </div>
        <div className="flex items-center gap-3 bg-blue-50/70 dark:bg-blue-950/30 px-4.5 py-3 rounded-2xl border border-blue-100 dark:border-blue-900/50 shadow-sm backdrop-blur-sm">
          <Award className="h-5 w-5 text-blue-600 dark:text-blue-400 animate-bounce shrink-0" />
          <div className="font-sans text-xs sm:text-sm">
            <span className="font-bold text-slate-700 dark:text-slate-300">Total Solved: </span>
            <span className="font-extrabold text-blue-600 dark:text-blue-400">
              {Object.keys(solvedQuestionsMap).length}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className="lg:col-span-1 space-y-5 bg-white/70 dark:bg-slate-900/75 backdrop-blur-md p-5 rounded-2xl border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/30 dark:shadow-none">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-850 pb-3">
            <h3 className="font-display text-sm font-black text-slate-950 dark:text-white flex items-center gap-2">
              <Filter className="h-4.5 w-4.5 text-blue-600" />
              <span>Syllabus Filters</span>
            </h3>
            <button
              onClick={handleResetFilters}
              className="font-sans text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="h-3 w-3" /> Reset
            </button>
          </div>

          {/* Class Filter */}
          <div className="space-y-2">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Class Level
            </label>
            <select
              id="filter-class"
              value={selectedClass}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedClass(val === 'all' ? 'all' : parseInt(val));
                setCurrentIndex(0);
              }}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
            >
              <option value="all">All Classes (6 to 10)</option>
              {CLASSES_DATA.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  Class {cls.id} Physics
                </option>
              ))}
            </select>
          </div>

          {/* Chapter Filter */}
          <div className="space-y-2">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Physics Chapter
            </label>
            <select
              id="filter-chapter"
              value={selectedChapter}
              onChange={(e) => {
                setSelectedChapter(e.target.value);
                setCurrentIndex(0);
              }}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
            >
              <option value="all">All Chapters</option>
              {availableChapters.map((ch) => (
                <option key={ch.id} value={ch.id}>
                  {ch.name}
                </option>
              ))}
            </select>
          </div>

          {/* Difficulty Filter */}
          <div className="space-y-2">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Difficulty
            </label>
            <select
              id="filter-difficulty"
              value={selectedDifficulty}
              onChange={(e) => {
                setSelectedDifficulty(e.target.value as Difficulty | 'all');
                setCurrentIndex(0);
              }}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
            >
              <option value="all">Any Difficulty</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>

          {/* Type Filter */}
          <div className="space-y-2">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Question Format
            </label>
            <select
              id="filter-type"
              value={selectedType}
              onChange={(e) => {
                setSelectedType(e.target.value as QuestionType | 'all');
                setCurrentIndex(0);
              }}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
            >
              <option value="all">Any Format</option>
              <option value="mcq">MCQ (4 Choices)</option>
              <option value="true_false">True / False</option>
              <option value="fill_blank">Fill in the Blank</option>
              <option value="numerical">Numerical Problem</option>
              <option value="short_answer">Short Answer</option>
              <option value="long_answer">Long Answer</option>
            </select>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-850">
            <p className="font-sans text-xs text-slate-400 dark:text-slate-500 leading-normal font-medium">
              Showing <strong className="text-slate-700 dark:text-slate-300 font-extrabold">{filteredQuestions.length}</strong> matching questions in total. Solve them sequentially!
            </p>
          </div>
        </div>

        {/* Question Viewer */}
        <div className="lg:col-span-3 space-y-6">
          {activeQuestion ? (
            <div className="space-y-6">
              {/* Progress and Nav Bar */}
              <div className="flex items-center justify-between gap-4 bg-white/70 dark:bg-slate-900/75 backdrop-blur-md p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/30 dark:shadow-none">
                <div className="flex-1 space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
                    <span>Question Progress</span>
                    <span>{currentIndex + 1} of {filteredQuestions.length}</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-300"
                      style={{ width: `${((currentIndex + 1) / filteredQuestions.length) * 100}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pl-4 shrink-0 border-l border-slate-100 dark:border-slate-800">
                  <button
                    id="btn-prev-question"
                    disabled={currentIndex === 0}
                    onClick={() => setCurrentIndex(prev => prev - 1)}
                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/60 bg-white text-slate-700 shadow-sm transition-all hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-white dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-750 cursor-pointer"
                    title="Previous Question"
                  >
                    <ArrowLeft className="h-4.5 w-4.5" />
                  </button>
                  <button
                    id="btn-next-question"
                    disabled={currentIndex === filteredQuestions.length - 1}
                    onClick={() => setCurrentIndex(prev => prev + 1)}
                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/60 bg-white text-slate-700 shadow-sm transition-all hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-white dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-750 cursor-pointer"
                    title="Next Question"
                  >
                    <ArrowRight className="h-4.5 w-4.5" />
                  </button>
                </div>
              </div>

              {/* Solved Banner Indicator */}
              {isCurrentSolved && currentSolvedDetails && (
                <div id="solved-badge-bar" className="flex items-center gap-2.5 rounded-2xl border border-emerald-150 bg-emerald-50/50 p-4 dark:border-emerald-950/40 dark:bg-emerald-950/15 backdrop-blur-sm">
                  <CheckSquare className="h-5 w-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <p className="font-sans text-xs sm:text-sm font-semibold text-emerald-800 dark:text-emerald-300">
                    You solved this question correctly on {new Date(currentSolvedDetails.timestamp || '').toLocaleDateString()}.
                  </p>
                </div>
              )}

              {/* The Interactive Question Card */}
              <QuestionCard
                key={activeQuestion.id}
                question={activeQuestion}
                submittedAnswer={currentSolvedDetails?.answered || ''}
                isSubmitted={isCurrentSolved}
                onSubmit={handleAnswerSubmit}
                onPracticeSimilar={handlePracticeSimilar}
              />
            </div>
          ) : (
            <div id="no-matching-questions" className="flex flex-col items-center justify-center text-center py-16 px-4 border border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white/50 dark:bg-slate-900/10">
              <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 p-4 text-amber-600 dark:text-amber-400 mb-4">
                <AlertTriangle className="h-8 w-8" />
              </div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                No matching questions found
              </h3>
              <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-sm font-medium">
                Try widening your syllabus filter settings or click Reset to browse all classes.
              </p>
              <button
                onClick={handleResetFilters}
                className="mt-5 rounded-xl bg-blue-600 px-5 py-2.5 font-sans text-sm font-bold text-white shadow-md shadow-blue-500/10 hover:bg-blue-700 hover:shadow-lg transition-all cursor-pointer"
              >
                Reset Filter Setup
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
