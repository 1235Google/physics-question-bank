import React, { useState } from 'react';
import { Search, Edit, Trash2, Filter, Eye, Tag } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { deleteQuestion } from '../../lib/db';

export default function ManageQuestions() {
  const { questions: PHYSICS_QUESTIONS, refreshData } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState<number | 'all'>('all');

  const filtered = PHYSICS_QUESTIONS.filter(q => {
    const matchesSearch = q.question.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = filterClass === 'all' || q.class === filterClass;
    return matchesSearch && matchesClass;
  });

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this question?')) {
      try {
        await deleteQuestion(id);
        await refreshData();
      } catch (err: any) {
        alert(err.message);
      }
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 md:p-6 shadow-lg shadow-slate-100/50 dark:shadow-none w-full">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h3 className="text-xl font-bold text-slate-800 dark:text-white">Manage Questions</h3>
        <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search questions..." 
              className="w-full h-12 md:h-auto pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select 
            className="w-full h-12 md:h-auto md:w-auto px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value === 'all' ? 'all' : parseInt(e.target.value))}
          >
            <option value="all">All Classes</option>
            {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
          </select>
        </div>
      </div>

      {/* Desktop Table (Hidden on Mobile) */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-sm text-slate-500 uppercase tracking-wider">
              <th className="p-4 font-bold">Class</th>
              <th className="p-4 font-bold">Type</th>
              <th className="p-4 font-bold w-1/2">Question</th>
              <th className="p-4 font-bold text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(q => (
              <tr key={q.id} className="border-b border-slate-100 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="p-4 font-medium text-slate-700 dark:text-slate-300">{q.class}</td>
                <td className="p-4">
                  <span className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 px-2 py-1 rounded-md text-xs font-bold uppercase">
                    {q.type}
                  </span>
                </td>
                <td className="p-4 text-slate-800 dark:text-slate-200 text-sm truncate max-w-md">
                  {q.question}
                </td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-colors">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button onClick={() => handleDelete(q.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-colors">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={4} className="p-8 text-center text-slate-500">No questions found matching your filters.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards (Hidden on Desktop) */}
      <div className="md:hidden space-y-4">
        {filtered.map(q => (
          <div key={q.id} className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col gap-3">
            <div className="flex justify-between items-start gap-2">
              <span className="bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest shrink-0">
                {q.type}
              </span>
              <div className="flex gap-1 bg-white dark:bg-slate-900 rounded-lg p-1 border border-slate-200 dark:border-slate-700">
                <button className="p-1.5 text-slate-400 hover:text-indigo-600 transition-colors rounded-md active:bg-slate-100 dark:active:bg-slate-800">
                  <Edit className="h-4 w-4" />
                </button>
                <button className="p-1.5 text-slate-400 hover:text-sky-600 transition-colors rounded-md active:bg-slate-100 dark:active:bg-slate-800">
                  <Eye className="h-4 w-4" />
                </button>
                <button onClick={() => handleDelete(q.id)} className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors rounded-md active:bg-slate-100 dark:active:bg-slate-800">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            <p className="text-slate-800 dark:text-slate-200 text-sm font-medium line-clamp-3">
              {q.question}
            </p>
            
            <div className="flex flex-wrap gap-2 mt-1">
              <div className="flex items-center gap-1 text-xs font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700">
                Class {q.class}
              </div>
              <div className="flex items-center gap-1 text-xs font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700 truncate max-w-[120px]">
                <Tag className="h-3 w-3" />
                {q.chapter}
              </div>
              <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-md border ${
                q.difficulty === 'easy' ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-400' :
                q.difficulty === 'medium' ? 'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-400' :
                'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-900/20 dark:border-rose-800 dark:text-rose-400'
              }`}>
                {q.difficulty}
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="p-8 text-center text-slate-500 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
            No questions found.
          </div>
        )}
      </div>
    </div>
  );
}
