import React from 'react';

export default function ExportQuestions() {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-lg text-center py-20">
      <h3 className="text-xl font-bold text-slate-400">ExportQuestions</h3>
      <p className="text-slate-500 mt-2">This feature is under development.</p>
    </div>
  );
}
