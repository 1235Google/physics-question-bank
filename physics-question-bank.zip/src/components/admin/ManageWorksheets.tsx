import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Trash2, Edit, FileText } from 'lucide-react';
import { deleteWorksheet } from '../../lib/db';

export default function ManageWorksheets() {
  const { worksheets, refreshData } = useData();

  const handleDelete = async (id: string) => {
    if(confirm('Are you sure you want to delete this worksheet?')) {
      try {
        await deleteWorksheet(id);
        await refreshData();
      } catch (err: any) {
        alert(err.message);
      }
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-100/50 dark:shadow-none">
      <h3 className="text-xl font-bold mb-6 text-slate-800 dark:text-white">Manage Worksheets</h3>
      
      <div className="space-y-3">
        {worksheets?.map((ws) => (
          <div key={ws.id} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-400">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 dark:text-white">{ws.title}</h4>
                <div className="text-xs text-slate-500 font-medium">Class {ws.classId} • {ws.questions?.length || 0} questions</div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-colors">
                <Edit className="h-4 w-4" />
              </button>
              <button onClick={() => handleDelete(ws.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
        {(!worksheets || worksheets.length === 0) && (
          <div className="p-8 text-center text-slate-500 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
            No worksheets found.
          </div>
        )}
      </div>
    </div>
  );
}
