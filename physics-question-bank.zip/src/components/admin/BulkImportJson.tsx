import React, { useState } from 'react';
import { Upload, FileCode, CheckCircle, AlertTriangle, Play, Loader2 } from 'lucide-react';
import { Question } from '../../types';
import { addQuestionsBatch } from '../../lib/db';
import { useData } from '../../context/DataContext';

export default function BulkImportJson() {
  const { refreshData } = useData();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [importing, setImporting] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!Array.isArray(json)) {
          setErrors(['JSON file must contain an array of question objects.']);
          setPreview([]);
          return;
        }

        const validData = [];
        const errs = [];

        for (let i = 0; i < json.length; i++) {
          const row = json[i];
          if (!row.question) {
            errs.push(`Index ${i}: Missing question text`);
            continue;
          }
          if (!row.answer) {
            errs.push(`Index ${i}: Missing correct answer`);
            continue;
          }
          validData.push(row);
        }

        setPreview(validData);
        setErrors(errs);
      } catch (err: any) {
        setErrors(['Failed to parse JSON file: ' + err.message]);
        setPreview([]);
      }
    };
    reader.readAsText(selected);
  };

  const handleImport = async () => {
    if (preview.length === 0) return;
    setImporting(true);
    try {
      const questionsToImport = preview.map((row, idx) => {
        return {
          id: `json_${Date.now()}_${idx}`,
          class: parseInt(row.class) || 6,
          subject: row.subject || 'Physics',
          chapter: row.chapter || 'unknown',
          type: row.type || 'vsa',
          difficulty: row.difficulty || 'medium',
          marks: parseInt(row.marks) || 1,
          question: row.question,
          options: Array.isArray(row.options) ? row.options : [],
          answer: row.answer,
          explanation: row.explanation || '',
          hint: row.hint || ''
        } as Question;
      });

      await addQuestionsBatch(questionsToImport);
      await refreshData();
      alert(`Successfully imported ${questionsToImport.length} questions!`);
      setFile(null);
      setPreview([]);
      setErrors([]);
    } catch (e: any) {
      alert('Error importing: ' + e.message);
    }
    setImporting(false);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-100/50 dark:shadow-none max-w-4xl">
      <div className="text-center mb-8">
        <div className="bg-sky-100 dark:bg-sky-900/30 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <FileCode className="h-8 w-8 text-sky-600 dark:text-sky-400" />
        </div>
        <h3 className="text-2xl font-bold text-slate-800 dark:text-white">Bulk Import JSON</h3>
        <p className="text-slate-500 mt-2">Upload a JSON array to import multiple questions securely.</p>
      </div>

      {!file ? (
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-8 md:p-12 text-center hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer relative">
          <input type="file" accept=".json" onChange={handleFile} className="absolute inset-0 opacity-0 cursor-pointer" />
          <Upload className="h-10 w-10 text-slate-400 mx-auto mb-4" />
          <span className="bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold py-2 px-6 rounded-xl inline-block mb-2">
            Select JSON File
          </span>
          <p className="text-sm text-slate-500">File must be a valid JSON array of objects</p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <FileCode className="h-6 w-6 text-sky-500" />
              <div>
                <h4 className="font-bold text-slate-800 dark:text-white">{file.name}</h4>
                <p className="text-xs text-slate-500">{preview.length} valid objects found</p>
              </div>
            </div>
            <button onClick={() => setFile(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-medium text-sm">
              Change File
            </button>
          </div>

          {errors.length > 0 && (
            <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                <h4 className="font-bold text-amber-800 dark:text-amber-400">Found {errors.length} errors</h4>
              </div>
              <ul className="text-sm text-amber-700 dark:text-amber-500 list-disc pl-5 max-h-32 overflow-y-auto space-y-1">
                {errors.map((err, i) => <li key={i}>{err}</li>)}
              </ul>
            </div>
          )}

          {preview.length > 0 && (
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-xl">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-3 font-bold text-slate-500">Class</th>
                    <th className="p-3 font-bold text-slate-500">Type</th>
                    <th className="p-3 font-bold text-slate-500">Question</th>
                    <th className="p-3 font-bold text-slate-500">Answer</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {preview.slice(0, 5).map((row, i) => (
                    <tr key={i}>
                      <td className="p-3">{row.class}</td>
                      <td className="p-3">{row.type}</td>
                      <td className="p-3 truncate max-w-[200px]">{row.question}</td>
                      <td className="p-3 truncate max-w-[150px]">{row.answer}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {preview.length > 5 && (
                <div className="p-2 text-center text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/50">
                  And {preview.length - 5} more items...
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end pt-4">
            <button 
              onClick={handleImport} 
              disabled={importing || preview.length === 0}
              className="w-full md:w-auto h-12 px-6 justify-center bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl flex items-center gap-2 disabled:opacity-50"
            >
              {importing ? <Loader2 className="h-5 w-5 animate-spin" /> : <Play className="h-5 w-5" />}
              {importing ? 'Importing...' : `Import ${preview.length} Questions`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
