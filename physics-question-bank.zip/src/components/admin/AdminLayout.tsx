import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Database, PlusCircle, List, FileText, 
  Upload, FileCode, Download, History, Edit3, BookOpen, 
  Users, TrendingUp, Settings as SettingsIcon, ChevronRight,
  Menu, X, Moon, Sun, Bell, UserCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdminLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function AdminLayout({ children, activeTab, onTabChange }: AdminLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const menuGroups = [
    {
      title: 'Overview',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }
      ]
    },
    {
      title: 'Question Bank',
      items: [
        { id: 'add_q', label: 'Add Question', icon: PlusCircle },
        { id: 'manage_q', label: 'Manage Questions', icon: List },
        { id: 'pdf', label: 'Import PDF', icon: FileText },
        { id: 'bulk_csv', label: 'Bulk Import CSV', icon: Upload },
        { id: 'bulk_json', label: 'Bulk Import JSON', icon: FileCode },
        { id: 'export', label: 'Export Questions', icon: Download },
        { id: 'history', label: 'Import History', icon: History }
      ]
    },
    {
      title: 'Worksheets',
      items: [
        { id: 'create_worksheet', label: 'Create Worksheet', icon: PlusCircle },
        { id: 'worksheets', label: 'Manage Worksheets', icon: FileText }
      ]
    },
    {
      title: 'Quizzes',
      items: [
        { id: 'create_quiz', label: 'Create Quiz', icon: PlusCircle },
        { id: 'quizzes', label: 'Manage Quizzes', icon: Edit3 }
      ]
    },
    {
      title: 'Curriculum',
      items: [
        { id: 'chapters', label: 'Manage Chapters', icon: BookOpen }
      ]
    },
    {
      title: 'System',
      items: [
        { id: 'users', label: 'Users', icon: Users },
        { id: 'analytics', label: 'Analytics', icon: TrendingUp },
        { id: 'settings', label: 'Settings', icon: SettingsIcon }
      ]
    }
  ];

  const getActiveTitle = () => {
    for (const group of menuGroups) {
      const item = group.items.find(i => i.id === activeTab);
      if (item) return item.label;
    }
    return 'Dashboard';
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
      
      {/* Top App Bar (Mobile & Desktop) */}
      <div className="sticky top-0 z-40 w-full h-14 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-4 md:hidden">
        <div className="flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)} className="p-1 -ml-1 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="font-bold text-slate-800 dark:text-white truncate">{getActiveTitle()}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setDarkMode(!darkMode)} className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
            {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
          <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
            <Bell className="h-5 w-5" />
          </button>
          <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-700 ml-1">
            <UserCircle className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Desktop Top Bar placeholder to align with mobile design request if needed, but typically desktop has sidebars */}
      <div className="hidden md:flex absolute top-0 right-0 p-4 z-40 items-center gap-3">
        <button onClick={() => setDarkMode(!darkMode)} className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
          {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </button>
        <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
          <Bell className="h-5 w-5" />
        </button>
        <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-700">
          <UserCircle className="h-5 w-5" />
        </div>
      </div>

      {/* Sidebar Overlay (Mobile) */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 md:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar (Desktop & Mobile Drawer) */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-[80%] max-w-[320px] md:w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:relative md:translate-x-0 overflow-y-auto flex flex-col h-full`}
      >
        <div className="p-5 flex items-center justify-between sticky top-0 bg-white dark:bg-slate-900 z-10 border-b md:border-b-0 border-slate-200 dark:border-slate-800">
          <h2 className="text-xl font-black text-slate-800 dark:text-white tracking-tight flex items-center gap-2">
            <Database className="h-6 w-6 text-indigo-600" />
            CMS Admin
          </h2>
          <button onClick={() => setSidebarOpen(false)} className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg md:hidden">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="px-4 py-4 pb-24 flex-1">
          {menuGroups.map((group, idx) => (
            <div key={idx} className="mb-6">
              <h4 className="px-3 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">{group.title}</h4>
              <div className="space-y-1">
                {group.items.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onTabChange(item.id);
                        if (window.innerWidth < 768) setSidebarOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium transition-all ${
                        isActive 
                          ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 font-bold' 
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={`h-5 w-5 ${isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`} />
                        {item.label}
                      </div>
                      {isActive && <ChevronRight className="h-4 w-4 opacity-50" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-x-hidden relative w-full pb-20 md:pb-0">
        <div className="p-4 md:p-8 max-w-7xl mx-auto md:mt-10">
          {children}
        </div>
      </div>
    </div>
  );
}
