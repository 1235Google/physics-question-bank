import React from 'react';
import { useData } from '../../context/DataContext';

export default function Dashboard() {
  const { questions, classes, chapters, worksheets, quizzes } = useData();
  
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-100/50 dark:shadow-none">
      <h3 className="text-lg font-bold mb-6 text-slate-800 dark:text-white">Platform Dashboard</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-5 border border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
          <span className="text-xs font-bold text-slate-500 uppercase">Total Questions</span>
          <div className="text-3xl font-black mt-1 text-indigo-600">{questions.length}</div>
        </div>
        <div className="p-5 border border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
          <span className="text-xs font-bold text-slate-500 uppercase">Total Worksheets</span>
          <div className="text-3xl font-black mt-1 text-emerald-600">{worksheets?.length || 0}</div>
        </div>
        <div className="p-5 border border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
          <span className="text-xs font-bold text-slate-500 uppercase">Total Quizzes</span>
          <div className="text-3xl font-black mt-1 text-amber-600">{quizzes?.length || 0}</div>
        </div>
        <div className="p-5 border border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
          <span className="text-xs font-bold text-slate-500 uppercase">Chapters</span>
          <div className="text-3xl font-black mt-1 text-rose-600">{chapters.length}</div>
        </div>
      </div>
    </div>
  );
}
