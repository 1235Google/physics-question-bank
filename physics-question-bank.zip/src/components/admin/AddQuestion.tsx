import React, { useState } from 'react';
import { Save, PlusCircle } from 'lucide-react';
import { Question } from '../../types';
import { useData } from '../../context/DataContext';
import { addQuestion } from '../../lib/db';

export default function AddQuestion() {
  const { classes: CLASSES_DATA, refreshData } = useData();
  const [formData, setFormData] = useState<Partial<Question>>({
    class: 6,
    subject: 'Physics',
    chapter: 'c6_motion_measurement',
    worksheet: '',
    type: 'mcq',
    difficulty: 'easy',
    marks: 1,
    question: '',
    options: ['', '', '', ''],
    answer: '',
    explanation: '',
    hint: '',
    estimatedTime: 30,
    tags: []
  });

  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const newQ: Question = {
      ...(formData as Question),
      id: `custom_${Date.now()}`,
    };
    try {
      await addQuestion(newQ);
      await refreshData();
      alert('Question added successfully!');
      setFormData({
        ...formData,
        question: '',
        options: ['', '', '', ''],
        answer: '',
        explanation: '',
        hint: '',
        tags: []
      });
    } catch(err: any) {
      alert(err.message);
    }
    setSaving(false);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-100/50 dark:shadow-none max-w-4xl">
      <h3 className="text-xl font-bold mb-6 text-slate-800 dark:text-white">Add New Question</h3>
      
      <form onSubmit={handleSubmit} className="space-y-6 pb-20 md:pb-0">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase">Class</label>
            <select className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.class} onChange={e => setFormData({...formData, class: parseInt(e.target.value)})}>
              {CLASSES_DATA.map(c => (
                <option key={c.id} value={c.id}>Class {c.id}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase">Type</label>
            <select className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as any})}>
              <option value="mcq">Multiple Choice</option>
              <option value="tf">True / False</option>
              <option value="fib">Fill in Blanks</option>
              <option value="vsa">Very Short Answer</option>
              <option value="sa">Short Answer</option>
              <option value="la">Long Answer</option>
              <option value="numerical">Numerical</option>
              <option value="assertion">Assertion & Reason</option>
              <option value="match">Match the Following</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase">Difficulty</label>
            <select className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.difficulty} onChange={e => setFormData({...formData, difficulty: e.target.value as any})}>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase">Marks</label>
            <input type="number" className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.marks} onChange={e => setFormData({...formData, marks: parseInt(e.target.value) || 1})} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
             <label className="text-xs font-bold text-slate-500 uppercase">Chapter ID</label>
             <input type="text" className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.chapter} onChange={e => setFormData({...formData, chapter: e.target.value})} placeholder="e.g. c6_motion_measurement"/>
          </div>
          <div>
             <label className="text-xs font-bold text-slate-500 uppercase">Tags (comma separated)</label>
             <input type="text" className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.tags?.join(', ') || ''} onChange={e => setFormData({...formData, tags: e.target.value.split(',').map(t => t.trim())})} />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-500 uppercase">Question Text</label>
          <textarea required className="w-full mt-1 p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl min-h-[100px] min-h-[48px]"
            value={formData.question} onChange={e => setFormData({...formData, question: e.target.value})} />
        </div>

        {formData.type === 'mcq' && (
          <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
            <label className="text-xs font-bold text-slate-500 uppercase mb-3 block">Options</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 min-h-[48px]">
              {[0,1,2,3].map(i => (
                <div key={i} className="flex items-center gap-2">
                  <span className="font-bold text-slate-400 w-6">{String.fromCharCode(65+i)}.</span>
                  <input type="text" className="flex-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-600 rounded-lg h-12"
                    value={formData.options?.[i] || ''} 
                    onChange={e => {
                      const newOpts = [...(formData.options || ['','','',''])];
                      newOpts[i] = e.target.value;
                      setFormData({...formData, options: newOpts});
                    }} 
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase">Correct Answer</label>
            <input type="text" required className="w-full mt-1 p-2.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl h-12"
              value={formData.answer} onChange={e => setFormData({...formData, answer: e.target.value})} />
          </div>
          <div>
             <label className="text-xs font-bold text-slate-500 uppercase">Hint (Optional)</label>
             <input type="text" className="w-full mt-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl h-12"
              value={formData.hint} onChange={e => setFormData({...formData, hint: e.target.value})} />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-500 uppercase">Explanation (Optional)</label>
          <textarea className="w-full mt-1 p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl min-h-[80px] min-h-[48px]"
            value={formData.explanation} onChange={e => setFormData({...formData, explanation: e.target.value})} />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800 min-h-[48px]">
          <button type="submit" disabled={saving} className="w-full md:w-auto h-12 px-6 flex justify-center items-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold rounded-xl transition-colors">
            <Save className="h-5 w-5" />
            {saving ? 'Saving...' : 'Save Question'}
          </button>
        </div>
      </form>
    </div>
  );
}
