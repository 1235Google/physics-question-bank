import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { CheckCircle, XCircle, AlertCircle, HelpCircle, Award, Clock, Lightbulb, Link2, Search } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  submittedAnswer?: string;
  isSubmitted: boolean;
  onSubmit: (answer: string) => void;
  showResultsInline?: boolean; // Whether to instantly correct and show explanation
  onPracticeSimilar?: (question: Question) => void;
  key?: string | number;
}

export default function QuestionCard({
  question,
  submittedAnswer = '',
  isSubmitted,
  onSubmit,
  showResultsInline = true,
  onPracticeSimilar
}: QuestionCardProps) {
  const [localAnswer, setLocalAnswer] = useState(submittedAnswer);
  const [showHint, setShowHint] = useState(false);

  useEffect(() => {
    setLocalAnswer(submittedAnswer);
    setShowHint(false); // Reset hint on new question
  }, [submittedAnswer, question.id]);

  const handleMcqSelect = (option: string) => {
    if (isSubmitted) return;
    setLocalAnswer(option);
    if (!showResultsInline) {
      onSubmit(option);
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitted || !localAnswer.trim()) return;
    onSubmit(localAnswer.trim());
  };

  const difficultyColors = {
    easy: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-900/60',
    medium: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/30 dark:text-amber-400 dark:border-amber-900/60',
    hard: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/30 dark:text-rose-400 dark:border-rose-900/60'
  };

  const typeLabels = {
    mcq: 'Multiple Choice (MCQ)',
    fill_blank: 'Fill in the Blank',
    true_false: 'True / False',
    short_answer: 'Short Answer',
    long_answer: 'Long Answer',
    numerical: 'Numerical Problem'
  };

  const isCorrect = isSubmitted && 
    (question.type === 'short_answer' || question.type === 'long_answer'
      ? true // Short/Long answers are qualitative, self-evaluated or always accepted as submitted
      : localAnswer.trim().toLowerCase() === question.answer.trim().toLowerCase());

  return (
    <div id={`question-card-${question.id}`} className="rounded-2xl border border-slate-200 bg-white p-5 md:p-6 shadow-sm transition-all duration-300 dark:border-slate-800 dark:bg-slate-900">
      {/* Header Badges */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-100 pb-4 mb-4 dark:border-slate-800">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider ${difficultyColors[question.difficulty]}`}>
            {question.difficulty}
          </span>
          <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/40 dark:text-blue-400">
            {typeLabels[question.type]}
          </span>
          {question.estimatedTime && (
            <span className="flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-400">
              <Clock className="h-3 w-3" />
              {question.estimatedTime}s
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 text-xs font-medium">
          <Award className="h-4.5 w-4.5 text-blue-500" />
          <span>{question.marks} {question.marks === 1 ? 'Mark' : 'Marks'}</span>
        </div>
      </div>

      {/* Question Body */}
      <div className="mb-6 space-y-4">
        <p className="font-sans text-base md:text-lg font-medium text-slate-800 dark:text-slate-100 leading-relaxed">
          {question.question}
        </p>

        {question.hint && !isSubmitted && (
          <div className="mt-2">
            {!showHint ? (
              <button 
                onClick={() => setShowHint(true)}
                className="flex items-center gap-1.5 text-xs font-bold text-amber-600 hover:text-amber-700 dark:text-amber-500 dark:hover:text-amber-400 transition-colors"
              >
                <Lightbulb className="h-3.5 w-3.5" />
                <span>Need a hint?</span>
              </button>
            ) : (
              <div className="rounded-xl bg-amber-50/80 border border-amber-200/60 p-3 text-sm text-amber-900 dark:bg-amber-950/20 dark:border-amber-900/40 dark:text-amber-200 animate-in fade-in slide-in-from-top-2 duration-300 flex gap-2.5">
                <Lightbulb className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{question.hint}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Answer Form Controls */}
      <div className="space-y-4">
        {/* MCQ Mode */}
        {question.type === 'mcq' && question.options && (
          <div className="grid grid-cols-1 gap-3">
            {question.options.map((opt, idx) => {
              const letter = String.fromCharCode(65 + idx); // A, B, C, D
              const isSelected = localAnswer === opt;
              const isCorrectOpt = opt === question.answer;
              
              let optStyle = 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-300 dark:hover:bg-slate-800';
              if (isSelected && !isSubmitted) {
                optStyle = 'border-blue-500 bg-blue-50/50 text-blue-700 ring-2 ring-blue-500/20 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300';
              } else if (isSubmitted) {
                if (isCorrectOpt) {
                  optStyle = 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:border-emerald-500 dark:bg-emerald-950/40 dark:text-emerald-300';
                } else if (isSelected && !isCorrectOpt) {
                  optStyle = 'border-rose-500 bg-rose-50 text-rose-800 dark:border-rose-500 dark:bg-rose-950/40 dark:text-rose-300';
                } else {
                  optStyle = 'border-slate-100 bg-slate-50 text-slate-400 opacity-60 dark:border-slate-800/40 dark:bg-slate-800/20 dark:text-slate-500';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  id={`option-${question.id}-${idx}`}
                  disabled={isSubmitted}
                  onClick={() => handleMcqSelect(opt)}
                  className={`flex items-center w-full rounded-xl border p-3.5 text-left font-sans text-sm font-medium transition-all duration-200 cursor-pointer ${optStyle}`}
                >
                  <span className={`mr-3.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border text-xs font-bold transition-colors duration-200 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-300 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-800'
                  }`}>
                    {letter}
                  </span>
                  <span className="flex-1 leading-snug">{opt}</span>
                  {isSubmitted && isCorrectOpt && <CheckCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400 ml-2" />}
                  {isSubmitted && isSelected && !isCorrectOpt && <XCircle className="h-5 w-5 text-rose-600 dark:text-rose-400 ml-2" />}
                </button>
              );
            })}
          </div>
        )}

        {/* True/False Mode */}
        {question.type === 'true_false' && (
          <div className="flex flex-col sm:flex-row gap-3">
            {['True', 'False'].map((val, idx) => {
              const isSelected = localAnswer === val;
              const isCorrectVal = val === question.answer;

              let btnStyle = 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-300 dark:hover:bg-slate-800';
              if (isSelected && !isSubmitted) {
                btnStyle = 'border-blue-500 bg-blue-50/50 text-blue-700 ring-2 ring-blue-500/20 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300';
              } else if (isSubmitted) {
                if (isCorrectVal) {
                  btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:border-emerald-500 dark:bg-emerald-950/40 dark:text-emerald-300';
                } else if (isSelected && !isCorrectVal) {
                  btnStyle = 'border-rose-500 bg-rose-50 text-rose-800 dark:border-rose-500 dark:bg-rose-950/40 dark:text-rose-300';
                } else {
                  btnStyle = 'border-slate-100 bg-slate-50 text-slate-400 opacity-60 dark:border-slate-800/40 dark:bg-slate-800/20 dark:text-slate-500';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  id={`tf-${question.id}-${idx}`}
                  disabled={isSubmitted}
                  onClick={() => handleMcqSelect(val)}
                  className={`flex flex-1 items-center justify-center rounded-xl border p-3.5 text-center font-sans text-base font-bold transition-all duration-200 cursor-pointer ${btnStyle}`}
                >
                  {val}
                </button>
              );
            })}
          </div>
        )}

        {/* Fill Blank / Numerical Mode (Instant Correction Textbox) */}
        {(question.type === 'fill_blank' || question.type === 'numerical') && (
          <form onSubmit={handleTextSubmit} className="space-y-3">
            <div className="relative">
              <input
                type="text"
                disabled={isSubmitted}
                value={localAnswer}
                onChange={(e) => setLocalAnswer(e.target.value)}
                placeholder={question.type === 'numerical' ? 'Enter numerical answer (e.g. 50 Pa, 1.6 s, -1.5 m/s)' : 'Type correct word...'}
                className={`w-full rounded-xl border px-4 py-3 font-sans text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/20 ${
                  isSubmitted
                    ? isCorrect
                      ? 'border-emerald-500 bg-emerald-50/30 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950/10 dark:text-emerald-300'
                      : 'border-rose-500 bg-rose-50/30 text-rose-800 dark:border-rose-800 dark:bg-rose-950/10 dark:text-rose-300'
                    : 'border-slate-200 bg-white text-slate-800 focus:border-blue-500 dark:border-slate-800 dark:bg-slate-800/40 dark:text-white dark:focus:border-blue-500'
                }`}
              />
              {isSubmitted && (
                <div className="absolute inset-y-0 right-3 flex items-center">
                  {isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <XCircle className="h-5 w-5 text-rose-600 dark:text-rose-400" />
                  )}
                </div>
              )}
            </div>

            {!isSubmitted && showResultsInline && (
              <button
                type="submit"
                disabled={!localAnswer.trim()}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 text-white font-sans text-sm font-bold shadow-md shadow-blue-500/10 hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                Submit Answer
              </button>
            )}
          </form>
        )}

        {/* Short & Long Qualitative Answers */}
        {(question.type === 'short_answer' || question.type === 'long_answer') && (
          <form onSubmit={handleTextSubmit} className="space-y-3">
            <textarea
              disabled={isSubmitted}
              value={localAnswer}
              onChange={(e) => setLocalAnswer(e.target.value)}
              rows={question.type === 'long_answer' ? 5 : 3}
              placeholder="Write your explanation or proof here..."
              className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 font-sans text-sm font-medium text-slate-800 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-slate-800 dark:bg-slate-800/40 dark:text-white dark:focus:border-blue-500"
            />

            {!isSubmitted && showResultsInline && (
              <button
                type="submit"
                disabled={!localAnswer.trim()}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 text-white font-sans text-sm font-bold shadow-md shadow-blue-500/10 hover:bg-blue-700 hover:shadow-lg transition-all"
              >
                Submit for Self-Evaluation
              </button>
            )}
          </form>
        )}

        {/* MCQ/TF Inline Submission trigger (for cases where showResultsInline is true but user selected) */}
        {showResultsInline && !isSubmitted && (question.type === 'mcq' || question.type === 'true_false') && localAnswer && (
          <div className="flex justify-end pt-2">
            <button
              onClick={() => onSubmit(localAnswer)}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 text-white font-sans text-sm font-bold shadow-md shadow-blue-500/10 hover:bg-blue-700 hover:shadow-lg transition-all"
            >
              Verify Answer
            </button>
          </div>
        )}
      </div>

      {/* Answer & Explanation Display once Submitted */}
      {isSubmitted && showResultsInline && (
        <div id={`result-explanation-${question.id}`} className="mt-5 rounded-xl border border-blue-100 bg-blue-50/30 p-4.5 dark:border-blue-950/40 dark:bg-blue-950/15">
          <div className="flex items-start gap-2.5">
            <div className="mt-0.5 rounded-lg bg-blue-500/10 p-1.5 text-blue-600 dark:text-blue-400 shrink-0">
              <AlertCircle className="h-4 w-4" />
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <h4 className="font-sans text-sm font-bold text-slate-900 dark:text-white">
                  {isCorrect ? 'Correct!' : 'Answer Analysis'}
                </h4>
                
                <div className="font-sans text-xs sm:text-sm mt-1">
                  <span className="font-bold text-slate-500 dark:text-slate-400">Correct Answer: </span>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded">
                    {question.answer}
                  </span>
                </div>

                {localAnswer && !isCorrect && (
                  <div className="font-sans text-xs sm:text-sm mt-1">
                    <span className="font-bold text-slate-500 dark:text-slate-400">Your Answer: </span>
                    <span className="font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/30 px-2 py-0.5 rounded">
                      {localAnswer}
                    </span>
                  </div>
                )}
              </div>

              <div className="pt-2 border-t border-slate-200/50 dark:border-slate-800/50">
                <p className="font-sans text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  <strong className="text-slate-700 dark:text-slate-200">Scientific Explanation: </strong> 
                  {question.explanation}
                </p>
                {question.relatedConcept && (
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-md bg-indigo-50/50 px-2.5 py-1 text-xs font-semibold text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-400">
                    <Link2 className="h-3.5 w-3.5" />
                    <span>Concept: {question.relatedConcept}</span>
                  </div>
                )}
              </div>
              
              {onPracticeSimilar && (
                <div className="pt-3">
                  <button
                    onClick={() => onPracticeSimilar(question)}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-600 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 transition-all dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:border-blue-800 dark:hover:bg-blue-950/30 dark:hover:text-blue-400"
                  >
                    <Search className="h-3.5 w-3.5" />
                    <span>Practice Similar Questions</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
