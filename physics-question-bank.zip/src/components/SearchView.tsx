import { useData } from '../context/DataContext';
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Question, Difficulty, QuestionType } from '../types';
import { Search, Filter, RotateCcw, ArrowRight, Award, AlertTriangle, BookOpen, ChevronDown } from 'lucide-react';
import useWindowSize from 'react-use/lib/useWindowSize';

interface SearchViewProps {
  onPracticeQuestion: (classId: number, chapter: string, questionId: string) => void;
}

export default function SearchView({ onPracticeQuestion }: SearchViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  // Query String
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Dropdown states
  const [selectedClass, setSelectedClass] = useState<number | 'all'>('all');
  const [selectedChapter, setSelectedChapter] = useState<string | 'all'>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'all'>('all');
  const [selectedType, setSelectedType] = useState<QuestionType | 'all'>('all');
  const [selectedMarks, setSelectedMarks] = useState<number | 'all'>('all');

  const handleResetFilters = () => {
    setQuery('');
    setSelectedClass('all');
    setSelectedChapter('all');
    setSelectedDifficulty('all');
    setSelectedType('all');
    setSelectedMarks('all');
  };

  // Click outside to close suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Compute available chapters for the selected class
  const availableChapters = useMemo(() => {
    if (selectedClass === 'all') return CHAPTERS_DATA;
    return CHAPTERS_DATA.filter(c => c.classId === selectedClass);
  }, [selectedClass]);

  // When class changes, reset chapter if it doesn't belong to the new class
  useEffect(() => {
    if (selectedChapter !== 'all' && selectedClass !== 'all') {
      const isValid = CHAPTERS_DATA.find(c => c.id === selectedChapter && c.classId === selectedClass);
      if (!isValid) setSelectedChapter('all');
    }
  }, [selectedClass]);

  // Generate suggestions based on query
  const suggestions = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (term.length < 2) return [];

    const results = new Set<string>();
    
    // Chapters
    CHAPTERS_DATA.forEach(ch => {
      if (ch.name.toLowerCase().includes(term)) {
        results.add(ch.name);
      }
    });

    // Concepts
    PHYSICS_QUESTIONS.forEach(q => {
      if (q.relatedConcept && q.relatedConcept.toLowerCase().includes(term)) {
        results.add(q.relatedConcept);
      }
    });

    return Array.from(results).slice(0, 5);
  }, [query]);

  // Instant Query execution
  const searchResults = useMemo(() => {
    const term = query.trim().toLowerCase();

    return PHYSICS_QUESTIONS.filter(q => {
      // Class Level Match
      if (selectedClass !== 'all' && q.class !== selectedClass) return false;
      
      // Chapter Match
      if (selectedChapter !== 'all' && q.chapter !== selectedChapter) return false;

      // Difficulty Match
      if (selectedDifficulty !== 'all' && q.difficulty !== selectedDifficulty) return false;

      // Question Type Match
      if (selectedType !== 'all' && q.type !== selectedType) return false;
      
      // Marks Match
      if (selectedMarks !== 'all' && q.marks !== selectedMarks) return false;

      // Search keyword matches
      if (term) {
        const textMatch = q.question.toLowerCase().includes(term);
        const explanationMatch = q.explanation.toLowerCase().includes(term);
        const conceptMatch = q.relatedConcept ? q.relatedConcept.toLowerCase().includes(term) : false;
        const chapter = CHAPTERS_DATA.find(ch => ch.id === q.chapter);
        const chapterMatch = chapter ? chapter.name.toLowerCase().includes(term) : false;
        
        if (!textMatch && !explanationMatch && !chapterMatch && !conceptMatch) return false;
      }

      return true;
    });
  }, [query, selectedClass, selectedChapter, selectedDifficulty, selectedType, selectedMarks]);

  const difficultyColors = {
    easy: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/30',
    medium: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/30',
    hard: 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-900/30'
  };

  return (
    <div id="search-hub" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-black tracking-tight text-slate-950 dark:text-white">
          Syllabus Search Engine
        </h1>
        <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">
          Advanced search by keyword, chapter, class, difficulty, question type, and marks.
        </p>
      </div>

      {/* Main Search Controller bar */}
      <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/60 dark:border-slate-800/60 rounded-3xl p-5 shadow-lg shadow-slate-100/30 dark:shadow-none space-y-4">
        <div className="relative" ref={searchContainerRef}>
          <input
            type="text"
            id="search-input-main"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search keywords, laws, concepts, or chapters..."
            className="w-full rounded-2xl border border-slate-200 bg-white/50 pl-12 pr-4 py-3.5 font-sans text-sm font-medium text-slate-850 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white dark:focus:border-blue-500"
          />
          <Search className="absolute left-4 top-4 h-5 w-5 text-slate-400 dark:text-slate-500" />
          
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              {suggestions.map((suggestion, idx) => (
                <div 
                  key={idx}
                  onClick={() => {
                    setQuery(suggestion);
                    setShowSuggestions(false);
                  }}
                  className="px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer flex items-center gap-3 transition-colors border-b border-slate-100 dark:border-slate-800 last:border-0"
                >
                  <Search className="h-4 w-4 text-slate-400" />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{suggestion}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="space-y-1.5">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Class
            </label>
            <div className="relative">
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value === 'all' ? 'all' : parseInt(e.target.value))}
                className="w-full appearance-none rounded-xl border border-slate-250 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-white pr-8"
              >
                <option value="all">Any Class</option>
                {[6, 7, 8, 9, 10].map(cNum => (
                  <option key={cNum} value={cNum}>Class {cNum}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Chapter
            </label>
            <div className="relative">
              <select
                value={selectedChapter}
                onChange={(e) => setSelectedChapter(e.target.value)}
                className="w-full appearance-none rounded-xl border border-slate-250 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-white pr-8 truncate"
              >
                <option value="all">Any Chapter</option>
                {availableChapters.map(ch => (
                  <option key={ch.id} value={ch.id}>{ch.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Difficulty
            </label>
            <div className="relative">
              <select
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value as Difficulty | 'all')}
                className="w-full appearance-none rounded-xl border border-slate-250 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-white pr-8"
              >
                <option value="all">Any Difficulty</option>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Format
            </label>
            <div className="relative">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as QuestionType | 'all')}
                className="w-full appearance-none rounded-xl border border-slate-250 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-white pr-8"
              >
                <option value="all">Any Format</option>
                <option value="mcq">MCQ</option>
                <option value="true_false">True/False</option>
                <option value="fill_blank">Fill in the Blank</option>
                <option value="numerical">Numerical</option>
                <option value="short_answer">Short Answer</option>
                <option value="long_answer">Long Answer</option>
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
          </div>
          
          <div className="space-y-1.5">
            <label className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Marks
            </label>
            <div className="relative">
              <select
                value={selectedMarks}
                onChange={(e) => setSelectedMarks(e.target.value === 'all' ? 'all' : parseInt(e.target.value))}
                className="w-full appearance-none rounded-xl border border-slate-250 bg-white px-3 py-2.5 font-sans text-xs font-bold text-slate-750 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-white pr-8"
              >
                <option value="all">Any Marks</option>
                <option value="1">1 Mark</option>
                <option value="2">2 Marks</option>
                <option value="3">3 Marks</option>
                <option value="4">4 Marks</option>
                <option value="5">5 Marks</option>
              </select>
              <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 text-xs font-bold font-sans text-slate-500 dark:text-slate-400">
          <span>Found {searchResults.length} matching questions</span>
          <button
            onClick={handleResetFilters}
            className="text-blue-600 hover:underline flex items-center gap-1 dark:text-blue-400 cursor-pointer"
          >
            <RotateCcw className="h-3 w-3" /> Clear filters
          </button>
        </div>
      </div>

      {/* Results list */}
      <div id="search-results-list" className="space-y-4">
        {searchResults.length > 0 ? (
          searchResults.map((q) => {
            const ch = CHAPTERS_DATA.find(c => c.id === q.chapter);
            return (
              <div
                key={q.id}
                id={`search-card-${q.id}`}
                className="group rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 hover:shadow-xl hover:border-blue-500/50 hover:-translate-y-0.5 transition-all duration-300 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-[10px] font-extrabold tracking-wider">
                    <span className="rounded bg-blue-50 px-2 py-0.5 text-blue-700 border border-blue-100/50 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-900/30">
                      Class {q.class}
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">•</span>
                    <span className="text-slate-500 dark:text-slate-400 max-w-xs truncate">
                      {ch?.name}
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">•</span>
                    <span className={`rounded border px-2 py-0.5 uppercase tracking-wide ${difficultyColors[q.difficulty]}`}>
                      {q.difficulty}
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">•</span>
                    <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                      <Award className="h-3 w-3" /> {q.marks} {q.marks === 1 ? 'Mark' : 'Marks'}
                    </span>
                  </div>

                  <p className="font-sans text-sm md:text-base font-bold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-150 leading-relaxed">
                    {q.question}
                  </p>
                </div>

                <div className="shrink-0">
                  <button
                    id={`btn-solve-search-${q.id}`}
                    onClick={() => onPracticeQuestion(q.class, q.chapter, q.id)}
                    className="group flex w-full sm:w-auto items-center justify-center gap-1.5 rounded-xl bg-blue-50/70 text-blue-700 px-4 py-2.5 font-sans text-xs font-bold hover:bg-blue-100 hover:text-blue-800 transition-all dark:bg-blue-950/40 dark:text-blue-400 cursor-pointer"
                  >
                    <span>Solve in Practice Hub</span>
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div id="search-empty-slate" className="flex flex-col items-center justify-center text-center py-16 px-4 border border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white/50 dark:bg-slate-900/10">
            <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 p-4 text-amber-600 dark:text-amber-400 mb-4">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              No matching questions found
            </h3>
            <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-sm font-medium">
              Verify your keyword spelling or try loosening your filter constraints.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

