import { useData } from '../context/DataContext';
import React, { useState, useMemo, useEffect } from 'react';
import { UserProgress } from '../types';
import { Atom, FileText, ArrowRight, Star, Sparkles, Compass, Flame, ShieldCheck, Zap, HelpCircle } from 'lucide-react';

interface HomeViewProps {
  onSelectClass: (classId: number) => void;
  onViewChange: (view: string) => void;
  progress: UserProgress;
  onQuickStartQuiz: (classId: number, chapter: string, difficulty: 'easy' | 'hard' | 'all') => void;
}

export default function HomeView({
  onSelectClass,
  onViewChange,
  progress,
  onQuickStartQuiz
}: HomeViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  // Quick Start Quiz States
  const [quickClass, setQuickClass] = useState<number>(10);
  const [quickChapter, setQuickChapter] = useState<string>('all');
  const [quickDifficulty, setQuickDifficulty] = useState<'easy' | 'hard' | 'all'>('all');

  // Reset selected chapter when class selection changes
  useEffect(() => {
    setQuickChapter('all');
  }, [quickClass]);

  // Dynamic statistics
  const stats = useMemo(() => {
    const solvedKeys = Object.keys(progress.solvedQuestions);
    const solvedCount = solvedKeys.length;
    
    let correctCount = 0;
    let solvedToday = 0;
    const todayStr = new Date().toISOString().split('T')[0];

    solvedKeys.forEach(k => {
      const sq = progress.solvedQuestions[k];
      if (sq.isCorrect) {
        correctCount++;
      }
      if (sq.timestamp.startsWith(todayStr)) {
        solvedToday++;
      }
    });

    const accuracy = solvedCount > 0 ? Math.round((correctCount / solvedCount) * 100) : 0;
    const totalQCount = PHYSICS_QUESTIONS.length || 100;
    const curriculumProgress = Math.min(100, Math.round((solvedCount / totalQCount) * 100));

    return {
      solvedCount,
      accuracy,
      curriculumProgress,
      solvedToday
    };
  }, [progress]);

  // Load favorite chapters list
  const favoriteChaptersList = useMemo(() => {
    return CHAPTERS_DATA.filter(ch => progress.favoriteChapters.includes(ch.id)).slice(0, 4);
  }, [progress.favoriteChapters]);

  // Chapters list for quick start quiz dropdown
  const quickChaptersList = useMemo(() => {
    return CHAPTERS_DATA.filter(ch => ch.classId === quickClass);
  }, [quickClass]);

  // Question of the Day
  const qotd = useMemo(() => {
    const today = new Date();
    const hash = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
    // Use the hash to predictably pick a question
    const index = hash % PHYSICS_QUESTIONS.length;
    return PHYSICS_QUESTIONS[index];
  }, []);

  // Helper for dynamic card tags and styling per Class
  const getClassConfig = (classId: number) => {
    switch (classId) {
      case 6:
        return {
          tag: 'Foundation',
          tagClass: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30',
          borderClass: 'border-slate-200/60 dark:border-slate-800/60 hover:border-emerald-500/60 hover:shadow-emerald-100/30 dark:hover:shadow-none'
        };
      case 7:
        return {
          tag: 'Foundation',
          tagClass: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30',
          borderClass: 'border-slate-200/60 dark:border-slate-800/60 hover:border-emerald-500/60 hover:shadow-emerald-100/30 dark:hover:shadow-none'
        };
      case 8:
        return {
          tag: 'Core Skills',
          tagClass: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-100 dark:border-blue-900/30',
          borderClass: 'border-slate-200/60 dark:border-slate-800/60 hover:border-blue-500/60 hover:shadow-blue-100/30 dark:hover:shadow-none'
        };
      case 9:
        return {
          tag: 'Advanced',
          tagClass: 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400 border border-purple-100 dark:border-purple-900/30',
          borderClass: 'border-slate-200/60 dark:border-slate-800/60 hover:border-purple-500/60 hover:shadow-purple-100/30 dark:hover:shadow-none'
        };
      case 10:
        return {
          tag: 'Board Prep',
          tagClass: 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30',
          borderClass: 'border-slate-200/60 dark:border-slate-800/60 border-l-4 border-l-blue-600 dark:border-l-l-blue-500 hover:border-blue-500/60'
        };
      default:
        return {
          tag: 'General',
          tagClass: 'bg-slate-50 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-100 dark:border-slate-750',
          borderClass: 'border-slate-200'
        };
    }
  };

  return (
    <div id="home-view" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* 3-Column Bento/High-Density Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* COLUMN 1 (LEFT SIDEBAR): USER METRICS & FAVS */}
        <aside className="lg:col-span-3 flex flex-col gap-6">
          {/* User Card */}
          <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-2xl p-5 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative">
                <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 dark:from-blue-500 dark:to-indigo-500 flex items-center justify-center font-display font-extrabold text-white text-sm shadow-md">
                  SD
                </div>
                <span className="absolute bottom-0 right-0 block h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-display font-extrabold text-slate-900 dark:text-white leading-tight">Souvik Dash</h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 font-medium tracking-wide">Physics Scholar</p>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-2.5 mb-4">
              <div className="bg-slate-50/50 dark:bg-slate-950/40 p-3 rounded-xl border border-slate-100/80 dark:border-slate-850/60">
                <p className="text-[9px] uppercase text-slate-400 dark:text-slate-500 font-extrabold tracking-wider mb-1">Solved</p>
                <p className="text-lg font-display font-black text-blue-600 dark:text-blue-400">{stats.solvedCount}</p>
              </div>
              <div className="bg-slate-50/50 dark:bg-slate-950/40 p-3 rounded-xl border border-slate-100/80 dark:border-slate-850/60">
                <p className="text-[9px] uppercase text-slate-400 dark:text-slate-500 font-extrabold tracking-wider mb-1">Accuracy</p>
                <p className="text-lg font-display font-black text-emerald-600 dark:text-emerald-400">{stats.accuracy}%</p>
              </div>
            </div>

            {/* Daily Goal */}
            <div className="space-y-2 mb-4 border-t border-slate-100 dark:border-slate-850 pt-4">
              <div className="flex justify-between text-[11px] font-bold">
                <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5 text-amber-500" /> Daily Goal</span>
                <span className="text-emerald-600 dark:text-emerald-400">{Math.min(5, stats.solvedToday)} / 5 Solved</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${Math.min(100, (stats.solvedToday / 5) * 100)}%` }}
                />
              </div>
              {stats.solvedToday >= 5 && (
                <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 mt-1">Goal reached! 🔥</p>
              )}
            </div>

            {/* Progress Slider */}
            <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-850">
              <div className="flex justify-between text-[11px] font-bold mt-3">
                <span className="text-slate-600 dark:text-slate-400">Curriculum Progress</span>
                <span className="text-blue-600 dark:text-blue-400">{stats.curriculumProgress}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${stats.curriculumProgress}%` }}
                />
              </div>
            </div>
          </div>

          {/* Streak Banner */}
          <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-700 dark:from-blue-750 dark:via-blue-800 dark:to-indigo-850 rounded-2xl p-5 text-white shadow-lg shadow-blue-500/10 relative overflow-hidden group">
            {/* Ambient visual background glow elements */}
            <div className="absolute right-0 bottom-0 w-32 h-32 bg-white/5 rounded-full blur-2xl group-hover:bg-white/10 transition-all duration-500" />
            <div className="absolute right-2 top-2 text-white/10">
              <Flame className="w-20 h-20 fill-white/10 text-transparent transition-transform duration-500 group-hover:scale-110" />
            </div>
            <div className="relative z-10 space-y-2.5">
              <h3 className="text-[10px] font-extrabold uppercase tracking-widest text-blue-100">Current Streak</h3>
              <div className="flex items-end gap-1.5">
                <span className="text-4xl font-display font-black leading-none">{progress.streak}</span>
                <span className="text-xs font-bold opacity-90 mb-0.5">{progress.streak === 1 ? 'Day' : 'Days'} Active</span>
              </div>
              <p className="text-[11px] opacity-85 leading-relaxed font-medium">
                You're in the top 5% of active learners this week! Keep up the daily momentum to unlock achievements.
              </p>
            </div>
          </div>

          {/* Favorite Chapters Box */}
          <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-2xl p-5 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none flex-1">
            <h3 className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-widest mb-3 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-850 pb-2">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>Favorite Chapters</span>
            </h3>
            {favoriteChaptersList.length > 0 ? (
              <ul className="space-y-3 pt-1">
                {favoriteChaptersList.map((ch, i) => {
                  const colors = ['bg-amber-400', 'bg-blue-400', 'bg-purple-400', 'bg-emerald-400'];
                  return (
                    <li key={ch.id} className="flex items-center gap-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <span className={`w-2 h-2 rounded-full ${colors[i % colors.length]} shrink-0`} />
                      <span className="truncate flex-1 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">{ch.name}</span>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="text-xs text-slate-400 dark:text-slate-500 py-4 leading-relaxed font-medium">
                No bookmarked chapters. Visit standard classes and toggle the star symbol to add favorites here!
              </p>
            )}
          </div>
        </aside>

        {/* COLUMN 2 (CENTER): HERO BANNER & CLASS CARD GRID */}
        <section className="col-span-1 lg:col-span-6 flex flex-col gap-6">
          {/* Hero Banner Section */}
          <div className="bg-gradient-to-br from-blue-50/80 via-white/95 to-indigo-50/40 dark:from-slate-900/90 dark:via-slate-900/80 dark:to-indigo-950/20 rounded-3xl p-6 sm:p-8 border border-slate-200/60 dark:border-slate-800/60 relative overflow-hidden shadow-xl shadow-slate-100/20 dark:shadow-none">
            {/* Glass glow blobs */}
            <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-blue-100/40 dark:bg-blue-900/10 rounded-full blur-3xl opacity-60" />
            <div className="absolute -left-12 -top-12 w-32 h-32 bg-indigo-100/40 dark:bg-indigo-900/10 rounded-full blur-2xl opacity-40" />
            
            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 rounded-full border border-blue-200/80 bg-blue-50/70 px-3 py-1 text-[10px] font-bold text-blue-700 dark:border-blue-900 dark:bg-blue-950/50 dark:text-blue-400 mb-4 shadow-sm">
                <Sparkles className="h-3 w-3 animate-pulse text-amber-500" />
                <span>Curriculum Mapped Standards (Class 6-10)</span>
              </div>
              
              <h1 className="text-3xl sm:text-4xl font-display font-black text-slate-900 dark:text-white leading-tight mb-3">
                Physics <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent dark:from-blue-400 dark:to-indigo-400">Question Bank</span>
              </h1>
              <p className="text-slate-500 dark:text-slate-400 max-w-lg text-xs sm:text-sm leading-relaxed mb-6 font-medium">
                Master fundamental physics principles, formulas, and laws from Class 6 to 10. Accelerate learning with interactive worksheets, speed-timed quizzes, and offline-ready exam papers.
              </p>
              
              <div className="flex flex-wrap gap-2.5">
                <button
                  id="btn-hero-learn"
                  onClick={() => onViewChange('classes')}
                  className="bg-blue-600 text-white hover:bg-blue-700 px-5 py-3 rounded-xl font-bold text-xs shadow-md shadow-blue-500/15 cursor-pointer flex items-center gap-1.5 transition-all hover:translate-x-0.5"
                >
                  <span>Start Learning</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  id="btn-hero-browse"
                  onClick={() => onViewChange('search')}
                  className="bg-white/80 border border-slate-200 text-slate-700 hover:bg-slate-50 px-5 py-3 rounded-xl font-bold text-xs dark:bg-slate-800/80 dark:border-slate-750 dark:text-slate-300 dark:hover:bg-slate-700 flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                >
                  <Compass className="w-3.5 h-3.5 text-blue-500" />
                  <span>Browse All Questions</span>
                </button>
                <button
                  id="btn-hero-random"
                  onClick={() => onQuickStartQuiz(Math.floor(Math.random() * 5) + 6, 'all', 'all')}
                  className="bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 px-5 py-3 rounded-xl font-bold text-xs dark:bg-indigo-950/40 dark:border-indigo-800/40 dark:text-indigo-300 dark:hover:bg-indigo-900/60 flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                  <span>🎲 Random Challenge</span>
                </button>
              </div>
            </div>
          </div>

          {/* Question of the Day */}
          {qotd && (
            <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-3xl p-5 md:p-6 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none flex flex-col md:flex-row gap-5 items-start md:items-center">
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-400 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-500" /> Question of the Day
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                    Class {qotd.classId}
                  </span>
                </div>
                <h3 className="text-sm md:text-base font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                  {qotd.text}
                </h3>
              </div>
              <button
                onClick={() => onQuickStartQuiz(qotd.classId, qotd.chapterId, 'all')}
                className="shrink-0 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 dark:bg-blue-950/30 dark:text-blue-400 dark:border-blue-900/50 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <span>Solve Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Classes Grid */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest pl-1">
              Choose Your Class Level
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {CLASSES_DATA.map((cls) => {
                const config = getClassConfig(cls.id);
                return (
                  <div
                    key={cls.id}
                    id={`class-card-${cls.id}`}
                    onClick={() => onSelectClass(cls.id)}
                    className={`bg-white/75 dark:bg-slate-900/80 p-5 rounded-2xl border ${config.borderClass} hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group flex flex-col justify-between h-44 shadow-sm`}
                  >
                    <div>
                      <div className="flex justify-between items-start mb-3">
                        <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded ${config.tagClass}`}>
                          {config.tag}
                        </span>
                        <div className="w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center font-display font-black text-xs group-hover:bg-blue-600 group-hover:text-white dark:group-hover:bg-blue-500 group-hover:shadow-md transition-all duration-300">
                          0{cls.id}
                        </div>
                      </div>
                      <h4 className="font-display font-extrabold text-base text-slate-900 dark:text-white mb-2 leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200">
                        Class {cls.id} Physics
                      </h4>
                    </div>

                    <div className="grid grid-cols-2 gap-y-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-850/60 text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                      <span>Chapters: {cls.chaptersCount}</span>
                      <span>Worksheets: {cls.worksheetsCount}</span>
                      <span className="col-span-2 text-blue-600 dark:text-blue-400 font-bold">Questions: {cls.questionsCount}+ Available</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* COLUMN 3 (RIGHT SIDEBAR): ACTIVITY LOG & QUICK TEST START */}
        <aside className="lg:col-span-3 flex flex-col gap-6">
          
          {/* Recent Activity Card */}
          <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-2xl p-5 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none">
            <h3 className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-widest mb-4 border-b border-slate-100 dark:border-slate-850 pb-2">
              Recent Activity
            </h3>
            
            <div className="space-y-4">
              {progress.quizAttempts.length > 0 ? (
                progress.quizAttempts.slice(-3).reverse().map((attempt) => (
                  <div key={attempt.id} className="flex gap-2.5 items-start">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 leading-tight">
                        Quiz: Class {attempt.classId} {CHAPTERS_DATA.find(c => c.id === attempt.chapterId)?.name || 'General'}
                      </p>
                      <p className="text-[9px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">
                        Score: {attempt.score}/{attempt.total} • {attempt.percentage}%
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <>
                  <div className="flex gap-2.5 items-start">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 leading-tight">Ready to start first quiz</p>
                      <p className="text-[9px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">Select a chapter below and test your knowledge!</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <span className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 leading-tight">Curriculum Initialized</p>
                      <p className="text-[9px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">Syllabus databases active for classes 6 to 10.</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <span className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-750 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 leading-tight">Setup Target Accuracy</p>
                      <p className="text-[9px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">Aim for 90%+ correct answers on the dashboard.</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Weekly Leaderboard (Mock) */}
          <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-2xl p-5 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none">
            <h3 className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-widest mb-4 border-b border-slate-100 dark:border-slate-850 pb-2">
              🏆 Weekly Leaderboard
            </h3>
            <div className="space-y-3">
              {[
                { name: 'Sarah M.', score: 1240, rank: 1, color: 'text-amber-500' },
                { name: 'David K.', score: 1120, rank: 2, color: 'text-slate-400' },
                { name: 'Aisha R.', score: 980, rank: 3, color: 'text-amber-700 dark:text-amber-600' },
                { name: 'Souvik D. (You)', score: 850 + stats.solvedCount * 10, rank: 4, color: 'text-blue-500', isYou: true },
                { name: 'James W.', score: 790, rank: 5, color: 'text-slate-500' }
              ].map((user) => (
                <div key={user.rank} className={`flex items-center justify-between p-2 rounded-lg ${user.isYou ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30' : ''}`}>
                  <div className="flex items-center gap-3">
                    <span className={`font-display font-bold text-sm ${user.color}`}>#{user.rank}</span>
                    <span className={`font-sans text-xs font-semibold ${user.isYou ? 'text-blue-700 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300'}`}>{user.name}</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-slate-500 dark:text-slate-400">{user.score} pt</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Start Quiz Block */}
          <div className="bg-white/70 dark:bg-slate-900/75 backdrop-blur-md rounded-2xl p-5 border border-slate-200/60 dark:border-slate-800/60 shadow-lg shadow-slate-100/40 dark:shadow-none flex-grow">
            <h3 className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-widest mb-4 border-b border-slate-100 dark:border-slate-850 pb-2">
              Quick Start Quiz
            </h3>
            
            <div className="space-y-4">
              {/* Select Class */}
              <div className="space-y-1">
                <label className="text-[9px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wide block">
                  Select Grade Level
                </label>
                <select
                  value={quickClass}
                  onChange={(e) => setQuickClass(parseInt(e.target.value))}
                  className="w-full text-xs bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-xl p-2.5 font-medium text-slate-750 dark:text-slate-300 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  {[6, 7, 8, 9, 10].map(cNum => (
                    <option key={cNum} value={cNum}>Class {cNum} Physics</option>
                  ))}
                </select>
              </div>

              {/* Select Chapter */}
              <div className="space-y-1">
                <label className="text-[9px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wide block">
                  Chapter Selection
                </label>
                <select
                  value={quickChapter}
                  onChange={(e) => setQuickChapter(e.target.value)}
                  className="w-full text-xs bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-xl p-2.5 font-medium text-slate-750 dark:text-slate-300 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="all">All Chapters</option>
                  {quickChaptersList.map(ch => (
                    <option key={ch.id} value={ch.id}>{ch.name}</option>
                  ))}
                </select>
              </div>

              {/* Difficulty Level Buttons */}
              <div className="space-y-1.5">
                <label className="text-[9px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wide block">
                  Difficulty Level
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setQuickDifficulty('all')}
                    className={`flex-1 py-1.5 px-2 border text-[10px] font-extrabold rounded-lg cursor-pointer transition-all ${
                      quickDifficulty === 'all'
                        ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900/60 dark:bg-blue-950/40 dark:text-blue-400 shadow-sm'
                        : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900'
                    }`}
                  >
                    Any
                  </button>
                  <button
                    onClick={() => setQuickDifficulty('easy')}
                    className={`flex-1 py-1.5 px-2 border text-[10px] font-extrabold rounded-lg cursor-pointer transition-all ${
                      quickDifficulty === 'easy'
                        ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900/60 dark:bg-blue-950/40 dark:text-blue-400 shadow-sm'
                        : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900'
                    }`}
                  >
                    Easy
                  </button>
                  <button
                    onClick={() => setQuickDifficulty('hard')}
                    className={`flex-1 py-1.5 px-2 border text-[10px] font-extrabold rounded-lg cursor-pointer transition-all ${
                      quickDifficulty === 'hard'
                        ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900/60 dark:bg-blue-950/40 dark:text-blue-400 shadow-sm'
                        : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900'
                    }`}
                  >
                    Hard
                  </button>
                </div>
              </div>

              {/* Begin Test Action */}
              <button
                onClick={() => onQuickStartQuiz(quickClass, quickChapter, quickDifficulty)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-3 rounded-xl text-xs mt-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-500/10 hover:shadow-lg hover:shadow-blue-500/20"
              >
                <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300 animate-pulse" />
                <span>Begin 15 Min Quiz</span>
              </button>
            </div>
          </div>
        </aside>

      </div>
    </div>
  );
}
