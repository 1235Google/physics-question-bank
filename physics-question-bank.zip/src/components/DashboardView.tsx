import { useData } from '../context/DataContext';
import React, { useMemo } from 'react';
import { UserProgress, Chapter } from '../types';
import { Award, Zap, FileText, CheckCircle, Flame, Star, Activity, ArrowRight, HelpCircle, AlertCircle, TrendingUp, Bookmark } from 'lucide-react';

interface DashboardViewProps {
  progress: UserProgress;
  onPracticeChapter: (classId: number, chapter: string) => void;
  onRemoveFavorite: (chapter: string) => void;
  onPracticeQuestion?: (classId: number, chapter: string, questionId: string) => void;
  onClaimDailyReward?: () => void;
}

export default function DashboardView({
  progress,
  onPracticeChapter,
  onRemoveFavorite,
  onPracticeQuestion,
  onClaimDailyReward
}: DashboardViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  
  // Computes statistics based on recorded progress
  const stats = useMemo(() => {
    const solvedKeys = Object.keys(progress.solvedQuestions);
    const solvedCount = solvedKeys.length;
    
    let correctCount = 0;
    let thisWeekCount = 0;
    let thisMonthCount = 0;
    const now = new Date();
    
    // Calculate week and month bounds
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - now.getDay()); // Sunday of this week
    weekStart.setHours(0, 0, 0, 0);
    
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    solvedKeys.forEach(k => {
      const q = progress.solvedQuestions[k];
      if (q.isCorrect) {
        correctCount++;
      }
      
      const qDate = new Date(q.timestamp);
      if (qDate >= weekStart) {
        thisWeekCount++;
      }
      if (qDate >= monthStart) {
        thisMonthCount++;
      }
    });

    const accuracy = solvedCount > 0 ? Math.round((correctCount / solvedCount) * 100) : 0;
    const worksheetsCount = progress.completedWorksheets.length;
    const quizzesCount = progress.quizAttempts.length;

    // Accuracy per class calculation
    const classAccuracy = [6, 7, 8, 9, 10].map(cNum => {
      const keysForClass = solvedKeys.filter(k => k.startsWith(`c${cNum}_`));
      const total = keysForClass.length;
      const correct = keysForClass.filter(k => progress.solvedQuestions[k].isCorrect).length;
      return {
        classId: cNum,
        percentage: total > 0 ? Math.round((correct / total) * 100) : 0,
        total
      };
    });

    // Accuracy per chapter to find strongest/weakest
    const chapterStats: Record<string, { total: number, correct: number }> = {};
    solvedKeys.forEach(k => {
      const qIdParts = k.split('_');
      // Format: c6_ch1_q1 -> classId_chapterId_questionId
      if (qIdParts.length >= 3) {
        const chapterId = qIdParts[1];
        if (!chapterStats[chapterId]) chapterStats[chapterId] = { total: 0, correct: 0 };
        chapterStats[chapterId].total++;
        if (progress.solvedQuestions[k].isCorrect) chapterStats[chapterId].correct++;
      }
    });

    const chapterAccuracy = Object.entries(chapterStats).map(([chapterId, data]) => ({
      chapterId,
      percentage: data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0,
      total: data.total
    })).filter(c => c.total >= 3); // Minimum 3 questions to be considered strongest/weakest

    chapterAccuracy.sort((a, b) => b.percentage - a.percentage);
    const strongestChapters = chapterAccuracy.slice(0, 2);
    const weakestChapters = chapterAccuracy.slice(-2).reverse();

    // Average Quiz Score
    const totalQuizScore = progress.quizAttempts.reduce((acc, curr) => acc + curr.percentage, 0);
    const avgQuizScore = quizzesCount > 0 ? Math.round(totalQuizScore / quizzesCount) : 0;

    // Use stored XP, or fallback to calculated if it's an old save
    let xp = progress.xp;
    if (xp === 0 && solvedCount > 0) {
      xp += solvedCount * 10;
      xp += progress.quizAttempts.reduce((acc, curr) => acc + (curr.percentage > 0 ? curr.percentage : 10), 0);
      xp += worksheetsCount * 50;
    }
    const coins = progress.coins;
    
    // Level calculation (e.g. 50 XP = level 2, 200 XP = level 3, 450 XP = level 4)
    const level = Math.floor(Math.sqrt(xp / 50)) + 1;
    const currentLevelXp = Math.pow(level - 1, 2) * 50;
    const nextLevelXp = Math.pow(level, 2) * 50;
    const levelProgress = Math.round(((xp - currentLevelXp) / (nextLevelXp - currentLevelXp)) * 100);

    let levelTitle = 'Novice';
    if (level >= 3) levelTitle = 'Beginner';
    if (level >= 5) levelTitle = 'Explorer';
    if (level >= 7) levelTitle = 'Scholar';
    if (level >= 10) levelTitle = 'Expert';
    if (level >= 15) levelTitle = 'Master';
    if (level >= 25) levelTitle = 'Grandmaster';

    // Study Calendar Dates
    const activeDates = new Set<string>();
    solvedKeys.forEach(k => {
      const qDate = new Date(progress.solvedQuestions[k].timestamp).toISOString().split('T')[0];
      activeDates.add(qDate);
    });
    progress.quizAttempts.forEach(q => {
      const qDate = new Date(q.timestamp).toISOString().split('T')[0];
      activeDates.add(qDate);
    });
    if (progress.lastRewardDate) {
      activeDates.add(progress.lastRewardDate);
    }

    return {
      solvedCount,
      correctCount,
      accuracy,
      worksheetsCount,
      quizzesCount,
      classAccuracy,
      thisWeekCount,
      thisMonthCount,
      strongestChapters,
      weakestChapters,
      avgQuizScore,
      xp,
      coins,
      level,
      levelTitle,
      levelProgress,
      nextLevelXp,
      activeDates
    };
  }, [progress]);

  // Load actual Chapter definitions for bookmarked/favorite IDs
  const favoriteChaptersList = useMemo(() => {
    return CHAPTERS_DATA.filter(ch => progress.favoriteChapters.includes(ch.id));
  }, [progress.favoriteChapters]);

  // Milestone awards based on streak or achievements
  const milestones = [
    { id: 'm1', name: 'First Milestone', desc: 'Solved 1 question correctly', met: stats.solvedCount >= 1 },
    { id: 'm2', name: 'Worksheet Scholar', desc: 'Finished 1 physics worksheet', met: stats.worksheetsCount >= 1 },
    { id: 'm3', name: 'Quiz Master', desc: 'Attempted your first timed test', met: stats.quizzesCount >= 1 },
    { id: 'm4', name: 'Streak Starter', desc: 'Attained a 1+ active streak', met: progress.streak >= 1 },
    { id: 'm5', name: 'Scientific Genius', desc: 'Attained 80%+ overall accuracy', met: stats.solvedCount >= 5 && stats.accuracy >= 80 }
  ];

  // Check if daily reward is claimable
  const isRewardClaimable = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return progress.lastRewardDate !== today;
  }, [progress.lastRewardDate]);

  return (
    <div id="student-dashboard" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-black tracking-tight text-slate-950 dark:text-white">
          Student Dashboard
        </h1>
        <p className="font-sans text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">
          Monitor your scientific growth, daily activity streak, test performance, and unlocked achievements.
        </p>
      </div>

      {/* Daily Reward Banner */}
      {isRewardClaimable && onClaimDailyReward && (
        <div className="bg-gradient-to-r from-amber-400 to-orange-500 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 cursor-pointer hover:scale-[1.01] transition-transform" onClick={onClaimDailyReward}>
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-sm border-2 border-white/30 shrink-0">
              <Star className="h-8 w-8 text-white fill-white animate-pulse" />
            </div>
            <div>
              <h2 className="font-display text-2xl font-bold tracking-tight text-white">Daily Reward Available!</h2>
              <p className="text-amber-100 font-medium text-sm mt-1">
                Claim your daily XP and Coins to boost your level.
              </p>
            </div>
          </div>
          <button 
            className="px-6 py-3 rounded-full bg-white text-orange-600 font-bold text-sm shadow-lg hover:bg-orange-50 transition-colors whitespace-nowrap"
            onClick={(e) => {
              e.stopPropagation();
              onClaimDailyReward();
            }}
          >
            Claim Reward
          </button>
        </div>
      )}

      {/* User Level & XP */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="h-20 w-20 rounded-full bg-white/20 flex items-center justify-center border-4 border-white/30 backdrop-blur-sm">
              <span className="font-display text-3xl font-black text-white">{stats.level}</span>
            </div>
            <div className="absolute -bottom-2 -right-2 bg-amber-400 text-amber-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border-2 border-indigo-600">
              Level
            </div>
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight">{stats.levelTitle}</h2>
            <p className="text-blue-100 font-medium text-sm mt-1">
              You need {stats.nextLevelXp - stats.xp} more XP to reach Level {stats.level + 1}
            </p>
          </div>
        </div>
        <div className="w-full md:w-1/3 flex flex-col gap-4">
          <div className="flex justify-between items-center bg-white/10 px-4 py-2 rounded-xl backdrop-blur-sm border border-white/20">
            <span className="text-sm font-bold text-blue-100 flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-amber-400 flex items-center justify-center text-amber-900 font-black text-xs">C</div>
              Coins
            </span>
            <span className="font-display font-black text-xl text-amber-300">{stats.coins}</span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm font-bold text-blue-50">
              <span>{stats.xp} XP</span>
              <span>{stats.nextLevelXp} XP</span>
            </div>
            <div className="h-3 w-full rounded-full bg-black/20 overflow-hidden relative">
              <div 
                className="h-full bg-white rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${stats.levelProgress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards Grid */}
      <div id="dashboard-stats-grid" className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {/* Solved */}
        <div className="rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:-translate-y-0.5 hover:shadow-xl transition-all duration-300">
          <div className="h-12 w-12 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 flex items-center justify-center shrink-0">
            <CheckCircle className="h-6 w-6" />
          </div>
          <div>
            <span className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Total Solved</span>
            <span className="font-display text-2xl font-black text-slate-950 dark:text-white mt-0.5 block">{stats.solvedCount}</span>
          </div>
        </div>

        {/* Weekly Progress */}
        <div className="rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:-translate-y-0.5 hover:shadow-xl transition-all duration-300">
          <div className="h-12 w-12 rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Activity className="h-6 w-6" />
          </div>
          <div>
            <span className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">This Week</span>
            <span className="font-display text-2xl font-black text-slate-950 dark:text-white mt-0.5 block">{stats.thisWeekCount} <span className="text-sm font-bold text-slate-400">Qs</span></span>
          </div>
        </div>

        {/* Monthly Progress */}
        <div className="rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:-translate-y-0.5 hover:shadow-xl transition-all duration-300">
          <div className="h-12 w-12 rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <TrendingUp className="h-6 w-6" />
          </div>
          <div>
            <span className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">This Month</span>
            <span className="font-display text-2xl font-black text-slate-950 dark:text-white mt-0.5 block">{stats.thisMonthCount} <span className="text-sm font-bold text-slate-400">Qs</span></span>
          </div>
        </div>

        {/* Streak */}
        <div className="rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:-translate-y-0.5 hover:shadow-xl transition-all duration-300">
          <div className="h-12 w-12 rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 flex items-center justify-center shrink-0">
            <Flame className="h-6 w-6 text-amber-500 fill-amber-500 animate-bounce" />
          </div>
          <div>
            <span className="font-sans text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Day Streak</span>
            <span className="font-display text-xl sm:text-2xl font-black text-slate-950 dark:text-white mt-0.5 block">{progress.streak} {progress.streak === 1 ? 'Day' : 'Days'}</span>
          </div>
        </div>
      </div>

      {/* Main double column space */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column: Charts & favorite chapters */}
        <div className="lg:col-span-2 space-y-8">
          {/* Chart Card */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-850 pb-3">
              <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <span>Accuracy Performance per Class</span>
              </h3>
              <span className="font-sans text-xs font-bold text-blue-600 dark:text-blue-400">
                Overall Accuracy: {stats.accuracy}%
              </span>
            </div>

            {/* Custom SVG/HTML Bar Chart mapping accuracy */}
            <div className="space-y-4 pt-2">
              {stats.classAccuracy.map((cls) => (
                <div key={cls.classId} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs font-bold font-sans">
                    <span className="text-slate-700 dark:text-slate-300">Class {cls.classId} Physics</span>
                    <span className="text-slate-500 dark:text-slate-400">{cls.percentage}% Accuracy ({cls.total} solved)</span>
                  </div>
                  <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden relative">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${cls.percentage}%` }}
                    />
                    {cls.total === 0 && (
                      <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                        No Questions Solved Yet
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Strongest and Weakest Chapters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 space-y-4">
              <h3 className="font-display text-sm font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-2">
                <CheckCircle className="text-emerald-500 h-4 w-4" />
                <span>Strongest Concepts</span>
              </h3>
              {stats.strongestChapters.length > 0 ? (
                <div className="space-y-3">
                  {stats.strongestChapters.map(c => {
                    const chapter = CHAPTERS_DATA.find(ch => ch.id === c.chapterId);
                    return (
                      <div key={c.chapterId} className="flex justify-between items-center bg-slate-50 dark:bg-slate-800 p-2 rounded-lg">
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300 truncate pr-2">{chapter?.name || c.chapterId}</span>
                        <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 shrink-0">{c.percentage}%</span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-xs text-slate-500 text-center py-2">Not enough data yet.</div>
              )}
            </div>

            <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 space-y-4">
              <h3 className="font-display text-sm font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-2">
                <AlertCircle className="text-rose-500 h-4 w-4" />
                <span>Needs Review</span>
              </h3>
              {stats.weakestChapters.length > 0 ? (
                <div className="space-y-3">
                  {stats.weakestChapters.map(c => {
                    const chapter = CHAPTERS_DATA.find(ch => ch.id === c.chapterId);
                    return (
                      <div key={c.chapterId} className="flex justify-between items-center bg-slate-50 dark:bg-slate-800 p-2 rounded-lg">
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300 truncate pr-2">{chapter?.name || c.chapterId}</span>
                        <span className="text-xs font-black text-rose-600 dark:text-rose-400 shrink-0">{c.percentage}%</span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-xs text-slate-500 text-center py-2">Not enough data yet.</div>
              )}
            </div>
          </div>

          {/* Favorite Chapters shortcuts */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-4">
            <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <Star className="text-amber-500 fill-amber-500 h-5 w-5" />
              <span>Favorite Physics Chapters</span>
            </h3>

            {favoriteChaptersList.length > 0 ? (
              <div id="favorites-list" className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {favoriteChaptersList.map(ch => (
                  <div
                    key={ch.id}
                    className="rounded-xl border border-slate-100/80 bg-slate-50/50 p-4 dark:border-slate-850/50 dark:bg-slate-850/40 flex items-center justify-between gap-4 group hover:border-blue-500 transition-colors duration-200"
                  >
                    <div className="space-y-1 overflow-hidden">
                      <span className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400">Class {ch.classId}</span>
                      <h4 className="font-sans text-sm font-bold text-slate-900 dark:text-white truncate">
                        {ch.name}
                      </h4>
                    </div>
                    <button
                      id={`btn-fav-shortcut-${ch.id}`}
                      onClick={() => onPracticeChapter(ch.classId, ch.id)}
                      className="group/btn rounded-lg bg-white border border-slate-200 p-2 text-slate-500 hover:text-blue-600 hover:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-blue-400 shrink-0 transition-colors cursor-pointer"
                      title="Practice Chapter"
                    >
                      <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-0.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div id="favorites-empty" className="text-center py-8 text-slate-400 dark:text-slate-500 font-sans text-sm font-medium">
                <p>No favorite chapters bookmarked yet.</p>
                <p className="text-xs mt-1 text-slate-400/85">Browse standard Classes to toggle stars on chapters.</p>
              </div>
            )}
          </div>

          {/* Bookmarked Questions */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-4">
            <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <Bookmark className="text-amber-600 fill-amber-100 dark:text-amber-400 dark:fill-amber-900/50 h-5 w-5" />
              <span>Bookmarked for Revision</span>
            </h3>

            {(progress.bookmarkedQuestions && progress.bookmarkedQuestions.length > 0) ? (
              <div className="space-y-3">
                {progress.bookmarkedQuestions.map(qId => {
                  const q = PHYSICS_QUESTIONS.find(pq => pq.id === qId);
                  if (!q) return null;
                  return (
                    <div key={q.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex justify-between gap-4 group">
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Class {q.class}</span>
                        <p className="font-sans text-sm font-bold text-slate-800 dark:text-slate-200 line-clamp-2">
                          {q.question}
                        </p>
                      </div>
                      <button
                        onClick={() => onPracticeQuestion && onPracticeQuestion(q.class, q.chapter, q.id)}
                        className="group/btn rounded-lg bg-slate-50 border border-slate-200 p-2 text-slate-500 hover:text-blue-600 hover:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-blue-400 shrink-0 transition-colors self-center cursor-pointer"
                        title="Practice Question"
                      >
                        <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-0.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-400 dark:text-slate-500 font-sans text-sm font-medium">
                <p>No questions bookmarked for revision.</p>
                <p className="text-xs mt-1 text-slate-400/85">Flag difficult questions during quizzes to save them here.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right column: achievements & history */}
        <div className="space-y-8">
          {/* Study Calendar */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-4">
            <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <TrendingUp className="h-5 w-5 text-indigo-600" />
              <span>Study Consistency</span>
            </h3>
            
            <div className="grid grid-cols-7 gap-1.5 pt-2">
              {['S','M','T','W','T','F','S'].map((day, i) => (
                <div key={i} className="text-center text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1">{day}</div>
              ))}
              {Array.from({ length: 28 }).map((_, i) => {
                // Generate last 28 days
                const d = new Date();
                d.setDate(d.getDate() - (27 - i));
                const dateStr = d.toISOString().split('T')[0];
                const isActive = stats.activeDates.has(dateStr);
                
                return (
                  <div 
                    key={i} 
                    title={dateStr}
                    className={`aspect-square rounded-md border ${
                      isActive 
                        ? 'bg-emerald-400 border-emerald-500 shadow-[0_0_8px_rgba(52,211,153,0.4)] dark:bg-emerald-500 dark:border-emerald-600' 
                        : 'bg-slate-100 border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                    }`}
                  />
                );
              })}
            </div>
            <p className="text-[10px] text-center text-slate-500 font-medium pt-2">Last 28 days of activity</p>
          </div>

          {/* Milestone Badges */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-4">
            <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <Award className="h-5 w-5 text-blue-600" />
              <span>Syllabus Badges</span>
            </h3>

            <div className="space-y-3">
              {milestones.map((m) => (
                <div
                  key={m.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                    m.met
                      ? 'border-blue-100 bg-blue-50/20 dark:border-blue-900/40 dark:bg-blue-950/10'
                      : 'border-slate-100 bg-slate-50/40 opacity-40 dark:border-slate-850/40 dark:bg-slate-850/20'
                  }`}
                >
                  <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 border ${
                    m.met
                      ? 'border-blue-300 bg-blue-100 text-blue-600 dark:border-blue-800 dark:bg-blue-900 dark:text-blue-400'
                      : 'border-slate-300 bg-slate-200 text-slate-400 dark:border-slate-700 dark:bg-slate-800'
                  }`}>
                    <Flame className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="font-sans text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {m.name}
                    </h4>
                    <p className="font-sans text-[11px] text-slate-500 dark:text-slate-400">
                      {m.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Past Quiz History Log */}
          <div className="rounded-3xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 md:p-6 shadow-lg shadow-slate-100/30 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-850 pb-3">
              <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white flex items-center gap-2">
                <Activity className="h-5 w-5 text-blue-600" />
                <span>Test History Log</span>
              </h3>
              <div className="text-right">
                <span className="block text-[10px] font-bold text-slate-400 uppercase">Avg Score</span>
                <span className="block font-black text-sm text-blue-600 dark:text-blue-400">{stats.avgQuizScore}%</span>
              </div>
            </div>

            {progress.quizAttempts.length > 0 ? (
              <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {progress.quizAttempts.slice().reverse().map((att) => (
                  <div
                    key={att.id}
                    className="p-3.5 border border-slate-100 bg-slate-50/30 rounded-xl text-xs space-y-1.5 dark:border-slate-850 dark:bg-slate-850/30"
                  >
                    <div className="flex justify-between font-bold text-slate-800 dark:text-slate-200">
                      <span>Class {att.classId} Quiz</span>
                      <span className={att.percentage >= 85 ? 'text-emerald-600 font-extrabold' : att.percentage >= 50 ? 'text-blue-600 font-extrabold' : 'text-slate-500'}>
                        {att.percentage}%
                      </span>
                    </div>
                    <div className="flex justify-between font-semibold text-slate-400 dark:text-slate-500">
                      <span>Score: {att.score} / {att.total}</span>
                      <span>Time: {Math.floor(att.timeTaken / 60)}m {att.timeTaken % 60}s</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 dark:text-slate-500 font-sans text-xs font-medium">
                No past quiz sessions recorded. Select Quiz on the navbar to take a test.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
