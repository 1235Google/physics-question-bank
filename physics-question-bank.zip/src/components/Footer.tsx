import React from 'react';
import { Atom, Shield, HelpCircle, BookOpen, Heart } from 'lucide-react';

interface FooterProps {
  onViewChange: (view: string) => void;
}

export default function Footer({ onViewChange }: FooterProps) {
  return (
    <footer id="app-footer" className="mt-auto border-t bg-slate-50 dark:border-slate-800 dark:bg-slate-950/80 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white dark:bg-blue-500">
                <Atom className="h-5 w-5" />
              </div>
              <span className="font-sans text-base font-bold tracking-tight text-slate-950 dark:text-white">
                Physics Question Bank
              </span>
            </div>
            <p className="font-sans text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              An interactive, comprehensive study and worksheet platform designed specifically for students in Classes 6 through 10. Learn, practice, and test physical concepts effectively.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-4">
              Study Resources
            </h3>
            <ul className="space-y-2">
              {['Classes', 'Worksheets', 'Quiz', 'Search'].map((tab) => (
                <li key={tab}>
                  <button
                    onClick={() => onViewChange(tab.toLowerCase())}
                    className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                  >
                    {tab} Hub
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support / Learn */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-4">
              Help & Support
            </h3>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onViewChange('about')}
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  About Platform
                </button>
              </li>
              <li>
                <a
                  href="#contact"
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  Contact Educators
                </a>
              </li>
              <li>
                <a
                  href="#faq"
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  Frequently Asked Questions
                </a>
              </li>
            </ul>
          </div>

          {/* Legal / Security */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-4">
              Legal Info
            </h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="#privacy"
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="#terms"
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  Terms of Service
                </a>
              </li>
              <li>
                <a
                  href="#cookies"
                  className="font-sans text-sm text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors duration-200"
                >
                  Cookie Preferences
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-sans text-xs text-slate-400 dark:text-slate-500">
            &copy; {new Date().getFullYear()} Physics Question Bank. Designed for student excellence.
          </p>
          <p className="font-sans text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1">
            Made with <Heart className="h-3.5 w-3.5 text-rose-500 fill-rose-500" /> for Physics Students
          </p>
        </div>
      </div>
    </footer>
  );
}
