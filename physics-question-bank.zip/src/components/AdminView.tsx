import React, { useState } from 'react';
import AdminLayout from './admin/AdminLayout';
import Dashboard from './admin/Dashboard';
import AddQuestion from './admin/AddQuestion';
import ManageQuestions from './admin/ManageQuestions';
import PdfUploader from './PdfUploader';
import BulkImportCsv from './admin/BulkImportCsv';
import BulkImportJson from './admin/BulkImportJson';
import ExportQuestions from './admin/ExportQuestions';
import ImportHistory from './admin/ImportHistory';
import ManageWorksheets from './admin/ManageWorksheets';
import CreateWorksheet from './admin/CreateWorksheet';
import ManageQuizzes from './admin/ManageQuizzes';
import CreateQuiz from './admin/CreateQuiz';
import ManageChapters from './admin/ManageChapters';
import Users from './admin/Users';
import Settings from './admin/Settings';

export default function AdminView() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'add_q': return <AddQuestion />;
      case 'manage_q': return <ManageQuestions />;
      case 'pdf': return <PdfUploader />;
      case 'bulk_csv': return <BulkImportCsv />;
      case 'bulk_json': return <BulkImportJson />;
      case 'export': return <ExportQuestions />;
      case 'history': return <ImportHistory />;
      case 'create_worksheet': return <CreateWorksheet />;
      case 'worksheets': return <ManageWorksheets />;
      case 'create_quiz': return <CreateQuiz />;
      case 'quizzes': return <ManageQuizzes />;
      case 'chapters': return <ManageChapters />;
      case 'users': return <Users />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <AdminLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </AdminLayout>
  );
}
