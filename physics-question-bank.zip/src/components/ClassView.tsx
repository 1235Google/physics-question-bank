import { useData } from '../context/DataContext';
import React from 'react';
import { Chapter } from '../types';
import { HelpCircle, Star, ArrowLeft, ArrowRight, Play, Award, BookOpen, Clock, Activity } from 'lucide-react';

interface ClassViewProps {
  classId: number;
  onBack: () => void;
  onPracticeChapter: (classId: number, chapter: string) => void;
  onQuizChapter: (classId: number, chapter: string) => void;
  favoriteChapters: string[];
  onToggleFavorite: (chapter: string) => void;
}

export default function ClassView({
  classId,
  onBack,
  onPracticeChapter,
  onQuizChapter,
  favoriteChapters,
  onToggleFavorite
}: ClassViewProps) {
  const { classes: CLASSES_DATA, chapters: CHAPTERS_DATA, questions: PHYSICS_QUESTIONS, worksheets: WORKSHEETS_DATA } = useData();
  const currentClass = CLASSES_DATA.find(cls => cls.id === classId);

  if (!currentClass) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-center">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Class level not found</h3>
        <button onClick={onBack} className="mt-4 text-blue-600 hover:underline dark:text-blue-400 font-bold">Go Back</button>
      </div>
    );
  }

  // Retrieve chapters for this class
  const classChapters = CHAPTERS_DATA.filter(ch => ch.classId === classId);

  return (
    <div id={`class-hub-${classId}`} className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Back CTA & Hero Header */}
      <div className="space-y-4">
        <button
          id="btn-class-back"
          onClick={onBack}
          className="group flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors duration-200"
        >
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5" /> 
          <span>Back to Class Hub</span>
        </button>

        <div className="rounded-3xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-700 dark:from-blue-750 dark:via-blue-800 dark:to-indigo-850 p-6 md:p-8 text-white shadow-xl shadow-blue-500/10 relative overflow-hidden">
          <div className="absolute right-0 bottom-0 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
          
          <div className="relative z-10">
            <h1 className="font-display text-2xl md:text-4xl font-black tracking-tight">
              {currentClass.name}
            </h1>
            <p className="font-sans text-sm md:text-base text-blue-100 mt-2.5 max-w-2xl leading-relaxed font-medium">
              Practice foundational Physics core topics. Study worksheets, solve targeted numericals, and test formulas with interactive quizzes.
            </p>

            <div className="flex flex-wrap gap-4 mt-6 pt-6 border-t border-white/10 text-xs font-bold uppercase tracking-wider">
              <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/5">
                <BookOpen className="h-4 w-4 text-blue-200" />
                <span>{currentClass.chaptersCount} Chapters</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/5">
                <Activity className="h-4 w-4 text-emerald-200" />
                <span>{currentClass.worksheetsCount} Worksheets</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/5">
                <HelpCircle className="h-4 w-4 text-purple-200" />
                <span>{currentClass.questionsCount} Questions</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chapters Card grid */}
      <div className="space-y-6">
        <h2 className="font-display text-xl md:text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          Syllabus Chapters
        </h2>

        <div id="chapters-list-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {classChapters.map((chapter) => {
            const isFav = favoriteChapters.includes(chapter.id);
            const chapterWorksheets = WORKSHEETS_DATA.filter(ws => ws.classId === classId && ws.title.toLowerCase().includes(chapter.name.toLowerCase().split(' ')[0]));
            
            return (
              <div
                key={chapter.id}
                id={`chapter-card-${chapter.id}`}
                className="group relative rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 shadow-lg shadow-slate-100/30 hover:shadow-xl hover:border-blue-500/50 hover:-translate-y-1 transition-all duration-300 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none flex flex-col justify-between h-[230px]"
              >
                {/* Favorite Toggler */}
                <button
                  id={`btn-chapter-fav-${chapter.id}`}
                  onClick={() => onToggleFavorite(chapter.id)}
                  className="absolute top-4.5 right-4.5 text-slate-400 hover:text-amber-500 hover:scale-110 transition-all duration-200 z-10"
                  title={isFav ? "Remove from Favorites" : "Mark as Favorite Chapter"}
                >
                  <Star className={`h-5 w-5 ${isFav ? 'text-amber-500 fill-amber-500' : ''}`} />
                </button>

                <div className="space-y-2 pr-6">
                  <h3 className="font-display text-base md:text-lg font-extrabold text-slate-950 dark:text-white leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200">
                    {chapter.name}
                  </h3>
                  <p className="font-sans text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-medium line-clamp-2">
                    {chapter.description}
                  </p>
                </div>

                <div>
                  {/* Metrics */}
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-bold text-slate-400 dark:text-slate-500 pt-3 border-t border-slate-100 dark:border-slate-850/50">
                    <span className="text-blue-600/80 dark:text-blue-400/80">{chapter.questions.length} Practice Questions</span>
                    <span>•</span>
                    <span>{chapterWorksheets.length || 1} Worksheets Included</span>
                  </div>

                  {/* Practice & Quiz CTAs */}
                  <div className="grid grid-cols-2 gap-3 mt-4">
                    <button
                      id={`btn-chapter-practice-${chapter.id}`}
                      onClick={() => onPracticeChapter(classId, chapter.id)}
                      className="flex items-center justify-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50/50 text-blue-700 py-2.5 font-sans text-xs font-bold hover:bg-blue-100 hover:text-blue-800 transition-all dark:border-blue-900/50 dark:bg-blue-950/20 dark:text-blue-400 dark:hover:bg-blue-950/40 cursor-pointer"
                    >
                      <BookOpen className="h-3.5 w-3.5" />
                      <span>Practice Mode</span>
                    </button>
                    <button
                      id={`btn-chapter-quiz-${chapter.id}`}
                      onClick={() => onQuizChapter(classId, chapter.id)}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 text-white py-2.5 font-sans text-xs font-bold hover:bg-blue-700 shadow-md shadow-blue-500/10 hover:shadow-lg hover:shadow-blue-500/20 transition-all cursor-pointer"
                    >
                      <Play className="h-3.5 w-3.5 text-blue-200 fill-blue-200" />
                      <span>Take Quiz</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
