import React from 'react';
import { BookOpen, ShieldCheck, Atom, HelpCircle, Activity, Sparkles, Award } from 'lucide-react';

export default function AboutView() {
  const highlights = [
    {
      icon: Atom,
      title: 'Academic Focus',
      text: 'Specially structured questions tracking Class 6 to 10 standards, facilitating deep, syllabus-compliant preparation.'
    },
    {
      icon: BookOpen,
      title: 'Versatile Question Formats',
      text: 'Solve MCQs, Fill in the blanks, True/False, numerical drills, and descriptive short/long-form questions with self-evaluation.'
    },
    {
      icon: ShieldCheck,
      title: 'Scientific Rationales',
      text: 'Every single question includes clear, comprehensive, step-by-step physical explanations to build intuitive conceptual models.'
    },
    {
      icon: Activity,
      title: 'Offline-first & Print-Ready',
      text: 'Generate and print custom chapter worksheets using standard browser-native print functions directly into beautiful PDF formats.'
    }
  ];

  return (
    <div id="about-platform" className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 space-y-12">
      {/* Intro Hero banner */}
      <div className="text-center space-y-4">
        <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 border border-blue-100 dark:border-blue-900/40 dark:bg-blue-950/40 dark:text-blue-400 mb-2 shadow-sm animate-bounce-slow">
          <Sparkles className="h-7 w-7" />
        </div>
        <h1 className="font-display text-3xl md:text-4xl font-black tracking-tight text-slate-950 dark:text-white">
          About Physics Question Bank
        </h1>
        <p className="font-sans text-base text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed font-medium">
          The ultimate interactive practice platform for junior and middle-school Physics students. Our mission is to combine rigorous educational concepts with active online exercises.
        </p>
      </div>

      {/* Grid Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {highlights.map((h, idx) => {
          const Icon = h.icon;
          return (
            <div key={idx} className="group rounded-2xl border border-slate-200/60 bg-white/70 backdrop-blur-md p-5 dark:border-slate-850/60 dark:bg-slate-900/75 dark:shadow-none space-y-3 hover:-translate-y-0.5 hover:shadow-xl hover:border-blue-500/40 transition-all duration-300">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 group-hover:scale-105 transition-transform duration-300">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {h.title}
              </h3>
              <p className="font-sans text-sm text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                {h.text}
              </p>
            </div>
          );
        })}
      </div>

      {/* Curriculum outline documentation */}
      <div className="rounded-3xl border border-slate-200/60 bg-white/50 backdrop-blur-md p-6 md:p-8 dark:border-slate-850/60 dark:bg-slate-900/40 space-y-6">
        <h2 className="font-display text-xl md:text-2xl font-black text-slate-950 dark:text-white flex items-center gap-2">
          <Award className="h-6 w-6 text-blue-600" />
          <span>Curriculum Coverage Outline</span>
        </h2>
        
        <div className="space-y-4 font-sans text-sm md:text-base text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
          <p>
            Our core physics questions and worksheets are curated by expert educators, tracking standard curriculum levels perfectly:
          </p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mt-4">
            <li className="bg-white/80 dark:bg-slate-900/80 p-4.5 rounded-xl border border-slate-100 dark:border-slate-850/60">
              <strong className="text-slate-800 dark:text-white block font-display font-bold mb-1 text-sm">Classes 6 & 7:</strong>
              Introduces measurement foundations, simple motion patterns, transparent/opaque optical materials, basic heat transfers, thermometers, and electrical current symbols.
            </li>
            <li className="bg-white/80 dark:bg-slate-900/80 p-4.5 rounded-xl border border-slate-100 dark:border-slate-850/60">
              <strong className="text-slate-800 dark:text-white block font-display font-bold mb-1 text-sm">Class 8:</strong>
              Covers force, mechanical pressure, fluid pressure, laws of optical reflection, anatomy of the human eye, and static vs rolling frictional characteristics.
            </li>
            <li className="bg-white/80 dark:bg-slate-900/80 p-4.5 rounded-xl border border-slate-100 dark:border-slate-850/60">
              <strong className="text-slate-800 dark:text-white block font-display font-bold mb-1 text-sm">Class 9:</strong>
              Deals with quantitative equations of motion, momentum conservation, universal gravitation, mass vs weight, and buoyant forces (Archimedes' Principle).
            </li>
            <li className="bg-white/80 dark:bg-slate-900/80 p-4.5 rounded-xl border border-slate-100 dark:border-slate-850/60">
              <strong className="text-slate-800 dark:text-white block font-display font-bold mb-1 text-sm">Class 10:</strong>
              Investigates mathematical optics (convex/concave mirrors and lenses), electrical potential difference, Ohmic resistances, Joule's law of heating, and electromagnetic inductions.
            </li>
          </ul>
        </div>
      </div>

      {/* Firebase connection explanation */}
      <div className="rounded-3xl border border-dashed border-blue-200 bg-blue-50/10 p-6 text-center dark:border-blue-900/30">
        <h3 className="font-display text-base font-extrabold text-slate-950 dark:text-white">Cloud Integration Ready</h3>
        <p className="font-sans text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-lg mx-auto leading-relaxed font-medium">
          The underlying state layer is decoupled from components. It can be easily hooked up to an online database (like Firebase Firestore) for collaborative accounts and thousands of questions without changing any front-end UI.
        </p>
      </div>
    </div>
  );
}
